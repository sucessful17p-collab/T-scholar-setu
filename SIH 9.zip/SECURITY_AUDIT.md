# Backend security/functionality audit

## Fixed in this package

1. **OTP generation** — replaced non-cryptographic `random.randint()` with `secrets.randbelow()`.
2. **OTP brute force** — implemented failed-attempt counting, 5-attempt lockout, and a 15-minute lock.
3. **OTP resend abuse** — added a 60-second per-account resend cooldown.
4. **OTP database mismatch** — the ORM referenced `failed_otp_attempts` and `otp_locked_until` without a migration; added a migration and `otp_sent_at`.
5. **JWT dependency URL** — corrected the OAuth2 token URL to `/api/v1/identity/auth/verify-otp`.
6. **JWT parsing** — invalid/non-numeric `sub` values now return 401 instead of causing a server error.
7. **Production secrets** — production startup now rejects weak/default JWT secrets and mock identity/OTP providers.
8. **CORS** — credentialed CORS was disabled because the application uses bearer tokens rather than cookies.
9. **Document uploads** — MIME type, size, filename, and magic-byte checks are enforced; storage keys are UUID-only and files are created with restrictive permissions.
10. **Document persistence** — Docker now mounts a persistent document volume rather than storing uploads only in `/tmp`.
11. **Grievance authorization** — applicants can no longer set staff assignment or internal resolution fields, and application-linked grievances are ownership checked.
12. **Notification authorization** — applicants cannot create notifications linked to another applicant's application.
13. **Eligibility transaction bug** — the eligibility engine no longer commits internally, so an incomplete eligibility check can be rolled back correctly during application submission.
14. **Payment idempotency race** — database uniqueness conflicts are handled rather than returning duplicate-payment errors or leaking provider exception text.
15. **Rate-limit memory growth** — the in-process limiter now bounds its key set.
16. **Mutable Pydantic defaults** — list/dict defaults were changed to factories.

## Remaining production controls

- The bundled Aadhaar, DigiLocker, OTP and PFMS implementations are mocks and must be replaced with approved providers.
- Put the API behind HTTPS and a production reverse proxy/WAF with a distributed rate limiter (Redis is preferable for multiple workers).
- Use a managed secret store and a real PostgreSQL credential; do not commit `.env`.
- Antivirus/content scanning should be added for uploaded documents before they enter a government workflow.
- Local file storage should be replaced by private object storage with signed, short-lived download URLs at production scale.
- The current JWT design has no server-side revocation list; use short-lived access tokens plus refresh-token rotation/revocation if persistent sessions are required.
- Verification workflow geography/institution boundaries are not modeled in the current schema, so role-based checks cannot enforce district/institute tenancy yet.

## Validation performed on this archive

- Python bytecode compilation: **passed**.
- AST parsing of backend Python files: **passed**.
- Pydantic phone/OTP validation smoke test: **passed** after hardening.
- Full pytest suite could not be executed in this analysis environment because required runtime packages/database services are unavailable here. Docker is also unavailable in this environment. Run `docker compose up --build` on the development machine for the authoritative integration test.
