# Phase 16 — SIH Demo / Deployment

## 1. Local Docker

From the repository root:

```bash
docker compose up --build
```

Backend:
- API: `http://localhost:8000`
- Health: `http://localhost:8000/health`
- OpenAPI: `http://localhost:8000/api/v1/openapi.json`

## 2. Database migration

The backend uses Alembic. On a fresh database:

```bash
docker compose exec backend alembic upgrade head
```

For a development reset, recreate the Postgres volume instead of manually editing migration tables.

## 3. Demo sequence

1. Request OTP using the mock OTP provider.
2. Complete applicant profile.
3. Create/select an active scheme version.
4. Create an application.
5. Upload mandatory documents.
6. Submit application.
7. Eligibility runs automatically.
8. Eligible application receives a verification assignment.
9. Nodal officer completes verification.
10. Admin creates and executes a selection run.
11. Admin publishes the merit list.
12. Admin creates a payment order using an idempotency key.
13. Mock PFMS marks it PAID.
14. Applicant sees payment/merit notifications.
15. Applicant can open a grievance.
16. Admin views analytics/dashboard/audit.
17. Admin can add guideline text and test the RAG assistant.

## 4. Production replacements required

Before production, replace the demo components:

- mock OTP -> approved SMS/OTP provider
- mock Aadhaar/DigiLocker -> approved government integration
- local document storage -> encrypted object storage with private buckets
- mock PFMS -> approved PFMS/DBT integration
- deterministic RAG -> approved embedding/vector + LLM stack
- in-memory rate limiter -> Redis/API gateway rate limiting
- development JWT secret -> secret manager/KMS generated secret
- HTTP -> TLS termination at the gateway
- local logs -> centralized, access-controlled observability
- demo admin creation -> controlled RBAC/provisioning workflow

Do not store raw Aadhaar numbers or other unnecessary identity data. Store opaque references/tokens wherever the integration permits.
