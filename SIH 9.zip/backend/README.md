# SIH Scholarship System — Backend

The backend is a **modular monolith** built with FastAPI + SQLAlchemy + PostgreSQL. It mirrors the frontend/application lifecycle and the architecture shown in `scholarship_platform_architecture.png`.

## Implemented phases

| Phase | Backend scope | Status |
|---|---|---|
| 0 | Architecture / scaffold | Complete |
| 1 | Infrastructure / database | Complete |
| 2 | Scheme configuration | Complete |
| 3 | Identity & authentication | Complete |
| 4 | Applicant / application | Complete |
| 5 | Document management | Complete |
| 6 | Eligibility engine | Complete |
| 7 | Verification workflow | Complete |
| 8 | Selection / merit | **Implemented** |
| 9 | Payment / DBT | **Implemented with mock PFMS adapter** |
| 10 | Notifications | **Implemented with in-app/demo provider** |
| 11 | Grievance | **Implemented** |
| 12 | AI / RAG assistant | **Implemented as deterministic local retrieval; LLM/vector adapter can be added later** |
| 13 | Analytics / MIS | **Implemented** |
| 14 | Admin dashboard APIs | **Implemented** |
| 15 | Security / hardening | **Implemented baseline** |
| 16 | Demo / deployment | **Docker + migration + test hooks prepared** |

## API surface

- `/api/v1/identity/*` — OTP login, profile, Aadhaar/DigiLocker adapter hooks
- `/api/v1/schemes/*` — scheme configuration
- `/api/v1/applications/*` — application lifecycle
- `/api/v1/applications/{id}/eligibility/*` — eligibility evaluation
- `/api/v1/applications/{id}/documents/*` — document management
- `/api/v1/verifications/*` — nodal verification workflow
- `/api/v1/selection/*` — merit/selection runs and published results
- `/api/v1/payments/*` — idempotent DBT/PFMS demo processing
- `/api/v1/notifications/*` — applicant notifications
- `/api/v1/grievances/*` — grievance tickets
- `/api/v1/assistant/*` — scheme-guideline retrieval assistant
- `/api/v1/analytics/*` — MIS metrics
- `/api/v1/admin/dashboard` — admin dashboard aggregation
- `/api/v1/security/audit` — admin audit view
- `/health` — database health check

## Selection flow

`VERIFIED applications -> SelectionRun -> deterministic score -> rank -> SELECTED/NOT_SELECTED -> admin publishes merit list -> notification`

Selection criteria are read from `selection_criteria`. Supported demo inputs include `MARKS_PERCENTAGE`, `INSTITUTE_QS_RANKING`, `RESEARCH_SCORE`, and `ENTRANCE_SCORE`. The scoring implementation is intentionally deterministic and auditable; scheme-specific policy should be configured before a real deployment.

## Payment flow

`Published SELECTED result -> PaymentOrder -> idempotency check -> PFMS adapter -> PAID/FAILED -> notification`

The bundled provider is a mock adapter for SIH demonstration. Replace it with the approved PFMS integration adapter before production.

## RAG flow

`Admin uploads guideline text -> KnowledgeDocument -> token-overlap retrieval -> cited source excerpts`

This is a local deterministic RAG foundation rather than a production LLM service. It is deliberately safe for a demo and can later be replaced by an embeddings/vector-search + approved LLM adapter.

## Security baseline

- JWT authentication and role checks
- Admin-only scheme creation, selection execution, payment processing, knowledge ingestion and analytics
- Request IDs
- Security headers
- CORS allow-list
- Per-client/path rate limiting
- Idempotent payment requests
- Audit logging for major workflow operations
- No raw Aadhaar number is stored by the existing identity adapter design

## Run

```bash
cd backend
pip install -r requirements.txt
alembic upgrade head
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

For Docker:

```bash
docker compose up --build
```

Set a strong random `SECRET_KEY`, real database credentials, HTTPS, and production CORS origins before deployment.
