"""Security hardening for OTP state and document storage.

Revision ID: 9a8b7c6d5e4f
Revises: f23456789012
"""
from alembic import op
import sqlalchemy as sa

revision = "9a8b7c6d5e4f"
down_revision = "f23456789012"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("user_accounts", sa.Column("otp_sent_at", sa.DateTime(), nullable=True))
    op.add_column(
        "user_accounts",
        sa.Column("failed_otp_attempts", sa.Integer(), nullable=False, server_default="0"),
    )
    op.add_column("user_accounts", sa.Column("otp_locked_until", sa.DateTime(), nullable=True))
    op.alter_column("user_accounts", "failed_otp_attempts", server_default=None)


def downgrade() -> None:
    op.drop_column("user_accounts", "otp_locked_until")
    op.drop_column("user_accounts", "failed_otp_attempts")
    op.drop_column("user_accounts", "otp_sent_at")
