"""Add Scheme Configuration Models

Revision ID: a1b2c3d4e5f6
Revises: 92d213cde4e1
Create Date: 2026-09-17 00:38:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'a1b2c3d4e5f6'
down_revision = '92d213cde4e1'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table('schemes',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(), nullable=False),
        sa.Column('description', sa.String(), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_schemes_id'), 'schemes', ['id'], unique=False)
    op.create_index(op.f('ix_schemes_name'), 'schemes', ['name'], unique=False)

    op.create_table('scheme_versions',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('scheme_id', sa.Integer(), nullable=False),
        sa.Column('version_number', sa.String(), nullable=False),
        sa.Column('start_date', sa.Date(), nullable=True),
        sa.Column('end_date', sa.Date(), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.ForeignKeyConstraint(['scheme_id'], ['schemes.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_scheme_versions_id'), 'scheme_versions', ['id'], unique=False)

    op.create_table('benefits',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('scheme_version_id', sa.Integer(), nullable=False),
        sa.Column('benefit_name', sa.String(), nullable=False),
        sa.Column('benefit_type', sa.Enum('ALLOWANCE', 'FEE_REIMBURSEMENT', 'ONE_TIME_GRANT', name='benefittypeenum'), nullable=False),
        sa.Column('amount', sa.Float(), nullable=False),
        sa.Column('currency', sa.String(), nullable=True),
        sa.Column('description', sa.String(), nullable=True),
        sa.ForeignKeyConstraint(['scheme_version_id'], ['scheme_versions.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_benefits_id'), 'benefits', ['id'], unique=False)

    op.create_table('eligibility_rules',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('scheme_version_id', sa.Integer(), nullable=False),
        sa.Column('rule_type', sa.String(), nullable=False),
        sa.Column('operator', sa.Enum('EQUALS', 'GREATER_THAN', 'LESS_THAN', 'GREATER_EQUALS', 'LESS_EQUALS', 'IN', name='operatorenum'), nullable=False),
        sa.Column('value', sa.String(), nullable=False),
        sa.ForeignKeyConstraint(['scheme_version_id'], ['scheme_versions.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_eligibility_rules_id'), 'eligibility_rules', ['id'], unique=False)

    op.create_table('form_fields',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('scheme_version_id', sa.Integer(), nullable=False),
        sa.Column('field_name', sa.String(), nullable=False),
        sa.Column('field_type', sa.Enum('STRING', 'INTEGER', 'FLOAT', 'DATE', 'BOOLEAN', name='fieldtypeenum'), nullable=False),
        sa.Column('is_mandatory', sa.Boolean(), nullable=True),
        sa.ForeignKeyConstraint(['scheme_version_id'], ['scheme_versions.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_form_fields_id'), 'form_fields', ['id'], unique=False)

    op.create_table('required_documents',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('scheme_version_id', sa.Integer(), nullable=False),
        sa.Column('document_name', sa.String(), nullable=False),
        sa.Column('is_mandatory', sa.Boolean(), nullable=True),
        sa.Column('description', sa.String(), nullable=True),
        sa.ForeignKeyConstraint(['scheme_version_id'], ['scheme_versions.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_required_documents_id'), 'required_documents', ['id'], unique=False)

    op.create_table('selection_criteria',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('scheme_version_id', sa.Integer(), nullable=False),
        sa.Column('criterion', sa.String(), nullable=False),
        sa.Column('priority', sa.Integer(), nullable=False),
        sa.ForeignKeyConstraint(['scheme_version_id'], ['scheme_versions.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_selection_criteria_id'), 'selection_criteria', ['id'], unique=False)

    op.create_table('workflow_rules',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('scheme_version_id', sa.Integer(), nullable=False),
        sa.Column('step_order', sa.Integer(), nullable=False),
        sa.Column('step_name', sa.String(), nullable=False),
        sa.Column('required_role', sa.String(), nullable=False),
        sa.Column('is_final_approval', sa.Boolean(), nullable=True),
        sa.ForeignKeyConstraint(['scheme_version_id'], ['scheme_versions.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_workflow_rules_id'), 'workflow_rules', ['id'], unique=False)


def downgrade() -> None:
    op.drop_index(op.f('ix_workflow_rules_id'), table_name='workflow_rules')
    op.drop_table('workflow_rules')
    
    op.drop_index(op.f('ix_selection_criteria_id'), table_name='selection_criteria')
    op.drop_table('selection_criteria')
    
    op.drop_index(op.f('ix_required_documents_id'), table_name='required_documents')
    op.drop_table('required_documents')
    
    op.drop_index(op.f('ix_form_fields_id'), table_name='form_fields')
    op.drop_table('form_fields')
    
    op.drop_index(op.f('ix_eligibility_rules_id'), table_name='eligibility_rules')
    op.drop_table('eligibility_rules')
    
    op.drop_index(op.f('ix_benefits_id'), table_name='benefits')
    op.drop_table('benefits')
    
    op.drop_index(op.f('ix_scheme_versions_id'), table_name='scheme_versions')
    op.drop_table('scheme_versions')
    
    op.drop_index(op.f('ix_schemes_name'), table_name='schemes')
    op.drop_index(op.f('ix_schemes_id'), table_name='schemes')
    op.drop_table('schemes')
    
    sa.Enum(name='benefittypeenum').drop(op.get_bind(), checkfirst=True)
    sa.Enum(name='operatorenum').drop(op.get_bind(), checkfirst=True)
    sa.Enum(name='fieldtypeenum').drop(op.get_bind(), checkfirst=True)
