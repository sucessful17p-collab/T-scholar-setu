"""Phase 3 Identity Models

Revision ID: c2d3e4f5a6b7
Revises: b1c2d3e4f5a6
Create Date: 2026-09-17 01:20:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'c2d3e4f5a6b7'
down_revision = 'b1c2d3e4f5a6'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # user_role ENUM
    user_role_enum = sa.Enum('APPLICANT', 'ADMIN', name='userrole')

    # gender ENUM
    gender_enum = sa.Enum('MALE', 'FEMALE', 'OTHER', name='genderenum')

    # verification_provider ENUM
    provider_enum = sa.Enum('AADHAAR', 'DIGILOCKER', name='verificationprovider')

    # verification_status ENUM
    status_enum = sa.Enum('PENDING', 'VERIFIED', 'FAILED', name='verificationstatus')

    op.create_table('user_accounts',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('phone_number', sa.String(), nullable=False),
        sa.Column('role', user_role_enum, nullable=False),
        sa.Column('hashed_otp', sa.String(), nullable=True),
        sa.Column('otp_expires_at', sa.DateTime(), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_user_accounts_id'), 'user_accounts', ['id'], unique=False)
    op.create_index(op.f('ix_user_accounts_phone_number'), 'user_accounts', ['phone_number'], unique=True)

    op.create_table('applicant_profiles',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('full_name', sa.String(), nullable=True),
        sa.Column('date_of_birth', sa.Date(), nullable=True),
        sa.Column('gender', gender_enum, nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['user_accounts.id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('user_id')
    )
    op.create_index(op.f('ix_applicant_profiles_id'), 'applicant_profiles', ['id'], unique=False)

    op.create_table('identity_verifications',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('applicant_profile_id', sa.Integer(), nullable=False),
        sa.Column('provider', provider_enum, nullable=False),
        sa.Column('reference_id', sa.String(), nullable=True),
        sa.Column('verification_status', status_enum, nullable=False),
        sa.Column('verified_at', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['applicant_profile_id'], ['applicant_profiles.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_identity_verifications_id'), 'identity_verifications', ['id'], unique=False)
    op.create_index(op.f('ix_identity_verifications_reference_id'), 'identity_verifications', ['reference_id'], unique=False)


def downgrade() -> None:
    op.drop_index(op.f('ix_identity_verifications_reference_id'), table_name='identity_verifications')
    op.drop_index(op.f('ix_identity_verifications_id'), table_name='identity_verifications')
    op.drop_table('identity_verifications')
    
    op.drop_index(op.f('ix_applicant_profiles_id'), table_name='applicant_profiles')
    op.drop_table('applicant_profiles')
    
    op.drop_index(op.f('ix_user_accounts_phone_number'), table_name='user_accounts')
    op.drop_index(op.f('ix_user_accounts_id'), table_name='user_accounts')
    op.drop_table('user_accounts')

    sa.Enum(name='verificationstatus').drop(op.get_bind(), checkfirst=True)
    sa.Enum(name='verificationprovider').drop(op.get_bind(), checkfirst=True)
    sa.Enum(name='genderenum').drop(op.get_bind(), checkfirst=True)
    sa.Enum(name='userrole').drop(op.get_bind(), checkfirst=True)
