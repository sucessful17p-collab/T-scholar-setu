"""phase_6_eligibility_engine

Revision ID: d912b3c4f5e6
Revises: 6b65cb07af9d
Create Date: 2026-09-17 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = 'd912b3c4f5e6'
down_revision: Union[str, None] = '6b65cb07af9d'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # EligibilityOverallStatus
    overall_status_enum = sa.Enum('ELIGIBLE', 'NOT_ELIGIBLE', 'INCOMPLETE', name='eligibilityoverallstatus')
    
    # EligibilityRuleResultStatus
    result_status_enum = sa.Enum('PASS', 'FAIL', 'UNKNOWN', name='eligibilityruleresultstatus')

    op.create_table('eligibility_evaluations',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('application_id', sa.Integer(), nullable=False),
    sa.Column('scheme_version_id', sa.Integer(), nullable=False),
    sa.Column('overall_status', overall_status_enum, nullable=False),
    sa.Column('evaluated_at', sa.DateTime(), nullable=True),
    sa.Column('created_at', sa.DateTime(), nullable=True),
    sa.ForeignKeyConstraint(['application_id'], ['applications.id'], ),
    sa.ForeignKeyConstraint(['scheme_version_id'], ['scheme_versions.id'], ),
    sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_eligibility_evaluations_application_id'), 'eligibility_evaluations', ['application_id'], unique=False)
    op.create_index(op.f('ix_eligibility_evaluations_id'), 'eligibility_evaluations', ['id'], unique=False)

    op.create_table('eligibility_rule_results',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('evaluation_id', sa.Integer(), nullable=False),
    sa.Column('eligibility_rule_id', sa.Integer(), nullable=False),
    sa.Column('result', result_status_enum, nullable=False),
    sa.Column('actual_value', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
    sa.Column('expected_value', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
    sa.Column('explanation', sa.String(), nullable=True),
    sa.Column('created_at', sa.DateTime(), nullable=True),
    sa.ForeignKeyConstraint(['eligibility_rule_id'], ['eligibility_rules.id'], ),
    sa.ForeignKeyConstraint(['evaluation_id'], ['eligibility_evaluations.id'], ),
    sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_eligibility_rule_results_evaluation_id'), 'eligibility_rule_results', ['evaluation_id'], unique=False)
    op.create_index(op.f('ix_eligibility_rule_results_id'), 'eligibility_rule_results', ['id'], unique=False)


def downgrade() -> None:
    op.drop_index(op.f('ix_eligibility_rule_results_id'), table_name='eligibility_rule_results')
    op.drop_index(op.f('ix_eligibility_rule_results_evaluation_id'), table_name='eligibility_rule_results')
    op.drop_table('eligibility_rule_results')
    
    op.drop_index(op.f('ix_eligibility_evaluations_id'), table_name='eligibility_evaluations')
    op.drop_index(op.f('ix_eligibility_evaluations_application_id'), table_name='eligibility_evaluations')
    op.drop_table('eligibility_evaluations')
    
    sa.Enum(name='eligibilityruleresultstatus').drop(op.get_bind(), checkfirst=True)
    sa.Enum(name='eligibilityoverallstatus').drop(op.get_bind(), checkfirst=True)
