"""phase_7_verification

Revision ID: e123456789ab
Revises: d912b3c4f5e6
Create Date: 2026-09-17 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = 'e123456789ab'
down_revision: Union[str, None] = 'd912b3c4f5e6'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # 1. Update ApplicationStatus Enum
    # Postgres ENUM alterations must be committed outside transaction block
    op.execute("COMMIT")
    op.execute("ALTER TYPE applicationstatus ADD VALUE IF NOT EXISTS 'IN_REVIEW'")
    op.execute("ALTER TYPE applicationstatus ADD VALUE IF NOT EXISTS 'DEFECTIVE'")
    op.execute("ALTER TYPE applicationstatus ADD VALUE IF NOT EXISTS 'VERIFIED'")
    op.execute("ALTER TYPE applicationstatus ADD VALUE IF NOT EXISTS 'REJECTED'")
    
    # 2. Update UserRole Enum
    op.execute("ALTER TYPE userrole ADD VALUE IF NOT EXISTS 'INSTITUTE_NODAL_OFFICER'")
    op.execute("ALTER TYPE userrole ADD VALUE IF NOT EXISTS 'DISTRICT_NODAL_OFFICER'")
    
    # 3. Create AuditLog
    op.create_table('audit_logs',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('actor_id', sa.Integer(), nullable=True),
    sa.Column('action', sa.String(), nullable=False),
    sa.Column('entity_type', sa.String(), nullable=False),
    sa.Column('entity_id', sa.Integer(), nullable=False),
    sa.Column('old_status', sa.String(), nullable=True),
    sa.Column('new_status', sa.String(), nullable=True),
    sa.Column('metadata_json', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
    sa.Column('created_at', sa.DateTime(), nullable=True),
    sa.ForeignKeyConstraint(['actor_id'], ['user_accounts.id'], ),
    sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_audit_logs_action'), 'audit_logs', ['action'], unique=False)
    op.create_index(op.f('ix_audit_logs_actor_id'), 'audit_logs', ['actor_id'], unique=False)
    op.create_index(op.f('ix_audit_logs_entity_id'), 'audit_logs', ['entity_id'], unique=False)
    op.create_index(op.f('ix_audit_logs_entity_type'), 'audit_logs', ['entity_type'], unique=False)
    op.create_index(op.f('ix_audit_logs_id'), 'audit_logs', ['id'], unique=False)

    # 4. Create Verification Enums & Tables
    assignment_status_enum = sa.Enum('PENDING', 'ASSIGNED', 'COMPLETED', 'CANCELLED', name='verificationassignmentstatus')
    action_enum = sa.Enum('APPROVE', 'DEFECT', 'REJECT', name='verificationactionenum')
    
    op.create_table('verification_assignments',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('application_id', sa.Integer(), nullable=False),
    sa.Column('verifier_id', sa.Integer(), nullable=True),
    sa.Column('verification_level', sa.String(), nullable=False),
    sa.Column('status', assignment_status_enum, nullable=False),
    sa.Column('assigned_at', sa.DateTime(), nullable=True),
    sa.Column('completed_at', sa.DateTime(), nullable=True),
    sa.Column('created_at', sa.DateTime(), nullable=True),
    sa.Column('updated_at', sa.DateTime(), nullable=True),
    sa.ForeignKeyConstraint(['application_id'], ['applications.id'], ),
    sa.ForeignKeyConstraint(['verifier_id'], ['user_accounts.id'], ),
    sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_verification_assignments_application_id'), 'verification_assignments', ['application_id'], unique=False)
    op.create_index(op.f('ix_verification_assignments_id'), 'verification_assignments', ['id'], unique=False)
    op.create_index(op.f('ix_verification_assignments_verifier_id'), 'verification_assignments', ['verifier_id'], unique=False)

    op.create_table('verification_actions',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('assignment_id', sa.Integer(), nullable=False),
    sa.Column('application_id', sa.Integer(), nullable=False),
    sa.Column('verifier_id', sa.Integer(), nullable=False),
    sa.Column('action', action_enum, nullable=False),
    sa.Column('comments', sa.String(), nullable=True),
    sa.Column('created_at', sa.DateTime(), nullable=True),
    sa.ForeignKeyConstraint(['application_id'], ['applications.id'], ),
    sa.ForeignKeyConstraint(['assignment_id'], ['verification_assignments.id'], ),
    sa.ForeignKeyConstraint(['verifier_id'], ['user_accounts.id'], ),
    sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_verification_actions_application_id'), 'verification_actions', ['application_id'], unique=False)
    op.create_index(op.f('ix_verification_actions_assignment_id'), 'verification_actions', ['assignment_id'], unique=False)
    op.create_index(op.f('ix_verification_actions_id'), 'verification_actions', ['id'], unique=False)
    op.create_index(op.f('ix_verification_actions_verifier_id'), 'verification_actions', ['verifier_id'], unique=False)


def downgrade() -> None:
    op.drop_index(op.f('ix_verification_actions_verifier_id'), table_name='verification_actions')
    op.drop_index(op.f('ix_verification_actions_id'), table_name='verification_actions')
    op.drop_index(op.f('ix_verification_actions_assignment_id'), table_name='verification_actions')
    op.drop_index(op.f('ix_verification_actions_application_id'), table_name='verification_actions')
    op.drop_table('verification_actions')
    
    op.drop_index(op.f('ix_verification_assignments_verifier_id'), table_name='verification_assignments')
    op.drop_index(op.f('ix_verification_assignments_id'), table_name='verification_assignments')
    op.drop_index(op.f('ix_verification_assignments_application_id'), table_name='verification_assignments')
    op.drop_table('verification_assignments')
    
    sa.Enum(name='verificationactionenum').drop(op.get_bind(), checkfirst=True)
    sa.Enum(name='verificationassignmentstatus').drop(op.get_bind(), checkfirst=True)
    
    op.drop_index(op.f('ix_audit_logs_id'), table_name='audit_logs')
    op.drop_index(op.f('ix_audit_logs_entity_type'), table_name='audit_logs')
    op.drop_index(op.f('ix_audit_logs_entity_id'), table_name='audit_logs')
    op.drop_index(op.f('ix_audit_logs_actor_id'), table_name='audit_logs')
    op.drop_index(op.f('ix_audit_logs_action'), table_name='audit_logs')
    op.drop_table('audit_logs')
    # Not downgrading enums because dropping values from postgres enums is complex and usually skipped in downgrade scripts.
