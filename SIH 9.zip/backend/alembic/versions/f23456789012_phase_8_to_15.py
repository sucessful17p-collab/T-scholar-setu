"""phases 8-15 selection payment notification grievance rag analytics admin security

Revision ID: f23456789012
Revises: e123456789ab
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "f23456789012"
down_revision = "e123456789ab"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        "selection_runs",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("scheme_version_id", sa.Integer(), sa.ForeignKey("scheme_versions.id"), nullable=False, index=True),
        sa.Column("seats", sa.Integer(), nullable=False),
        sa.Column("status", sa.Enum("DRAFT","EXECUTED","PUBLISHED","CANCELLED", name="selectionrunstatus"), nullable=False),
        sa.Column("created_by", sa.Integer(), sa.ForeignKey("user_accounts.id"), nullable=True),
        sa.Column("executed_at", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
    )
    op.create_table(
        "selection_results",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("run_id", sa.Integer(), sa.ForeignKey("selection_runs.id"), nullable=False, index=True),
        sa.Column("application_id", sa.Integer(), sa.ForeignKey("applications.id"), nullable=False, index=True),
        sa.Column("rank", sa.Integer(), nullable=False),
        sa.Column("score", sa.Float(), nullable=False),
        sa.Column("decision", sa.Enum("SELECTED","WAITLISTED","NOT_SELECTED", name="selectiondecision"), nullable=False),
        sa.Column("score_breakdown", postgresql.JSONB(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=True),
    )
    op.create_table(
        "payment_orders",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("application_id", sa.Integer(), sa.ForeignKey("applications.id"), nullable=False, index=True),
        sa.Column("benefit_id", sa.Integer(), sa.ForeignKey("benefits.id"), nullable=True),
        sa.Column("amount", sa.Float(), nullable=False),
        sa.Column("currency", sa.String(), nullable=False),
        sa.Column("status", sa.Enum("INITIATED","SENT","PAID","FAILED","REVERSED", name="paymentstatus"), nullable=False),
        sa.Column("idempotency_key", sa.String(), nullable=False, unique=True, index=True),
        sa.Column("provider_reference", sa.String(), nullable=True, index=True),
        sa.Column("failure_reason", sa.String(), nullable=True),
        sa.Column("initiated_at", sa.DateTime(), nullable=True),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
        sa.Column("paid_at", sa.DateTime(), nullable=True),
    )
    op.create_table(
        "notifications",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("user_accounts.id"), nullable=False, index=True),
        sa.Column("application_id", sa.Integer(), sa.ForeignKey("applications.id"), nullable=True, index=True),
        sa.Column("channel", sa.Enum("IN_APP","SMS","EMAIL", name="notificationchannel"), nullable=False),
        sa.Column("template", sa.String(), nullable=False),
        sa.Column("message", sa.String(), nullable=False),
        sa.Column("status", sa.Enum("QUEUED","SENT","FAILED","READ", name="notificationstatus"), nullable=False),
        sa.Column("provider_reference", sa.String(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.Column("sent_at", sa.DateTime(), nullable=True),
    )
    op.create_table(
        "grievance_tickets",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("ticket_number", sa.String(), nullable=False, unique=True, index=True),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("user_accounts.id"), nullable=False, index=True),
        sa.Column("application_id", sa.Integer(), sa.ForeignKey("applications.id"), nullable=True, index=True),
        sa.Column("category", sa.String(), nullable=False),
        sa.Column("subject", sa.String(), nullable=False),
        sa.Column("description", sa.String(), nullable=False),
        sa.Column("priority", sa.Enum("LOW","MEDIUM","HIGH", name="grievancepriority"), nullable=False),
        sa.Column("status", sa.Enum("OPEN","IN_PROGRESS","RESOLVED","CLOSED", name="grievancestatus"), nullable=False),
        sa.Column("assigned_to", sa.Integer(), sa.ForeignKey("user_accounts.id"), nullable=True),
        sa.Column("resolution_note", sa.String(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
        sa.Column("resolved_at", sa.DateTime(), nullable=True),
    )
    op.create_table(
        "knowledge_documents",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("scheme_version_id", sa.Integer(), sa.ForeignKey("scheme_versions.id"), nullable=True, index=True),
        sa.Column("title", sa.String(), nullable=False),
        sa.Column("source", sa.String(), nullable=True),
        sa.Column("content", sa.Text(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
    )

def downgrade():
    op.drop_table("knowledge_documents")
    op.drop_table("grievance_tickets")
    op.drop_table("notifications")
    op.drop_table("payment_orders")
    op.drop_table("selection_results")
    op.drop_table("selection_runs")
    for name in ["grievancepriority","grievancestatus","notificationstatus","notificationchannel","paymentstatus","selectiondecision","selectionrunstatus"]:
        op.execute(sa.text(f"DROP TYPE IF EXISTS {name}"))
