# Core Initialization
