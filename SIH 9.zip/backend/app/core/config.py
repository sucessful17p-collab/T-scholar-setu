from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    PROJECT_NAME: str = "SIH Scholarship System"
    API_V1_STR: str = "/api/v1"
    ENVIRONMENT: str = "development"

    POSTGRES_USER: str
    POSTGRES_PASSWORD: str
    POSTGRES_DB: str
    DATABASE_URL: str

    SECRET_KEY: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24

    AADHAAR_PROVIDER: str = "mock"
    DIGILOCKER_PROVIDER: str = "mock"
    OTP_PROVIDER: str = "mock"

    RATE_LIMIT_PER_MINUTE: int = 120
    OTP_RESEND_COOLDOWN_SECONDS: int = 60
    OTP_MAX_ATTEMPTS: int = 5
    OTP_LOCK_MINUTES: int = 15
    DOCUMENT_MAX_SIZE_MB: int = 5
    DOCUMENT_STORAGE_PATH: str = "/app/data/sih_uploads"
    CORS_ORIGINS: str = "http://localhost:3000,http://localhost:5173"

    model_config = SettingsConfigDict(env_file=".env", case_sensitive=True, extra="ignore")

    @property
    def cors_origins(self):
        return [x.strip() for x in self.CORS_ORIGINS.split(",") if x.strip()]

    def validate_runtime(self) -> None:
        if self.ENVIRONMENT.lower() == "production":
            if len(self.SECRET_KEY) < 32 or self.SECRET_KEY in {
                "development_secret_key_change_before_production",
                "change-me",
            }:
                raise RuntimeError("SECRET_KEY must be a strong, unique value in production")
            if any(str(v).lower() == "mock" for v in [self.AADHAAR_PROVIDER, self.DIGILOCKER_PROVIDER, self.OTP_PROVIDER]):
                raise RuntimeError("Mock identity/OTP providers cannot be enabled in production")
            if "localhost" in self.CORS_ORIGINS or "127.0.0.1" in self.CORS_ORIGINS:
                raise RuntimeError("Production CORS_ORIGINS must not contain localhost")
        if self.ALGORITHM not in {"HS256", "HS384", "HS512"}:
            raise RuntimeError("Unsupported JWT signing algorithm")
        if not 1 <= self.OTP_MAX_ATTEMPTS <= 10:
            raise RuntimeError("OTP_MAX_ATTEMPTS must be between 1 and 10")


settings = Settings()
settings.validate_runtime()
