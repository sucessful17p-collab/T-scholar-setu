# Import all the models here for Alembic
from app.db.base_class import Base  # noqa

# Import all models here so Alembic can discover them
from app.modules.scheme.models import Scheme, SchemeVersion, EligibilityRule, RequiredDocument, FormField, Benefit, SelectionCriterion, WorkflowRule
from app.modules.identity.models import UserAccount, ApplicantProfile, IdentityVerification
from app.modules.application.models import Application
from app.modules.document.models import ApplicationDocument
from app.modules.eligibility.models import EligibilityEvaluation, EligibilityRuleResult
from app.modules.audit.models import AuditLog
from app.modules.verification.models import VerificationAssignment, VerificationAction

from app.modules.selection.models import SelectionRun, SelectionResult
from app.modules.payment.models import PaymentOrder
from app.modules.notification.models import Notification
from app.modules.grievance.models import GrievanceTicket
from app.modules.rag_assistant.models import KnowledgeDocument
