import time
import uuid
from collections import defaultdict, deque

from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import text
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

from app.core.config import settings
from app.db.session import SessionLocal

from app.modules.scheme.router import router as scheme_router
from app.modules.identity.router import router as identity_router
from app.modules.identity.admin_demo_router import router as admin_demo_router
from app.modules.application.router import router as application_router
from app.modules.document.router import router as document_router
from app.modules.eligibility.router import router as eligibility_router
from app.modules.verification.router import router as verification_router
from app.modules.selection.router import router as selection_router
from app.modules.payment.router import router as payment_router
from app.modules.notification.router import router as notification_router
from app.modules.grievance.router import router as grievance_router
from app.modules.rag_assistant.router import router as rag_router
from app.modules.analytics.router import router as analytics_router
from app.modules.admin.router import router as admin_router
from app.modules.security.router import router as security_router

app = FastAPI(
    title=settings.PROJECT_NAME,
    version="1.0.0",
    openapi_url=f"{settings.API_V1_STR}/openapi.json"
    if settings.ENVIRONMENT.lower() != "production"
    else None,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=False,
    allow_methods=["GET", "POST", "PATCH", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "X-Request-ID"],
)


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        request_id = request.headers.get("X-Request-ID") or uuid.uuid4().hex
        response = await call_next(request)

        response.headers["X-Request-ID"] = request_id
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"

        response.headers["Cache-Control"] = (
            "no-store"
            if request.url.path.startswith(settings.API_V1_STR)
            else response.headers.get("Cache-Control", "no-cache")
        )

        if settings.ENVIRONMENT.lower() == "production":
            response.headers["Strict-Transport-Security"] = (
                "max-age=31536000; includeSubDomains"
            )

        return response


class RateLimitMiddleware(BaseHTTPMiddleware):
    def __init__(self, app):
        super().__init__(app)
        self.hits = defaultdict(deque)
        self.max_keys = 10000

    async def dispatch(self, request: Request, call_next):
        if request.url.path in {
            "/health",
            f"{settings.API_V1_STR}/openapi.json",
        }:
            return await call_next(request)

        client = request.client.host if request.client else "unknown"
        key = f"{client}:{request.method}:{request.url.path}"
        now = time.monotonic()

        if key not in self.hits and len(self.hits) >= self.max_keys:
            oldest_key = min(
                self.hits,
                key=lambda k: self.hits[k][-1] if self.hits[k] else 0,
            )
            self.hits.pop(oldest_key, None)

        q = self.hits[key]

        while q and now - q[0] > 60:
            q.popleft()

        if len(q) >= settings.RATE_LIMIT_PER_MINUTE:
            return JSONResponse(
                status_code=429,
                content={"detail": "Rate limit exceeded"},
            )

        q.append(now)

        return await call_next(request)


app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(RateLimitMiddleware)


app.include_router(
    scheme_router,
    prefix=settings.API_V1_STR,
)

app.include_router(
    identity_router,
    prefix=f"{settings.API_V1_STR}/identity",
    tags=["Identity"],
)

app.include_router(
    admin_demo_router,
    prefix=f"{settings.API_V1_STR}/identity",
    tags=["Identity"],
)

app.include_router(
    application_router,
    prefix=f"{settings.API_V1_STR}/applications",
    tags=["Application"],
)

app.include_router(
    document_router,
    prefix=f"{settings.API_V1_STR}",
    tags=["Document"],
)

app.include_router(
    eligibility_router,
    prefix=f"{settings.API_V1_STR}",
    tags=["Eligibility"],
)

app.include_router(
    verification_router,
    prefix=f"{settings.API_V1_STR}",
)

app.include_router(
    selection_router,
    prefix=f"{settings.API_V1_STR}",
)

app.include_router(
    payment_router,
    prefix=f"{settings.API_V1_STR}",
)

app.include_router(
    notification_router,
    prefix=f"{settings.API_V1_STR}",
)

app.include_router(
    grievance_router,
    prefix=f"{settings.API_V1_STR}",
)

app.include_router(
    rag_router,
    prefix=f"{settings.API_V1_STR}",
)

app.include_router(
    analytics_router,
    prefix=f"{settings.API_V1_STR}",
)

app.include_router(
    admin_router,
    prefix=f"{settings.API_V1_STR}",
)

app.include_router(
    security_router,
    prefix=f"{settings.API_V1_STR}",
)


def get_db():
    db = SessionLocal()

    try:
        yield db
    finally:
        db.close()


from fastapi.staticfiles import StaticFiles

@app.get("/health")
def health_check(db: Session = Depends(get_db)):
    try:
        db.execute(text("SELECT 1"))

        return {
            "status": "ok",
            "database": "connected",
            "version": "1.0.0",
        }

    except Exception:
        raise HTTPException(
            status_code=503,
            detail="Database connection failed",
        )

# Mount frontend at the end to avoid intercepting API routes
import os
base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
frontend_path = os.path.join(base_dir, "frontend")
if os.path.exists(frontend_path):
    app.mount("/app", StaticFiles(directory=frontend_path, html=True), name="frontend")