from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.modules.identity.deps import get_db, get_current_user
from app.modules.identity.models import UserAccount, UserRole
from app.modules.application.models import Application
from app.modules.grievance.models import GrievanceTicket
from app.modules.payment.models import PaymentOrder
from app.modules.selection.models import SelectionRun
from app.modules.rag_assistant.models import KnowledgeDocument

router = APIRouter(prefix="/admin", tags=["Admin Dashboard"])

def admin(user):
    if user.role != UserRole.ADMIN: raise HTTPException(403, "Admin access required")
    return user

@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db), user: UserAccount = Depends(get_current_user)):
    admin(user)
    return {
        "counts": {
            "applications": db.query(Application).count(),
            "grievances": db.query(GrievanceTicket).count(),
            "payments": db.query(PaymentOrder).count(),
            "selection_runs": db.query(SelectionRun).count(),
            "knowledge_documents": db.query(KnowledgeDocument).count(),
        },
        "quick_links": {
            "applications": "/api/v1/applications/",
            "selection_runs": "/api/v1/selection/runs",
            "payments": "/api/v1/payments/",
            "grievances": "/api/v1/grievances/",
            "analytics": "/api/v1/analytics/overview",
        }
    }
