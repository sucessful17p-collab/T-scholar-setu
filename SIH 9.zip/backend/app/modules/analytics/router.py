from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session
from app.modules.identity.deps import get_db, get_current_user
from app.modules.identity.models import UserAccount, UserRole
from app.modules.application.models import Application, ApplicationStatus
from app.modules.payment.models import PaymentOrder, PaymentStatus
from app.modules.grievance.models import GrievanceTicket, GrievanceStatus
from app.modules.selection.models import SelectionResult, SelectionDecision

router = APIRouter(prefix="/analytics", tags=["Analytics / MIS"])

def admin_only(user):
    if user.role != UserRole.ADMIN: raise HTTPException(403, "Admin access required")
    return user

@router.get("/overview")
def overview(db: Session = Depends(get_db), user: UserAccount = Depends(get_current_user)):
    admin_only(user)
    app_counts = {s.value: db.query(Application).filter(Application.status == s).count() for s in ApplicationStatus}
    return {
        "applications": app_counts,
        "payments": {
            "total": db.query(PaymentOrder).count(),
            "paid": db.query(PaymentOrder).filter(PaymentOrder.status == PaymentStatus.PAID).count(),
            "paid_amount": db.query(func.coalesce(func.sum(PaymentOrder.amount), 0)).filter(PaymentOrder.status == PaymentStatus.PAID).scalar(),
        },
        "grievances": {
            "open": db.query(GrievanceTicket).filter(GrievanceTicket.status.in_([GrievanceStatus.OPEN, GrievanceStatus.IN_PROGRESS])).count(),
            "resolved": db.query(GrievanceTicket).filter(GrievanceTicket.status == GrievanceStatus.RESOLVED).count(),
        },
        "selection": {
            "selected": db.query(SelectionResult).filter(SelectionResult.decision == SelectionDecision.SELECTED).count()
        }
    }

@router.get("/schemes/{scheme_version_id}")
def scheme_metrics(scheme_version_id: int, db: Session = Depends(get_db), user: UserAccount = Depends(get_current_user)):
    admin_only(user)
    total = db.query(Application).filter(Application.scheme_version_id == scheme_version_id).count()
    by_status = {}
    for status in ApplicationStatus:
        by_status[status.value] = db.query(Application).filter(
            Application.scheme_version_id == scheme_version_id, Application.status == status
        ).count()
    return {"scheme_version_id": scheme_version_id, "total": total, "by_status": by_status}
