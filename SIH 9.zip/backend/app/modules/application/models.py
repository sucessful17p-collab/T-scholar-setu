import enum
from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Enum
from sqlalchemy.types import JSON
from sqlalchemy.orm import relationship

from app.db.base_class import Base

class ApplicationStatus(str, enum.Enum):
    DRAFT = "DRAFT"
    SUBMITTED = "SUBMITTED"
    IN_REVIEW = "IN_REVIEW"
    DEFECTIVE = "DEFECTIVE"
    VERIFIED = "VERIFIED"
    REJECTED = "REJECTED"

class Application(Base):
    __tablename__ = "applications"
    
    id = Column(Integer, primary_key=True, index=True)
    application_number = Column(String, unique=True, index=True, nullable=False)
    
    applicant_profile_id = Column(Integer, ForeignKey("applicant_profiles.id"), nullable=False)
    scheme_version_id = Column(Integer, ForeignKey("scheme_versions.id"), nullable=False)
    
    status = Column(Enum(ApplicationStatus), default=ApplicationStatus.DRAFT, nullable=False)
    
    form_data = Column(JSON, nullable=True, default=dict)
    
    submitted_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    applicant_profile = relationship("ApplicantProfile", foreign_keys=[applicant_profile_id])
    scheme_version = relationship("SchemeVersion", foreign_keys=[scheme_version_id])
