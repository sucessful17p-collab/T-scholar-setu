from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.modules.application.schemas import ApplicationCreate, ApplicationUpdate, ApplicationResponse
from app.modules.application.services import application_service
from app.modules.identity.models import UserAccount
from app.modules.identity.deps import get_db, get_current_user

router = APIRouter()

@router.post("/", response_model=ApplicationResponse, status_code=status.HTTP_201_CREATED)
def create_application(
    data: ApplicationCreate,
    db: Session = Depends(get_db),
    current_user: UserAccount = Depends(get_current_user)
):
    if not current_user.profile:
        raise HTTPException(status_code=400, detail="Applicant profile is missing")
    return application_service.create_draft(db, current_user.profile.id, data)

@router.get("/", response_model=List[ApplicationResponse])
def list_applications(
    db: Session = Depends(get_db),
    current_user: UserAccount = Depends(get_current_user)
):
    if not current_user.profile:
        return []
    return application_service.list_applications(db, current_user.profile.id)

@router.get("/{application_id}", response_model=ApplicationResponse)
def get_application(
    application_id: int,
    db: Session = Depends(get_db),
    current_user: UserAccount = Depends(get_current_user)
):
    if not current_user.profile:
        raise HTTPException(status_code=400, detail="Applicant profile is missing")
    return application_service.get_application(db, application_id, current_user.profile.id)

@router.patch("/{application_id}", response_model=ApplicationResponse)
def update_application(
    application_id: int,
    data: ApplicationUpdate,
    db: Session = Depends(get_db),
    current_user: UserAccount = Depends(get_current_user)
):
    if not current_user.profile:
        raise HTTPException(status_code=400, detail="Applicant profile is missing")
    return application_service.update_draft(db, application_id, current_user.profile.id, data)

@router.post("/{application_id}/submit", response_model=ApplicationResponse)
def submit_application(
    application_id: int,
    db: Session = Depends(get_db),
    current_user: UserAccount = Depends(get_current_user)
):
    if not current_user.profile:
        raise HTTPException(status_code=400, detail="Applicant profile is missing")
    return application_service.submit_application(db, application_id, current_user.profile.id)
