from pydantic import BaseModel, Field
from typing import Optional, Dict, Any
from datetime import datetime
from app.modules.application.models import ApplicationStatus

class ApplicationCreate(BaseModel):
    scheme_version_id: int
    form_data: Optional[Dict[str, Any]] = Field(default_factory=dict)

class ApplicationUpdate(BaseModel):
    form_data: Optional[Dict[str, Any]] = None

class ApplicationResponse(BaseModel):
    id: int
    application_number: str
    applicant_profile_id: int
    scheme_version_id: int
    status: ApplicationStatus
    form_data: Dict[str, Any]
    submitted_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
