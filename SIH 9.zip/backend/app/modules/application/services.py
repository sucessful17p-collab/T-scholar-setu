import uuid
from typing import List, Optional
from datetime import datetime
from sqlalchemy.orm import Session
from fastapi import HTTPException

from app.modules.application.models import Application, ApplicationStatus
from app.modules.application.schemas import ApplicationCreate, ApplicationUpdate
from app.modules.scheme.models import SchemeVersion
from app.modules.document.models import ApplicationDocument

class ApplicationService:

    def _generate_application_number(self) -> str:
        date_str = datetime.utcnow().strftime("%Y%m%d")
        random_str = uuid.uuid4().hex[:8].upper()
        return f"APP-{date_str}-{random_str}"

    def create_draft(self, db: Session, profile_id: int, data: ApplicationCreate) -> Application:
        # Verify SchemeVersion exists and is active
        scheme_version = db.query(SchemeVersion).filter(SchemeVersion.id == data.scheme_version_id).first()
        if not scheme_version:
            raise HTTPException(status_code=404, detail="Scheme Version not found")
        
        if not scheme_version.is_active:
            raise HTTPException(status_code=400, detail="Scheme Version is not active")

        # Create application
        app = Application(
            application_number=self._generate_application_number(),
            applicant_profile_id=profile_id,
            scheme_version_id=scheme_version.id,
            status=ApplicationStatus.DRAFT,
            form_data=data.form_data or {}
        )
        db.add(app)
        db.commit()
        db.refresh(app)
        return app

    def list_applications(self, db: Session, profile_id: int) -> List[Application]:
        return db.query(Application).filter(Application.applicant_profile_id == profile_id).all()

    def get_application(self, db: Session, app_id: int, profile_id: int) -> Application:
        app = db.query(Application).filter(Application.id == app_id).first()
        if not app:
            raise HTTPException(status_code=404, detail="Application not found")
        if app.applicant_profile_id != profile_id:
            raise HTTPException(status_code=403, detail="Not authorized to access this application")
        return app

    def update_draft(self, db: Session, app_id: int, profile_id: int, data: ApplicationUpdate) -> Application:
        app = self.get_application(db, app_id, profile_id)
        
        if app.status not in [ApplicationStatus.DRAFT, ApplicationStatus.DEFECTIVE]:
            raise HTTPException(status_code=400, detail="Only DRAFT or DEFECTIVE applications can be updated")
            
        if data.form_data is not None:
            app.form_data = data.form_data
            
        db.commit()
        db.refresh(app)
        return app

    def submit_application(self, db: Session, app_id: int, profile_id: int) -> Application:
        from app.modules.eligibility.engine import evaluate_application
        from app.modules.eligibility.models import EligibilityOverallStatus
        from app.modules.audit.services import audit_service
        from app.modules.verification.services import verification_service
        
        app = self.get_application(db, app_id, profile_id)
        
        if app.status not in [ApplicationStatus.DRAFT, ApplicationStatus.DEFECTIVE]:
            raise HTTPException(status_code=400, detail="Application is already submitted or in an invalid state")
            
        scheme_version = app.scheme_version
        if not scheme_version:
            raise HTTPException(status_code=500, detail="Linked Scheme Version not found")

        missing_fields = []
        for field in scheme_version.form_fields:
            if field.is_mandatory:
                if field.field_name not in app.form_data or app.form_data[field.field_name] is None or app.form_data[field.field_name] == "":
                    missing_fields.append(field.field_name)
                    
        if missing_fields:
            raise HTTPException(status_code=400, detail=f"Missing required fields: {', '.join(missing_fields)}")
            
        mandatory_docs = [doc for doc in scheme_version.required_documents if doc.is_mandatory]
        if mandatory_docs:
            uploaded_doc_ids = {
                d.required_document_id for d in db.query(ApplicationDocument.required_document_id)
                .filter(ApplicationDocument.application_id == app_id)
                .filter(ApplicationDocument.required_document_id.isnot(None))
                .all()
            }
            missing_docs = [doc.document_name for doc in mandatory_docs if doc.id not in uploaded_doc_ids]
            if missing_docs:
                raise HTTPException(status_code=400, detail=f"Missing required documents: {', '.join(missing_docs)}")
            
        old_status = app.status
        app.status = ApplicationStatus.SUBMITTED
        app.submitted_at = datetime.utcnow()
        
        audit_service.log_action(
            db=db,
            action="APPLICATION_SUBMITTED",
            entity_type="Application",
            entity_id=app.id,
            actor_id=profile_id,
            old_status=old_status.value,
            new_status=app.status.value
        )
        
        # Phase 7: Evaluate Eligibility automatically
        evaluation = evaluate_application(db, app, scheme_version)
        audit_service.log_action(
            db=db,
            action="ELIGIBILITY_EVALUATED",
            entity_type="Application",
            entity_id=app.id,
            metadata={"overall_status": evaluation.overall_status.value}
        )
        
        if evaluation.overall_status == EligibilityOverallStatus.NOT_ELIGIBLE:
            app.status = ApplicationStatus.REJECTED
            audit_service.log_action(
                db=db,
                action="APPLICATION_REJECTED_ELIGIBILITY",
                entity_type="Application",
                entity_id=app.id,
                old_status=ApplicationStatus.SUBMITTED.value,
                new_status=ApplicationStatus.REJECTED.value,
                metadata={"reason": "Failed eligibility check"}
            )
        elif evaluation.overall_status == EligibilityOverallStatus.INCOMPLETE:
            # We don't save, just throw an exception so they fix it
            db.rollback()
            raise HTTPException(status_code=400, detail="Eligibility check failed due to incomplete data")
        else:
            # ELIGIBLE -> Start verification workflow
            verification_service.start_verification_workflow(db, app)
        
        db.commit()
        db.refresh(app)
        return app

application_service = ApplicationService()
