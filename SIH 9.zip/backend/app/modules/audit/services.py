from typing import Any, Dict, Optional
from sqlalchemy.orm import Session
from app.modules.audit.models import AuditLog

class AuditService:
    def log_action(
        self,
        db: Session,
        action: str,
        entity_type: str,
        entity_id: int,
        actor_id: Optional[int] = None,
        old_status: Optional[str] = None,
        new_status: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> AuditLog:
        log = AuditLog(
            actor_id=actor_id,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            old_status=old_status,
            new_status=new_status,
            metadata_json=metadata or {}
        )
        db.add(log)
        db.flush()
        return log

audit_service = AuditService()
