from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship

from app.db.base_class import Base

class ApplicationDocument(Base):
    __tablename__ = "application_documents"
    
    id = Column(Integer, primary_key=True, index=True)
    application_id = Column(Integer, ForeignKey("applications.id"), nullable=False)
    required_document_id = Column(Integer, ForeignKey("required_documents.id"), nullable=True)
    
    original_filename = Column(String, nullable=False)
    storage_key = Column(String, unique=True, index=True, nullable=False)
    mime_type = Column(String, nullable=False)
    file_size = Column(Integer, nullable=False)
    
    uploaded_at = Column(DateTime, default=datetime.utcnow)

    # Relationships (Optional but good for ORM)
    application = relationship("Application", foreign_keys=[application_id])
    required_document = relationship("RequiredDocument", foreign_keys=[required_document_id])
