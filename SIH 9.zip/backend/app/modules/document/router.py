import os
from typing import List, Optional
from fastapi import APIRouter, Depends, UploadFile, File, Form
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.modules.identity.deps import get_current_user, get_db
from app.modules.identity.models import UserAccount
from app.modules.document.schemas import DocumentResponse
from app.modules.document.services import DocumentService
from app.modules.document.storage import get_storage_provider, StorageProvider

router = APIRouter()

def get_document_service(storage: StorageProvider = Depends(get_storage_provider)) -> DocumentService:
    return DocumentService(storage_provider=storage)

@router.post("/applications/{application_id}/documents/", response_model=DocumentResponse)
def upload_document(
    application_id: int,
    required_document_id: Optional[int] = Form(None),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: UserAccount = Depends(get_current_user),
    service: DocumentService = Depends(get_document_service)
):
    profile_id = current_user.profile.id
    doc = service.upload_document(
        db=db,
        profile_id=profile_id,
        application_id=application_id,
        file=file,
        required_document_id=required_document_id
    )
    return doc

@router.get("/applications/{application_id}/documents/", response_model=List[DocumentResponse])
def list_documents(
    application_id: int,
    db: Session = Depends(get_db),
    current_user: UserAccount = Depends(get_current_user),
    service: DocumentService = Depends(get_document_service)
):
    profile_id = current_user.profile.id
    return service.list_documents(db, profile_id, application_id)

@router.delete("/documents/{document_id}")
def delete_document(
    document_id: int,
    db: Session = Depends(get_db),
    current_user: UserAccount = Depends(get_current_user),
    service: DocumentService = Depends(get_document_service)
):
    profile_id = current_user.profile.id
    service.delete_document(db, profile_id, document_id)
    return {"detail": "Document deleted successfully"}

@router.get("/documents/{document_id}/download")
def download_document(
    document_id: int,
    db: Session = Depends(get_db),
    current_user: UserAccount = Depends(get_current_user),
    service: DocumentService = Depends(get_document_service)
):
    profile_id = current_user.profile.id
    file_path = service.get_document_path(db, profile_id, document_id)
    doc = service.get_document(db, profile_id, document_id)
    
    if not os.path.exists(file_path):
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="File not found on storage")
        
    return FileResponse(
        path=file_path,
        filename=doc.original_filename,
        media_type=doc.mime_type
    )
