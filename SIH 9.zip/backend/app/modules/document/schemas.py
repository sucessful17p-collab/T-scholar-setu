from datetime import datetime
from typing import Optional
from pydantic import BaseModel, ConfigDict


class DocumentResponse(BaseModel):
    id: int
    application_id: int
    required_document_id: Optional[int] = None
    
    original_filename: str
    mime_type: str
    file_size: int
    uploaded_at: datetime
    
    model_config = ConfigDict(from_attributes=True)
