import os
import uuid
from typing import List, Optional
from fastapi import UploadFile, HTTPException
from sqlalchemy.orm import Session

from app.core.config import settings
from app.modules.application.models import Application, ApplicationStatus
from app.modules.document.models import ApplicationDocument
from app.modules.document.storage import StorageProvider
from app.modules.scheme.models import RequiredDocument

ALLOWED_MIME_TYPES = {"application/pdf", "image/jpeg", "image/png"}
MAGIC_HEADERS = {
    "application/pdf": (b"%PDF-",),
    "image/jpeg": (b"\\xff\\xd8\\xff",),
    "image/png": (b"\\x89PNG\\r\\n\\x1a\\n",),
}
MAX_FILE_SIZE_BYTES = settings.DOCUMENT_MAX_SIZE_MB * 1024 * 1024

class DocumentService:
    def __init__(self, storage_provider: StorageProvider):
        self.storage_provider = storage_provider

    def _verify_application_access(self, db: Session, application_id: int, profile_id: int, require_draft: bool = False) -> Application:
        app = db.query(Application).filter(Application.id == application_id).first()
        if not app:
            raise HTTPException(status_code=404, detail="Application not found")
        
        if app.applicant_profile_id != profile_id:
            raise HTTPException(status_code=403, detail="Not authorized to access this application")
            
        if require_draft and app.status not in [ApplicationStatus.DRAFT, ApplicationStatus.DEFECTIVE]:
            raise HTTPException(status_code=400, detail="Documents can only be modified for DRAFT or DEFECTIVE applications")
            
        return app

    def upload_document(
        self, 
        db: Session, 
        profile_id: int, 
        application_id: int, 
        file: UploadFile, 
        required_document_id: Optional[int] = None
    ) -> ApplicationDocument:
        # 1. Verify Application
        app = self._verify_application_access(db, application_id, profile_id, require_draft=True)
        
        # 2. Validate declared type, size, and file signature. MIME type alone is
        # attacker-controlled, so the first bytes must match the declared type too.
        content_type = (file.content_type or "").lower().split(";", 1)[0].strip()
        if content_type not in ALLOWED_MIME_TYPES:
            raise HTTPException(status_code=400, detail="Unsupported file type")

        file.file.seek(0, 2)
        file_size = file.file.tell()
        file.file.seek(0)
        if file_size <= 0 or file_size > MAX_FILE_SIZE_BYTES:
            raise HTTPException(status_code=400, detail="Invalid file size or file exceeds the 5MB limit")

        header = file.file.read(16)
        file.file.seek(0)
        if not any(header.startswith(magic) for magic in MAGIC_HEADERS[content_type]):
            raise HTTPException(status_code=400, detail="File content does not match its declared type")

        # Never preserve a user-controlled path or executable-looking extension.
        original_name = os.path.basename(file.filename or "document")
        if original_name in {".", ".."} or any(ord(ch) < 32 for ch in original_name):
            raise HTTPException(status_code=400, detail="Invalid filename")
        extension = {"application/pdf": "pdf", "image/jpeg": "jpg", "image/png": "png"}[content_type]
        # 3. Validate RequiredDocument if provided
        if required_document_id:
            req_doc = db.query(RequiredDocument).filter(
                RequiredDocument.id == required_document_id,
                RequiredDocument.scheme_version_id == app.scheme_version_id
            ).first()
            if not req_doc:
                raise HTTPException(status_code=400, detail="Invalid required_document_id for this scheme version")
        
        # 4. Save file via Storage Adapter
        # Generate safe unique key
        storage_key = f"{uuid.uuid4().hex}.{extension}"
        
        try:
            self.storage_provider.save(file, storage_key)
        except Exception as e:
            raise HTTPException(status_code=500, detail="Failed to store document")
        
        # 5. Persist Metadata to DB
        doc = ApplicationDocument(
            application_id=app.id,
            required_document_id=required_document_id,
            original_filename=original_name,
            storage_key=storage_key,
            mime_type=content_type,
            file_size=file_size
        )
        db.add(doc)
        db.commit()
        db.refresh(doc)
        
        return doc

    def list_documents(self, db: Session, profile_id: int, application_id: int) -> List[ApplicationDocument]:
        self._verify_application_access(db, application_id, profile_id, require_draft=False)
        return db.query(ApplicationDocument).filter(ApplicationDocument.application_id == application_id).all()

    def get_document(self, db: Session, profile_id: int, document_id: int) -> ApplicationDocument:
        doc = db.query(ApplicationDocument).filter(ApplicationDocument.id == document_id).first()
        if not doc:
            raise HTTPException(status_code=404, detail="Document not found")
        
        # Verify access through the application
        self._verify_application_access(db, doc.application_id, profile_id, require_draft=False)
        return doc

    def delete_document(self, db: Session, profile_id: int, document_id: int) -> None:
        doc = self.get_document(db, profile_id, document_id)
        
        # Must be in DRAFT or DEFECTIVE to delete
        self._verify_application_access(db, doc.application_id, profile_id, require_draft=True)
        
        # Delete from storage
        self.storage_provider.delete(doc.storage_key)
        
        # Delete from DB
        db.delete(doc)
        db.commit()

    def get_document_path(self, db: Session, profile_id: int, document_id: int) -> str:
        doc = self.get_document(db, profile_id, document_id)
        return self.storage_provider.get_path(doc.storage_key)
