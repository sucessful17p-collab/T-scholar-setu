import os
import shutil
from abc import ABC, abstractmethod

from fastapi import UploadFile

from app.core.config import settings


class StorageProvider(ABC):
    @abstractmethod
    def save(self, file: UploadFile, storage_key: str) -> None:
        pass

    @abstractmethod
    def delete(self, storage_key: str) -> None:
        pass

    @abstractmethod
    def get_path(self, storage_key: str) -> str:
        pass


class LocalStorageProvider(StorageProvider):
    def __init__(self, base_path: str | None = None):
        self.base_path = base_path or settings.DOCUMENT_STORAGE_PATH
        os.makedirs(self.base_path, mode=0o700, exist_ok=True)

    def _get_full_path(self, storage_key: str) -> str:
        safe_key = os.path.basename(storage_key)
        full_path = os.path.abspath(os.path.join(self.base_path, safe_key))
        base = os.path.abspath(self.base_path)
        if os.path.dirname(full_path) != base:
            raise ValueError("Invalid storage key")
        return full_path

    def save(self, file: UploadFile, storage_key: str) -> None:
        file_path = self._get_full_path(storage_key)
        file.file.seek(0)
        with open(file_path, "xb") as buffer:
            shutil.copyfileobj(file.file, buffer, length=1024 * 1024)
        os.chmod(file_path, 0o600)

    def delete(self, storage_key: str) -> None:
        file_path = self._get_full_path(storage_key)
        if os.path.exists(file_path):
            os.remove(file_path)

    def get_path(self, storage_key: str) -> str:
        return self._get_full_path(storage_key)


def get_storage_provider() -> StorageProvider:
    return LocalStorageProvider()
