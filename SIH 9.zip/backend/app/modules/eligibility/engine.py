from typing import Any, Optional, Dict, Callable
from datetime import date
import json

from sqlalchemy.orm import Session

from app.modules.application.models import Application
from app.modules.scheme.models import SchemeVersion, EligibilityRule, OperatorEnum
from app.modules.identity.models import ApplicantProfile
from app.modules.eligibility.models import (
    EligibilityEvaluation, 
    EligibilityRuleResult, 
    EligibilityOverallStatus, 
    EligibilityRuleResultStatus
)

def get_age(profile: ApplicantProfile, application: Application) -> Optional[int]:
    if not profile or not profile.date_of_birth:
        return None
    today = date.today()
    dob = profile.date_of_birth
    return today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))

# Static Registry mapping rule types to a function that resolves the actual value
RULE_RESOLVERS: Dict[str, Callable[[ApplicantProfile, Application], Any]] = {
    "MAX_INCOME": lambda p, a: p.annual_family_income if p else None,
    "MAX_AGE_MASTERS": get_age,
    "MAX_AGE_PHD": get_age,
    "MAX_AGE_POSTDOC": get_age,
    "CATEGORY": lambda p, a: p.category.value if (p and p.category) else None,
    "MIN_MARKS": lambda p, a: a.form_data.get("marks_percentage") if a.form_data else None,
    "CLASS_ENROLLED": lambda p, a: a.form_data.get("class_enrolled") if a.form_data else None,
}

def evaluate_operator(operator: OperatorEnum, actual_value: Any, expected_value: str) -> bool:
    if actual_value is None:
        return False
        
    # IN operator: expects a JSON list or comma separated string
    if operator == OperatorEnum.IN:
        try:
            expected_list = json.loads(expected_value)
            if not isinstance(expected_list, list):
                expected_list = [x.strip() for x in str(expected_value).split(",")]
        except Exception:
            expected_list = [x.strip() for x in str(expected_value).split(",")]
            
        return str(actual_value) in [str(x) for x in expected_list]
        
    # Handle Numeric vs String comparison
    try:
        if isinstance(actual_value, (int, float)):
            expected_val = float(expected_value)
            actual_val = float(actual_value)
        else:
            expected_val = str(expected_value)
            actual_val = str(actual_value)
    except (ValueError, TypeError):
        expected_val = str(expected_value)
        actual_val = str(actual_value)
        
    if operator == OperatorEnum.EQUALS:
        return actual_val == expected_val
    elif operator == OperatorEnum.GREATER_THAN:
        return actual_val > expected_val
    elif operator == OperatorEnum.LESS_THAN:
        return actual_val < expected_val
    elif operator == OperatorEnum.GREATER_EQUALS:
        return actual_val >= expected_val
    elif operator == OperatorEnum.LESS_EQUALS:
        return actual_val <= expected_val
        
    return False

def evaluate_application(db: Session, application: Application, scheme_version: SchemeVersion) -> EligibilityEvaluation:
    profile = application.applicant_profile
    
    evaluation = EligibilityEvaluation(
        application_id=application.id,
        scheme_version_id=scheme_version.id,
        overall_status=EligibilityOverallStatus.ELIGIBLE # Assume eligible until proven otherwise
    )
    
    has_failed = False
    has_unknown = False
    
    rule_results = []
    
    for rule in scheme_version.eligibility_rules:
        # Resolve the actual value safely using the registry
        resolver = RULE_RESOLVERS.get(rule.rule_type)
        if resolver is None:
            # If we encounter an unknown rule type, we can't safely evaluate it.
            # Treat it as UNKNOWN (or FAIL depending on strictness, UNKNOWN is safer).
            result_status = EligibilityRuleResultStatus.UNKNOWN
            actual_value = None
            explanation = f"Unsupported rule type: {rule.rule_type}. Please configure the engine."
        else:
            try:
                actual_value = resolver(profile, application)
                
                if actual_value is None:
                    result_status = EligibilityRuleResultStatus.UNKNOWN
                    explanation = f"Required data for {rule.rule_type} is missing."
                else:
                    passed = evaluate_operator(rule.operator, actual_value, rule.value)
                    if passed:
                        result_status = EligibilityRuleResultStatus.PASS
                        explanation = f"Condition met: {actual_value} {rule.operator.value} {rule.value}"
                    else:
                        result_status = EligibilityRuleResultStatus.FAIL
                        explanation = f"Condition failed: {actual_value} does not satisfy {rule.operator.value} {rule.value}"
            except Exception:
                result_status = EligibilityRuleResultStatus.UNKNOWN
                actual_value = None
                explanation = "This eligibility rule could not be evaluated with the available data."
                
        # Track roll-up status
        if result_status == EligibilityRuleResultStatus.FAIL:
            has_failed = True
        elif result_status == EligibilityRuleResultStatus.UNKNOWN:
            has_unknown = True
            
        rule_results.append(EligibilityRuleResult(
            eligibility_rule_id=rule.id,
            result=result_status,
            actual_value=actual_value,
            expected_value=rule.value,
            explanation=explanation
        ))

    # Compute overall status based on precedence: FAIL > UNKNOWN > PASS
    if has_failed:
        evaluation.overall_status = EligibilityOverallStatus.NOT_ELIGIBLE
    elif has_unknown:
        evaluation.overall_status = EligibilityOverallStatus.INCOMPLETE
    else:
        evaluation.overall_status = EligibilityOverallStatus.ELIGIBLE
        
    db.add(evaluation)
    db.flush() # flush to get evaluation.id
    
    for result in rule_results:
        result.evaluation_id = evaluation.id
        db.add(result)
        
    # The caller owns the transaction. This is important when submission needs
    # to roll back after an incomplete eligibility evaluation.
    db.flush()
    return evaluation
