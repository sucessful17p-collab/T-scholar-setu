import enum
from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Enum
from sqlalchemy.types import JSON
from sqlalchemy.orm import relationship

from app.db.base_class import Base

class EligibilityOverallStatus(str, enum.Enum):
    ELIGIBLE = "ELIGIBLE"
    NOT_ELIGIBLE = "NOT_ELIGIBLE"
    INCOMPLETE = "INCOMPLETE"

class EligibilityRuleResultStatus(str, enum.Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    UNKNOWN = "UNKNOWN"

class EligibilityEvaluation(Base):
    __tablename__ = "eligibility_evaluations"
    
    id = Column(Integer, primary_key=True, index=True)
    application_id = Column(Integer, ForeignKey("applications.id"), nullable=False, index=True)
    scheme_version_id = Column(Integer, ForeignKey("scheme_versions.id"), nullable=False)
    
    overall_status = Column(Enum(EligibilityOverallStatus), nullable=False)
    
    evaluated_at = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    application = relationship("Application", foreign_keys=[application_id])
    scheme_version = relationship("SchemeVersion", foreign_keys=[scheme_version_id])
    rule_results = relationship("EligibilityRuleResult", back_populates="evaluation", cascade="all, delete-orphan")


class EligibilityRuleResult(Base):
    __tablename__ = "eligibility_rule_results"
    
    id = Column(Integer, primary_key=True, index=True)
    evaluation_id = Column(Integer, ForeignKey("eligibility_evaluations.id"), nullable=False, index=True)
    eligibility_rule_id = Column(Integer, ForeignKey("eligibility_rules.id"), nullable=False)
    
    result = Column(Enum(EligibilityRuleResultStatus), nullable=False)
    
    # Store dynamic values. JSON allows flexible storage of strings, numbers, lists
    actual_value = Column(JSON, nullable=True)
    expected_value = Column(JSON, nullable=True)
    explanation = Column(String, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    
    evaluation = relationship("EligibilityEvaluation", back_populates="rule_results")
    eligibility_rule = relationship("EligibilityRule", foreign_keys=[eligibility_rule_id])
