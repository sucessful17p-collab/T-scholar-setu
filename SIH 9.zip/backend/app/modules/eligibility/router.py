from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.modules.identity.deps import get_db, get_current_user
from app.modules.identity.models import UserAccount, UserRole
from app.modules.application.models import Application
from app.modules.eligibility.models import EligibilityEvaluation
from app.modules.eligibility.schemas import EligibilityEvaluationResponse
from app.modules.eligibility.engine import evaluate_application

router = APIRouter(
    prefix="/applications",
    tags=["eligibility"]
)

@router.post("/{application_id}/eligibility/evaluate", response_model=EligibilityEvaluationResponse)
def evaluate_eligibility(
    application_id: int,
    db: Session = Depends(get_db),
    current_user: UserAccount = Depends(get_current_user)
):
    application = db.query(Application).filter(Application.id == application_id).first()
    if not application:
        raise HTTPException(status_code=404, detail="Application not found")
        
    if current_user.role == UserRole.APPLICANT and application.applicant_profile.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to evaluate this application")

    scheme_version = application.scheme_version
    if not scheme_version:
        raise HTTPException(status_code=400, detail="Application is not attached to a valid scheme version")
        
    evaluation = evaluate_application(db, application, scheme_version)
    db.commit()
    db.refresh(evaluation)
    return evaluation


@router.get("/{application_id}/eligibility", response_model=EligibilityEvaluationResponse)
def get_eligibility(
    application_id: int,
    db: Session = Depends(get_db),
    current_user: UserAccount = Depends(get_current_user)
):
    application = db.query(Application).filter(Application.id == application_id).first()
    if not application:
        raise HTTPException(status_code=404, detail="Application not found")
        
    if current_user.role == UserRole.APPLICANT and application.applicant_profile.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to view this application's eligibility")

    # Get the latest evaluation
    evaluation = db.query(EligibilityEvaluation)\
        .filter(EligibilityEvaluation.application_id == application_id)\
        .order_by(EligibilityEvaluation.created_at.desc())\
        .first()
        
    if not evaluation:
        raise HTTPException(status_code=404, detail="No eligibility evaluation found for this application")
        
    return evaluation
