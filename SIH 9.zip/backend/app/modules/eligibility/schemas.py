from pydantic import BaseModel, ConfigDict
from typing import List, Optional, Any
from datetime import datetime

from app.modules.eligibility.models import EligibilityOverallStatus, EligibilityRuleResultStatus

class EligibilityRuleResultResponse(BaseModel):
    id: int
    eligibility_rule_id: int
    result: EligibilityRuleResultStatus
    actual_value: Optional[Any] = None
    expected_value: Optional[Any] = None
    explanation: Optional[str] = None
    created_at: datetime
    
    model_config = ConfigDict(from_attributes=True)


class EligibilityEvaluationResponse(BaseModel):
    id: int
    application_id: int
    scheme_version_id: int
    overall_status: EligibilityOverallStatus
    evaluated_at: datetime
    rule_results: List[EligibilityRuleResultResponse]
    
    model_config = ConfigDict(from_attributes=True)
