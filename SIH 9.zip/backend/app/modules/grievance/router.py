import uuid
from datetime import datetime
from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.modules.identity.deps import get_db, get_current_user
from app.modules.identity.models import UserAccount, UserRole
from app.modules.grievance.models import GrievanceTicket, GrievanceStatus
from app.modules.grievance.schemas import GrievanceCreate, GrievanceUpdate, GrievanceResponse

router = APIRouter(prefix="/grievances", tags=["Grievance"])

@router.post("/", response_model=GrievanceResponse, status_code=201)
def create(data: GrievanceCreate, db: Session = Depends(get_db), user: UserAccount = Depends(get_current_user)):
    payload = data.model_dump()
    if user.role == UserRole.APPLICANT and payload.get("application_id") is not None:
        from app.modules.application.models import Application
        app = db.query(Application).filter(Application.id == payload["application_id"]).first()
        if not app or not user.profile or app.applicant_profile_id != user.profile.id:
            raise HTTPException(403, "Not authorized to create a grievance for this application")
    ticket = GrievanceTicket(
        ticket_number=f"GRV-{datetime.utcnow():%Y%m%d}-{uuid.uuid4().hex[:8].upper()}",
        user_id=user.id, **payload
    )
    db.add(ticket); db.commit(); db.refresh(ticket)
    return ticket

@router.get("/me", response_model=List[GrievanceResponse])
def mine(db: Session = Depends(get_db), user: UserAccount = Depends(get_current_user)):
    return db.query(GrievanceTicket).filter(GrievanceTicket.user_id == user.id).order_by(GrievanceTicket.created_at.desc()).all()

@router.get("/", response_model=List[GrievanceResponse])
def all_tickets(db: Session = Depends(get_db), user: UserAccount = Depends(get_current_user)):
    if user.role == UserRole.APPLICANT: raise HTTPException(403, "Admin access required")
    return db.query(GrievanceTicket).order_by(GrievanceTicket.created_at.desc()).all()

@router.patch("/{ticket_id}", response_model=GrievanceResponse)
def update(ticket_id: int, data: GrievanceUpdate, db: Session = Depends(get_db), user: UserAccount = Depends(get_current_user)):
    ticket = db.query(GrievanceTicket).filter(GrievanceTicket.id == ticket_id).first()
    if not ticket: raise HTTPException(404, "Grievance not found")
    if user.role == UserRole.APPLICANT and ticket.user_id != user.id: raise HTTPException(403, "Not authorized")
    if user.role == UserRole.APPLICANT:
        # Applicants may close their own ticket, but cannot assign staff or alter
        # internal resolution data.
        if data.status not in [GrievanceStatus.CLOSED, None] or data.assigned_to is not None or data.resolution_note is not None:
            raise HTTPException(403, "Applicants cannot modify staff workflow fields")
    for k,v in data.model_dump(exclude_unset=True).items():
        setattr(ticket, k, v)
    if ticket.status == GrievanceStatus.RESOLVED and ticket.resolved_at is None:
        ticket.resolved_at = datetime.utcnow()
    db.commit(); db.refresh(ticket)
    return ticket
