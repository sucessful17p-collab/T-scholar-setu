from datetime import datetime
from typing import Optional
from pydantic import BaseModel, ConfigDict
from app.modules.grievance.models import GrievancePriority, GrievanceStatus

class GrievanceCreate(BaseModel):
    application_id: Optional[int] = None
    category: str
    subject: str
    description: str
    priority: GrievancePriority = GrievancePriority.MEDIUM

class GrievanceUpdate(BaseModel):
    status: Optional[GrievanceStatus] = None
    assigned_to: Optional[int] = None
    resolution_note: Optional[str] = None

class GrievanceResponse(BaseModel):
    id: int
    ticket_number: str
    user_id: int
    application_id: Optional[int]
    category: str
    subject: str
    description: str
    priority: GrievancePriority
    status: GrievanceStatus
    assigned_to: Optional[int]
    resolution_note: Optional[str]
    created_at: datetime
    updated_at: datetime
    resolved_at: Optional[datetime]
    model_config = ConfigDict(from_attributes=True)
