# Identity adapters module
