from abc import ABC, abstractmethod
from typing import Dict, Any

class IdentityProviderBase(ABC):
    
    @abstractmethod
    def verify_identity(self, document_id: str) -> Dict[str, Any]:
        """
        Takes a raw document ID (e.g. Aadhaar number) and returns a verification result.
        Must return a dict containing at least:
        - 'is_verified': bool
        - 'reference_id': str (an opaque token representing this verification event)
        - optionally other non-sensitive profile data (name, dob)
        """
        pass
