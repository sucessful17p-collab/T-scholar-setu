from app.core.config import settings
from .base import IdentityProviderBase
from .mock_aadhaar import MockAadhaarAdapter
from .mock_digilocker import MockDigiLockerAdapter

def get_aadhaar_provider() -> IdentityProviderBase:
    provider = settings.AADHAAR_PROVIDER.lower()
    if provider == "mock":
        return MockAadhaarAdapter()
    raise ValueError(f"Unknown Aadhaar provider: {provider}")

def get_digilocker_provider() -> IdentityProviderBase:
    provider = settings.DIGILOCKER_PROVIDER.lower()
    if provider == "mock":
        return MockDigiLockerAdapter()
    raise ValueError(f"Unknown DigiLocker provider: {provider}")

def get_otp_provider():
    from .otp import MockOtpProvider
    provider = settings.OTP_PROVIDER.lower()
    if provider == "mock":
        return MockOtpProvider()
    raise ValueError(f"Unknown OTP provider: {provider}")
