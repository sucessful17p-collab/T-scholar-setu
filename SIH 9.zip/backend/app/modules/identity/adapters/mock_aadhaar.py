import uuid
from typing import Dict, Any
from .base import IdentityProviderBase

class MockAadhaarAdapter(IdentityProviderBase):
    
    def verify_identity(self, document_id: str) -> Dict[str, Any]:
        """
        Mock implementation of Aadhaar verification.
        In a real scenario, this would call the UIDAI/e-KYC API.
        """
        # Simulate validation (e.g. failing if length is not 12)
        if not document_id or len(document_id) != 12 or not document_id.isdigit():
            return {
                "is_verified": False,
                "reference_id": None,
                "error": "Invalid mock Aadhaar format"
            }
            
        return {
            "is_verified": True,
            "reference_id": f"mock_uidai_ref_{uuid.uuid4().hex[:12]}",
            "full_name": "Mock Aadhaar User", # Simulated fetch from KYC
            "gender": "MALE",
        }
