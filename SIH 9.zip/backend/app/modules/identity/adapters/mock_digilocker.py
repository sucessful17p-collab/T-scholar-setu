import uuid
from typing import Dict, Any
from .base import IdentityProviderBase

class MockDigiLockerAdapter(IdentityProviderBase):
    
    def verify_identity(self, document_id: str) -> Dict[str, Any]:
        """
        Mock implementation of DigiLocker verification.
        In a real scenario, this would use OAuth2 to fetch documents from DigiLocker API.
        """
        if not document_id:
            return {
                "is_verified": False,
                "reference_id": None,
                "error": "Invalid mock DigiLocker format"
            }
            
        return {
            "is_verified": True,
            "reference_id": f"mock_dl_ref_{uuid.uuid4().hex[:12]}",
            "full_name": "Mock DigiLocker User",
        }
