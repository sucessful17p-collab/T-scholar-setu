import os
from abc import ABC, abstractmethod

class OtpProviderBase(ABC):
    @abstractmethod
    def send_otp(self, phone_number: str, otp: str) -> None:
        """
        Sends an OTP to the provided phone number.
        """
        pass

class MockOtpProvider(OtpProviderBase):
    def send_otp(self, phone_number: str, otp: str) -> None:
        """
        Mock implementation of OTP delivery.
        Writes the OTP to a purely development/demo file rather than 
        polluting the application logs.
        """
        demo_file = os.path.join(os.getcwd(), ".demo_otps.txt")
        # Development-only provider. Production startup rejects OTP_PROVIDER=mock.
        os.makedirs(os.path.dirname(demo_file) or ".", exist_ok=True)
        if not os.path.exists(demo_file):
            with open(demo_file, "w") as f:
                pass
            os.chmod(demo_file, 0o600)
        with open(demo_file, "a") as f:
            f.write(f"[{phone_number}] OTP: {otp}\n")
