"""Development-only administrator demo login."""

import os

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.security import create_access_token
from app.db.session import SessionLocal
from app.modules.identity.models import UserAccount

router = APIRouter()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/admin-demo", tags=["Identity"])
def admin_demo_login(db: Session = Depends(get_db)):
    environment = os.getenv("ENVIRONMENT", "development").strip().lower()

    if environment in {"production", "prod"}:
        raise HTTPException(status_code=404, detail="Not found")

    demo_phone = os.getenv(
        "DEMO_ADMIN_PHONE",
        "+919876543210",
    ).strip()

    user = (
        db.query(UserAccount)
        .filter(UserAccount.phone_number == demo_phone)
        .first()
    )

    from app.modules.identity.models import UserRole
    if user is None:
        # Auto-create the admin demo user for local testing
        user = UserAccount(phone_number=demo_phone, role=UserRole.ADMIN, failed_otp_attempts=0, is_active=True)
        db.add(user)
        db.commit()
        db.refresh(user)

    role = user.role.value if hasattr(user.role, "value") else str(user.role).upper()

    if role not in {"ADMIN", "SUPER_ADMIN"}:
        raise HTTPException(
            status_code=403,
            detail="Configured demo account is not an administrator",
        )

    if hasattr(user, "is_active") and not user.is_active:
        raise HTTPException(
            status_code=403,
            detail="Demo administrator account is inactive",
        )

    token = create_access_token(
        subject=str(user.id),
        additional_claims={"role": role},
    )

    return {
        "access_token": token,
        "token_type": "bearer",
        "role": role,
        "demo": True,
    }
