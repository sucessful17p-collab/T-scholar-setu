import enum
from datetime import datetime

from sqlalchemy import (
    Column,
    Integer,
    String,
    Boolean,
    DateTime,
    ForeignKey,
    Enum,
    Date,
    Float,
)
from sqlalchemy.orm import relationship

from app.db.base_class import Base


class UserRole(str, enum.Enum):
    APPLICANT = "APPLICANT"
    ADMIN = "ADMIN"
    INSTITUTE_NODAL_OFFICER = "INSTITUTE_NODAL_OFFICER"
    DISTRICT_NODAL_OFFICER = "DISTRICT_NODAL_OFFICER"


class VerificationProvider(str, enum.Enum):
    AADHAAR = "AADHAAR"
    DIGILOCKER = "DIGILOCKER"


class VerificationStatus(str, enum.Enum):
    PENDING = "PENDING"
    VERIFIED = "VERIFIED"
    FAILED = "FAILED"


class GenderEnum(str, enum.Enum):
    MALE = "MALE"
    FEMALE = "FEMALE"
    OTHER = "OTHER"


class CategoryEnum(str, enum.Enum):
    GENERAL = "GENERAL"
    SC = "SC"
    ST = "ST"
    OBC = "OBC"
    EWS = "EWS"


class UserAccount(Base):
    __tablename__ = "user_accounts"

    id = Column(Integer, primary_key=True, index=True)
    phone_number = Column(String, unique=True, index=True, nullable=False)
    role = Column(
        Enum(UserRole),
        default=UserRole.APPLICANT,
        nullable=False,
    )

    # OTP security fields
    hashed_otp = Column(String, nullable=True)
    otp_expires_at = Column(DateTime, nullable=True)
    otp_sent_at = Column(DateTime, nullable=True)
    failed_otp_attempts = Column(Integer, default=0, nullable=False)
    otp_locked_until = Column(DateTime, nullable=True)

    is_active = Column(Boolean, default=True)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
    )

    profile = relationship(
        "ApplicantProfile",
        back_populates="user",
        uselist=False,
        cascade="all, delete-orphan",
    )


class ApplicantProfile(Base):
    __tablename__ = "applicant_profiles"

    id = Column(Integer, primary_key=True, index=True)

    user_id = Column(
        Integer,
        ForeignKey("user_accounts.id"),
        unique=True,
        nullable=False,
    )

    full_name = Column(String, nullable=True)
    date_of_birth = Column(Date, nullable=True)
    gender = Column(Enum(GenderEnum), nullable=True)
    category = Column(Enum(CategoryEnum), nullable=True)
    domicile_state = Column(String, nullable=True)
    annual_family_income = Column(Float, nullable=True)
    disability_status = Column(Boolean, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
    )

    user = relationship(
        "UserAccount",
        back_populates="profile",
    )

    verifications = relationship(
        "IdentityVerification",
        back_populates="profile",
        cascade="all, delete-orphan",
    )


class IdentityVerification(Base):
    __tablename__ = "identity_verifications"

    id = Column(Integer, primary_key=True, index=True)

    applicant_profile_id = Column(
        Integer,
        ForeignKey("applicant_profiles.id"),
        nullable=False,
    )

    provider = Column(
        Enum(VerificationProvider),
        nullable=False,
    )

    # Opaque reference token, NOT raw PII
    reference_id = Column(
        String,
        nullable=True,
        index=True,
    )

    verification_status = Column(
        Enum(VerificationStatus),
        default=VerificationStatus.PENDING,
        nullable=False,
    )

    verified_at = Column(DateTime, nullable=True)

    created_at = Column(
        DateTime,
        default=datetime.utcnow,
    )

    updated_at = Column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
    )

    profile = relationship(
        "ApplicantProfile",
        back_populates="verifications",
    )