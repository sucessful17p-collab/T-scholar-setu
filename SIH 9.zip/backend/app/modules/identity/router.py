from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.modules.identity.schemas import RequestOTP, VerifyOTP, Token, ApplicantProfileResponse, ApplicantProfileUpdate, ExternalVerificationRequest, IdentityVerificationResponse
from app.modules.identity.services import identity_service
from app.modules.identity.models import UserAccount
from app.modules.identity.deps import get_db, get_current_user

router = APIRouter()

@router.post("/auth/request-otp", status_code=status.HTTP_200_OK)
def request_otp(data: RequestOTP, db: Session = Depends(get_db)):
    """
    Generate and send an OTP to the provided phone number.
    Creates a new user if one doesn't exist.
    """
    identity_service.request_otp(db, data.phone_number)
    return {"message": "OTP sent successfully"}

@router.post("/auth/verify-otp", response_model=Token)
def verify_otp(data: VerifyOTP, db: Session = Depends(get_db)):
    """
    Verify the OTP and return a JWT access token.
    (This doubles as the OAuth2 token endpoint if mapped as such, though typically OAuth2 expects form-data.
    We are using a JSON body for simplicity in this prototype).
    """
    token = identity_service.verify_otp_and_login(db, data.phone_number, data.otp)
    return {"access_token": token, "token_type": "bearer"}

@router.get("/profile", response_model=ApplicantProfileResponse)
def get_profile(
    db: Session = Depends(get_db),
    current_user: UserAccount = Depends(get_current_user)
):
    """
    Get the authenticated applicant's profile and verifications.
    """
    profile = identity_service.get_profile_by_phone(db, current_user.phone_number)
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    return profile

@router.patch("/profile", response_model=ApplicantProfileResponse)
def update_profile(
    data: ApplicantProfileUpdate,
    db: Session = Depends(get_db),
    current_user: UserAccount = Depends(get_current_user)
):
    """
    Update the authenticated applicant's profile.
    """
    profile = identity_service.get_profile_by_phone(db, current_user.phone_number)
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    
    update_data = data.model_dump(exclude_unset=True)
    updated_profile = identity_service.update_profile(db, profile.id, update_data)
    return updated_profile


@router.post("/verify", response_model=IdentityVerificationResponse)
def trigger_verification(
    data: ExternalVerificationRequest,
    db: Session = Depends(get_db),
    current_user: UserAccount = Depends(get_current_user)
):
    """
    Trigger an external identity verification (Aadhaar or DigiLocker) via the configured adapter.
    """
    profile = identity_service.get_profile_by_phone(db, current_user.phone_number)
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
        
    verification = identity_service.trigger_external_verification(
        db, 
        profile_id=profile.id,
        provider_enum=data.provider,
        document_id=data.document_id
    )
    return verification
