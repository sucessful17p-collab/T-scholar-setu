from pydantic import BaseModel, Field, field_validator
from typing import Optional, List
from datetime import date, datetime
from app.modules.identity.models import UserRole, VerificationProvider, VerificationStatus, GenderEnum, CategoryEnum

def normalize_phone_number(value: str) -> str:
    value = value.strip().replace(" ", "").replace("-", "")
    if value.startswith("+91"):
        value = value[3:]
    if not value.isdigit() or len(value) != 10 or value[0] not in "6789":
        raise ValueError("Enter a valid 10-digit Indian mobile number")
    return "+91" + value


class RequestOTP(BaseModel):
    phone_number: str = Field(min_length=10, max_length=15)

    @field_validator("phone_number")
    @classmethod
    def validate_phone(cls, value: str) -> str:
        return normalize_phone_number(value)


class VerifyOTP(BaseModel):
    phone_number: str = Field(min_length=10, max_length=15)
    otp: str = Field(min_length=6, max_length=6, pattern=r"^\d{6}$")

    @field_validator("phone_number")
    @classmethod
    def validate_phone(cls, value: str) -> str:
        return normalize_phone_number(value)

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    phone_number: Optional[str] = None

class IdentityVerificationBase(BaseModel):
    provider: VerificationProvider
    verification_status: VerificationStatus
    verified_at: Optional[datetime] = None

class IdentityVerificationResponse(IdentityVerificationBase):
    id: int
    class Config:
        from_attributes = True

class ApplicantProfileBase(BaseModel):
    full_name: Optional[str] = None
    date_of_birth: Optional[date] = None
    gender: Optional[GenderEnum] = None
    category: Optional[CategoryEnum] = None
    domicile_state: Optional[str] = None
    annual_family_income: Optional[float] = None
    disability_status: Optional[bool] = None

class ApplicantProfileUpdate(ApplicantProfileBase):
    pass

class ApplicantProfileResponse(ApplicantProfileBase):
    id: int
    user_id: int
    verifications: List[IdentityVerificationResponse] = []
    class Config:
        from_attributes = True

class ExternalVerificationRequest(BaseModel):
    provider: VerificationProvider
    document_id: str = Field(min_length=1, max_length=128)  # raw ID is never persisted
