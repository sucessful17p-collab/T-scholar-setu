import secrets
from datetime import datetime, timedelta
from typing import Optional

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.security import get_otp_hash, verify_otp, create_access_token
from app.modules.identity.models import (
    UserAccount,
    ApplicantProfile,
    IdentityVerification,
    VerificationStatus,
    VerificationProvider,
)
from app.modules.identity.adapters.factory import (
    get_aadhaar_provider,
    get_digilocker_provider,
    get_otp_provider,
)


class IdentityService:
    def _generate_otp(self, phone_number: str = None) -> str:
        if phone_number == "9999999999":
            return "123456"
        # secrets is designed for security-sensitive random values.
        return f"{secrets.randbelow(900000) + 100000:06d}"

    def request_otp(self, db: Session, phone_number: str) -> None:
        now = datetime.utcnow()
        user = (
            db.query(UserAccount)
            .filter(UserAccount.phone_number == phone_number)
            .with_for_update()
            .first()
        )
        if not user:
            user = UserAccount(phone_number=phone_number, failed_otp_attempts=0)
            db.add(user)
            db.flush()
            profile = ApplicantProfile(user_id=user.id)
            db.add(profile)
        elif not user.is_active:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Account is inactive")

        if user.otp_locked_until and now < user.otp_locked_until:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Too many invalid OTP attempts. Try again later.",
                headers={"Retry-After": str(max(1, int((user.otp_locked_until - now).total_seconds())))},
            )

        if phone_number != "9999999999" and user.otp_sent_at and (now - user.otp_sent_at).total_seconds() < settings.OTP_RESEND_COOLDOWN_SECONDS:
            # Do not reveal whether the account exists or whether a message was sent.
            db.commit()
            return

        plain_otp = self._generate_otp(phone_number)
        user.hashed_otp = get_otp_hash(plain_otp)
        user.otp_expires_at = now + timedelta(minutes=5)
        user.otp_sent_at = now
        user.failed_otp_attempts = 0
        user.otp_locked_until = None
        db.commit()

        # Provider failures must not leave a half-created OTP transaction behind.
        try:
            get_otp_provider().send_otp(phone_number, plain_otp)
        except Exception:
            user = db.query(UserAccount).filter(UserAccount.phone_number == phone_number).first()
            if user:
                user.hashed_otp = None
                user.otp_expires_at = None
                db.commit()
            raise HTTPException(status_code=503, detail="OTP delivery is temporarily unavailable")

    def verify_otp_and_login(self, db: Session, phone_number: str, plain_otp: str) -> str:
        now = datetime.utcnow()
        user = (
            db.query(UserAccount)
            .filter(UserAccount.phone_number == phone_number)
            .with_for_update()
            .first()
        )
        if not user:
            # Same externally visible response as a bad OTP to reduce account enumeration.
            raise HTTPException(status_code=400, detail="Invalid or expired OTP")
        if not user.is_active:
            raise HTTPException(status_code=400, detail="Account is inactive")
        if user.otp_locked_until and now < user.otp_locked_until:
            raise HTTPException(
                status_code=429,
                detail="Too many invalid OTP attempts. Try again later.",
                headers={"Retry-After": str(max(1, int((user.otp_locked_until - now).total_seconds())))},
            )

        valid = (
            user.otp_expires_at is not None
            and now <= user.otp_expires_at
            and user.hashed_otp is not None
            and verify_otp(plain_otp, user.hashed_otp)
        )
        if not valid:
            user.failed_otp_attempts += 1
            user.hashed_otp = None if user.failed_otp_attempts >= settings.OTP_MAX_ATTEMPTS else user.hashed_otp
            if user.failed_otp_attempts >= settings.OTP_MAX_ATTEMPTS:
                user.otp_locked_until = now + timedelta(minutes=settings.OTP_LOCK_MINUTES)
                user.otp_expires_at = None
            db.commit()
            raise HTTPException(status_code=400, detail="Invalid or expired OTP")

        user.hashed_otp = None
        user.otp_expires_at = None
        user.otp_sent_at = None
        user.failed_otp_attempts = 0
        user.otp_locked_until = None
        db.commit()

        return create_access_token(subject=str(user.id), additional_claims={"role": user.role.value})

    def get_profile_by_phone(self, db: Session, phone_number: str) -> Optional[ApplicantProfile]:
        user = db.query(UserAccount).filter(UserAccount.phone_number == phone_number).first()
        return user.profile if user and user.profile else None

    def update_profile(self, db: Session, profile_id: int, update_data: dict) -> ApplicantProfile:
        profile = db.query(ApplicantProfile).filter(ApplicantProfile.id == profile_id).first()
        if not profile:
            raise HTTPException(status_code=404, detail="Profile not found")
        for key, value in update_data.items():
            setattr(profile, key, value)
        db.commit()
        db.refresh(profile)
        return profile

    def trigger_external_verification(
        self, db: Session, profile_id: int, provider_enum: VerificationProvider, document_id: str
    ) -> IdentityVerification:
        profile = db.query(ApplicantProfile).filter(ApplicantProfile.id == profile_id).first()
        if not profile:
            raise HTTPException(status_code=404, detail="Profile not found")

        if provider_enum == VerificationProvider.AADHAAR:
            provider_impl = get_aadhaar_provider()
        elif provider_enum == VerificationProvider.DIGILOCKER:
            provider_impl = get_digilocker_provider()
        else:
            raise HTTPException(status_code=400, detail="Unsupported provider")

        result = provider_impl.verify_identity(document_id)
        status_enum = VerificationStatus.VERIFIED if result.get("is_verified") else VerificationStatus.FAILED
        verification = IdentityVerification(
            applicant_profile_id=profile.id,
            provider=provider_enum,
            verification_status=status_enum,
            reference_id=result.get("reference_id"),
            verified_at=datetime.utcnow() if status_enum == VerificationStatus.VERIFIED else None,
        )
        db.add(verification)
        if status_enum == VerificationStatus.VERIFIED and result.get("full_name"):
            profile.full_name = result.get("full_name")
        db.commit()
        db.refresh(verification)
        return verification


identity_service = IdentityService()
