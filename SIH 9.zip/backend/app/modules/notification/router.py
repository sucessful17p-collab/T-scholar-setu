from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.modules.identity.deps import get_db, get_current_user
from app.modules.identity.models import UserAccount, UserRole
from app.modules.notification.models import Notification, NotificationStatus
from app.modules.notification.schemas import NotificationCreate, NotificationResponse
from app.modules.notification.services import notification_service

router = APIRouter(prefix="/notifications", tags=["Notifications"])

@router.get("/me", response_model=List[NotificationResponse])
def my_notifications(db: Session = Depends(get_db), user: UserAccount = Depends(get_current_user)):
    return db.query(Notification).filter(Notification.user_id == user.id).order_by(Notification.created_at.desc()).all()

@router.post("/", response_model=NotificationResponse, status_code=201)
def create_notification(data: NotificationCreate, db: Session = Depends(get_db), user: UserAccount = Depends(get_current_user)):
    if user.role != UserRole.ADMIN:
        if data.user_id != user.id:
            raise HTTPException(403, "Only admins can notify another user")
        if data.application_id is not None:
            from app.modules.application.models import Application
            app = db.query(Application).filter(Application.id == data.application_id).first()
            if not app or not user.profile or app.applicant_profile_id != user.profile.id:
                raise HTTPException(403, "Not authorized for this application")
    return notification_service.send(db, data)

@router.post("/{notification_id}/read", response_model=NotificationResponse)
def mark_read(notification_id: int, db: Session = Depends(get_db), user: UserAccount = Depends(get_current_user)):
    n = db.query(Notification).filter(Notification.id == notification_id).first()
    if not n: raise HTTPException(404, "Notification not found")
    if n.user_id != user.id and user.role != UserRole.ADMIN: raise HTTPException(403, "Not authorized")
    n.status = NotificationStatus.READ; db.commit(); db.refresh(n)
    return n
