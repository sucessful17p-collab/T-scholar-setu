from datetime import datetime
from typing import Optional
from pydantic import BaseModel, ConfigDict
from app.modules.notification.models import NotificationChannel, NotificationStatus

class NotificationCreate(BaseModel):
    user_id: int
    application_id: Optional[int] = None
    channel: NotificationChannel = NotificationChannel.IN_APP
    template: str
    message: str

class NotificationResponse(BaseModel):
    id: int
    user_id: int
    application_id: Optional[int]
    channel: NotificationChannel
    template: str
    message: str
    status: NotificationStatus
    provider_reference: Optional[str]
    created_at: datetime
    sent_at: Optional[datetime]
    model_config = ConfigDict(from_attributes=True)
