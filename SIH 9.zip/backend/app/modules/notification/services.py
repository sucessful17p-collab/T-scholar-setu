from datetime import datetime
from sqlalchemy.orm import Session
from app.modules.notification.models import Notification, NotificationStatus

class NotificationService:
    def send(self, db: Session, data):
        item = Notification(**data.model_dump())
        item.status = NotificationStatus.SENT
        item.provider_reference = f"DEMO-{datetime.utcnow().timestamp()}"
        item.sent_at = datetime.utcnow()
        db.add(item); db.commit(); db.refresh(item)
        return item

notification_service = NotificationService()
