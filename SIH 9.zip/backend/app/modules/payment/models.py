import enum
from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Float, Enum
from sqlalchemy.orm import relationship
from app.db.base_class import Base

class PaymentStatus(str, enum.Enum):
    INITIATED = "INITIATED"
    SENT = "SENT"
    PAID = "PAID"
    FAILED = "FAILED"
    REVERSED = "REVERSED"

class PaymentOrder(Base):
    __tablename__ = "payment_orders"
    id = Column(Integer, primary_key=True, index=True)
    application_id = Column(Integer, ForeignKey("applications.id"), nullable=False, index=True)
    benefit_id = Column(Integer, ForeignKey("benefits.id"), nullable=True)
    amount = Column(Float, nullable=False)
    currency = Column(String, default="INR", nullable=False)
    status = Column(Enum(PaymentStatus), default=PaymentStatus.INITIATED, nullable=False)
    idempotency_key = Column(String, unique=True, nullable=False, index=True)
    provider_reference = Column(String, nullable=True, index=True)
    failure_reason = Column(String, nullable=True)
    initiated_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    paid_at = Column(DateTime, nullable=True)

    application = relationship("Application", foreign_keys=[application_id])
    benefit = relationship("Benefit", foreign_keys=[benefit_id])
