from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.modules.identity.deps import get_db, get_current_user
from app.modules.identity.models import UserAccount, UserRole
from app.modules.payment.models import PaymentOrder
from app.modules.payment.schemas import PaymentCreate, PaymentResponse
from app.modules.payment.services import payment_service

router = APIRouter(prefix="/payments", tags=["Payment / DBT"])

def require_admin(user: UserAccount = Depends(get_current_user)):
    if user.role != UserRole.ADMIN: raise HTTPException(403, "Admin access required")
    return user

@router.post("/", response_model=PaymentResponse, status_code=201)
def process_payment(data: PaymentCreate, db: Session = Depends(get_db), user: UserAccount = Depends(require_admin)):
    return payment_service.create_and_submit(db, data, user.id)

@router.get("/", response_model=List[PaymentResponse])
def list_payments(db: Session = Depends(get_db), user: UserAccount = Depends(require_admin)):
    return db.query(PaymentOrder).order_by(PaymentOrder.initiated_at.desc()).all()

@router.get("/applications/{application_id}", response_model=List[PaymentResponse])
def application_payments(application_id: int, db: Session = Depends(get_db), user: UserAccount = Depends(get_current_user)):
    orders = db.query(PaymentOrder).filter(PaymentOrder.application_id == application_id).all()
    if user.role == UserRole.APPLICANT:
        if not user.profile:
            raise HTTPException(403, "Not authorized")
        if orders and any(o.application.applicant_profile_id != user.profile.id for o in orders):
            raise HTTPException(403, "Not authorized")
        if not orders:
            # Prevent probing arbitrary application IDs.
            from app.modules.application.models import Application
            app = db.query(Application).filter(Application.id == application_id).first()
            if not app or app.applicant_profile_id != user.profile.id:
                raise HTTPException(403, "Not authorized")
    elif user.role != UserRole.ADMIN:
        raise HTTPException(403, "Not authorized")
    return orders
