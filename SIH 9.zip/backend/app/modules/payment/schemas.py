from datetime import datetime
from typing import Optional
from pydantic import BaseModel, ConfigDict
from app.modules.payment.models import PaymentStatus

class PaymentCreate(BaseModel):
    application_id: int
    benefit_id: Optional[int] = None
    idempotency_key: str

class PaymentResponse(BaseModel):
    id: int
    application_id: int
    benefit_id: Optional[int]
    amount: float
    currency: str
    status: PaymentStatus
    idempotency_key: str
    provider_reference: Optional[str]
    failure_reason: Optional[str]
    initiated_at: datetime
    updated_at: datetime
    paid_at: Optional[datetime]
    model_config = ConfigDict(from_attributes=True)
