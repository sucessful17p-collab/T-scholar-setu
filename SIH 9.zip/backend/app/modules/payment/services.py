from datetime import datetime
from fastapi import HTTPException
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from app.modules.application.models import Application, ApplicationStatus
from app.modules.payment.models import PaymentOrder, PaymentStatus
from app.modules.scheme.models import Benefit
from app.modules.selection.models import SelectionResult, SelectionDecision, SelectionRunStatus
from app.modules.audit.services import audit_service
from app.modules.notification.services import notification_service
from app.modules.notification.schemas import NotificationCreate

class MockPFMSAdapter:
    def submit(self, order: PaymentOrder) -> str:
        return f"PFMS-DEMO-{order.idempotency_key[:16].upper()}"

class PaymentService:
    def __init__(self, provider=None):
        self.provider = provider or MockPFMSAdapter()

    def create_and_submit(self, db: Session, data, actor_id: int):
        if not data.idempotency_key or len(data.idempotency_key) > 128:
            raise HTTPException(400, "Invalid idempotency key")
        existing = db.query(PaymentOrder).filter(PaymentOrder.idempotency_key == data.idempotency_key).first()
        if existing:
            return existing

        app = db.query(Application).filter(Application.id == data.application_id).first()
        if not app: raise HTTPException(404, "Application not found")
        if app.status != ApplicationStatus.VERIFIED:
            raise HTTPException(400, "Payment is allowed only for VERIFIED applications")

        published = db.query(SelectionResult).join(SelectionResult.run).filter(
            SelectionResult.application_id == app.id,
            SelectionResult.decision == SelectionDecision.SELECTED,
            SelectionResult.run.has(status=SelectionRunStatus.PUBLISHED)
        ).first()
        if not published:
            raise HTTPException(400, "Application is not selected in a published merit list")

        benefit = None
        if data.benefit_id:
            benefit = db.query(Benefit).filter(
                Benefit.id == data.benefit_id,
                Benefit.scheme_version_id == app.scheme_version_id
            ).first()
            if not benefit: raise HTTPException(400, "Invalid benefit for this scheme version")
        else:
            benefit = db.query(Benefit).filter(Benefit.scheme_version_id == app.scheme_version_id).first()
        if not benefit: raise HTTPException(400, "No benefit configured for this scheme")

        order = PaymentOrder(
            application_id=app.id, benefit_id=benefit.id, amount=benefit.amount,
            currency=benefit.currency, idempotency_key=data.idempotency_key,
            status=PaymentStatus.INITIATED
        )
        db.add(order)
        try:
            db.flush()
            order.provider_reference = self.provider.submit(order)
            order.status = PaymentStatus.SENT
            order.paid_at = datetime.utcnow()
            order.status = PaymentStatus.PAID  # mock provider is synchronous
        except IntegrityError:
            db.rollback()
            existing = db.query(PaymentOrder).filter(PaymentOrder.idempotency_key == data.idempotency_key).first()
            if existing:
                return existing
            raise HTTPException(409, "Payment request could not be created")
        except Exception as exc:
            order.status = PaymentStatus.FAILED
            order.failure_reason = "Payment provider error"
        audit_service.log_action(db, "PAYMENT_PROCESSED", "PaymentOrder", order.id, actor_id=actor_id,
                                 new_status=order.status.value,
                                 metadata={"application_id": app.id, "amount": order.amount})
        db.commit(); db.refresh(order)
        if order.status == PaymentStatus.PAID:
            notification_service.send(
                db,
                NotificationCreate(
                    user_id=app.applicant_profile.user_id,
                    application_id=app.id,
                    template="PAYMENT_SUCCESS",
                    message=f"Your DBT payment of {order.currency} {order.amount:.2f} has been processed. Reference: {order.provider_reference}.",
                ),
            )
        return order

payment_service = PaymentService()
