from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.modules.identity.deps import get_db, get_current_user
from app.modules.identity.models import UserAccount, UserRole
from app.modules.rag_assistant.models import KnowledgeDocument
from app.modules.rag_assistant.schemas import KnowledgeDocumentCreate, KnowledgeDocumentResponse, AssistantQuery, AssistantAnswer
from app.modules.rag_assistant.services import rag_service

router = APIRouter(prefix="/assistant", tags=["AI / RAG Assistant"])

@router.post("/query", response_model=AssistantAnswer)
def query(data: AssistantQuery, db: Session = Depends(get_db), user: UserAccount = Depends(get_current_user)):
    answer, docs = rag_service.answer(db, data.question, data.scheme_version_id)
    return AssistantAnswer(answer=answer, sources=docs)

@router.post("/knowledge", response_model=KnowledgeDocumentResponse, status_code=201)
def add_knowledge(data: KnowledgeDocumentCreate, db: Session = Depends(get_db), user: UserAccount = Depends(get_current_user)):
    if user.role != UserRole.ADMIN: raise HTTPException(403, "Admin access required")
    doc = KnowledgeDocument(**data.model_dump())
    db.add(doc); db.commit(); db.refresh(doc)
    return doc
