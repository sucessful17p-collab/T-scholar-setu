from typing import Optional, List
from pydantic import BaseModel, ConfigDict

class KnowledgeDocumentCreate(BaseModel):
    scheme_version_id: Optional[int] = None
    title: str
    source: Optional[str] = None
    content: str

class KnowledgeDocumentResponse(BaseModel):
    id: int
    scheme_version_id: Optional[int]
    title: str
    source: Optional[str]
    content: str
    model_config = ConfigDict(from_attributes=True)

class AssistantQuery(BaseModel):
    question: str
    scheme_version_id: Optional[int] = None

class AssistantAnswer(BaseModel):
    answer: str
    sources: List[KnowledgeDocumentResponse]
