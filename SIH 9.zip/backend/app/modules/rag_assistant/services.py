import re
from typing import List
from sqlalchemy.orm import Session
from app.modules.rag_assistant.models import KnowledgeDocument

STOPWORDS = {"the","a","an","is","are","of","to","and","or","for","in","on","with","what","how","who","can","my","this","that"}

class RAGService:
    def _terms(self, text):
        return {x for x in re.findall(r"[a-z0-9_]+", text.lower()) if x not in STOPWORDS and len(x) > 2}

    def answer(self, db: Session, question: str, scheme_version_id=None):
        docs = db.query(KnowledgeDocument)
        if scheme_version_id:
            docs = docs.filter(KnowledgeDocument.scheme_version_id.in_([scheme_version_id, None]))
        docs = docs.all()
        q = self._terms(question)
        ranked = []
        for d in docs:
            terms = self._terms(d.content + " " + d.title)
            overlap = len(q & terms)
            if overlap:
                ranked.append((overlap, d))
        ranked.sort(key=lambda x: (-x[0], x[1].id))
        top = [d for _, d in ranked[:3]]
        if not top:
            return "I could not find a matching scheme guideline in the configured knowledge base. Please contact the helpdesk.", []
        excerpts = []
        for d in top:
            sentences = re.split(r"(?<=[.!?])\s+", d.content)
            relevant = [s for s in sentences if q & self._terms(s)]
            excerpts.append(f"{d.title}: {' '.join(relevant[:2]) or sentences[0][:400]}")
        return " ".join(excerpts), top

rag_service = RAGService()
