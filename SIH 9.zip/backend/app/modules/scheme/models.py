from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, Date, Enum as SQLEnum, Float
from sqlalchemy.orm import relationship
import enum

from app.db.base_class import Base

class OperatorEnum(str, enum.Enum):
    EQUALS = "=="
    GREATER_THAN = ">"
    LESS_THAN = "<"
    GREATER_EQUALS = ">="
    LESS_EQUALS = "<="
    IN = "IN"

class FieldTypeEnum(str, enum.Enum):
    STRING = "string"
    INTEGER = "integer"
    FLOAT = "float"
    DATE = "date"
    BOOLEAN = "boolean"

class BenefitTypeEnum(str, enum.Enum):
    ALLOWANCE = "ALLOWANCE"
    FEE_REIMBURSEMENT = "FEE_REIMBURSEMENT"
    ONE_TIME_GRANT = "ONE_TIME_GRANT"

class Scheme(Base):
    __tablename__ = "schemes"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True, nullable=False)
    description = Column(String)
    
    versions = relationship("SchemeVersion", back_populates="scheme", cascade="all, delete-orphan")


class SchemeVersion(Base):
    __tablename__ = "scheme_versions"

    id = Column(Integer, primary_key=True, index=True)
    scheme_id = Column(Integer, ForeignKey("schemes.id"), nullable=False)
    version_number = Column(String, nullable=False)  # e.g., "2021-22"
    start_date = Column(Date)
    end_date = Column(Date)
    is_active = Column(Boolean, default=False)

    scheme = relationship("Scheme", back_populates="versions")
    
    eligibility_rules = relationship("EligibilityRule", back_populates="version", cascade="all, delete-orphan")
    required_documents = relationship("RequiredDocument", back_populates="version", cascade="all, delete-orphan")
    form_fields = relationship("FormField", back_populates="version", cascade="all, delete-orphan")
    benefits = relationship("Benefit", back_populates="version", cascade="all, delete-orphan")
    selection_criteria = relationship("SelectionCriterion", back_populates="version", cascade="all, delete-orphan")
    workflow_rules = relationship("WorkflowRule", back_populates="version", cascade="all, delete-orphan")


class EligibilityRule(Base):
    __tablename__ = "eligibility_rules"

    id = Column(Integer, primary_key=True, index=True)
    scheme_version_id = Column(Integer, ForeignKey("scheme_versions.id"), nullable=False)
    
    rule_type = Column(String, nullable=False)  # e.g., 'MAX_AGE', 'MAX_INCOME', 'CATEGORY'
    operator = Column(SQLEnum(OperatorEnum), nullable=False)
    value = Column(String, nullable=False)

    version = relationship("SchemeVersion", back_populates="eligibility_rules")


class RequiredDocument(Base):
    __tablename__ = "required_documents"

    id = Column(Integer, primary_key=True, index=True)
    scheme_version_id = Column(Integer, ForeignKey("scheme_versions.id"), nullable=False)
    
    document_name = Column(String, nullable=False)
    is_mandatory = Column(Boolean, default=True)
    description = Column(String)

    version = relationship("SchemeVersion", back_populates="required_documents")


class FormField(Base):
    __tablename__ = "form_fields"

    id = Column(Integer, primary_key=True, index=True)
    scheme_version_id = Column(Integer, ForeignKey("scheme_versions.id"), nullable=False)
    
    field_name = Column(String, nullable=False)
    field_type = Column(SQLEnum(FieldTypeEnum), nullable=False)
    is_mandatory = Column(Boolean, default=True)

    version = relationship("SchemeVersion", back_populates="form_fields")


class Benefit(Base):
    __tablename__ = "benefits"

    id = Column(Integer, primary_key=True, index=True)
    scheme_version_id = Column(Integer, ForeignKey("scheme_versions.id"), nullable=False)
    
    benefit_name = Column(String, nullable=False)
    benefit_type = Column(SQLEnum(BenefitTypeEnum), nullable=False)
    amount = Column(Float, nullable=False)
    currency = Column(String, default="INR")
    description = Column(String)

    version = relationship("SchemeVersion", back_populates="benefits")


class SelectionCriterion(Base):
    __tablename__ = "selection_criteria"

    id = Column(Integer, primary_key=True, index=True)
    scheme_version_id = Column(Integer, ForeignKey("scheme_versions.id"), nullable=False)
    
    criterion = Column(String, nullable=False) # e.g. "QS_RANKING", "MARKS_PERCENTAGE"
    priority = Column(Integer, nullable=False) # 1 is highest

    version = relationship("SchemeVersion", back_populates="selection_criteria")


class WorkflowRule(Base):
    __tablename__ = "workflow_rules"

    id = Column(Integer, primary_key=True, index=True)
    scheme_version_id = Column(Integer, ForeignKey("scheme_versions.id"), nullable=False)
    
    step_order = Column(Integer, nullable=False)
    step_name = Column(String, nullable=False)
    required_role = Column(String, nullable=False)
    is_final_approval = Column(Boolean, default=False)

    version = relationship("SchemeVersion", back_populates="workflow_rules")
