from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List

from app.db.session import SessionLocal
from app.modules.scheme import schemas
from app.modules.scheme.services import scheme_service
from app.modules.identity.deps import get_current_user
from app.modules.identity.models import UserAccount, UserRole
from fastapi import HTTPException

router = APIRouter(prefix="/schemes", tags=["Schemes"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def require_admin(user: UserAccount = Depends(get_current_user)):
    if user.role != UserRole.ADMIN:
        raise HTTPException(status_code=403, detail="Admin access required")
    return user

@router.post("/", response_model=schemas.SchemeResponse)
def create_scheme(
    scheme_in: schemas.SchemeCreate,
    db: Session = Depends(get_db),
    user: UserAccount = Depends(require_admin),
):
    return scheme_service.create_scheme(db, scheme_in)

@router.get("/", response_model=List[schemas.SchemeResponse])
def get_all_schemes(db: Session = Depends(get_db)):
    return scheme_service.get_all_schemes(db)

@router.get("/{scheme_id}/versions/active", response_model=schemas.SchemeVersionResponse)
def get_active_scheme_version(scheme_id: int, db: Session = Depends(get_db)):
    return scheme_service.get_active_version(db, scheme_id)
