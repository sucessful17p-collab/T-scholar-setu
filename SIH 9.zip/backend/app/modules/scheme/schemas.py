from typing import List, Optional
from datetime import date
from pydantic import BaseModel, Field

from app.modules.scheme.models import OperatorEnum, FieldTypeEnum, BenefitTypeEnum

class EligibilityRuleBase(BaseModel):
    rule_type: str
    operator: OperatorEnum
    value: str

class RequiredDocumentBase(BaseModel):
    document_name: str
    is_mandatory: bool = True
    description: Optional[str] = None

class FormFieldBase(BaseModel):
    field_name: str
    field_type: FieldTypeEnum
    is_mandatory: bool = True

class BenefitBase(BaseModel):
    benefit_name: str
    benefit_type: BenefitTypeEnum
    amount: float
    currency: str = "INR"
    description: Optional[str] = None

class SelectionCriterionBase(BaseModel):
    criterion: str
    priority: int

class WorkflowRuleBase(BaseModel):
    step_order: int
    step_name: str
    required_role: str
    is_final_approval: bool = False

# Version Schemas
class SchemeVersionCreate(BaseModel):
    version_number: str
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    is_active: bool = False
    
    eligibility_rules: List[EligibilityRuleBase] = Field(default_factory=list)
    required_documents: List[RequiredDocumentBase] = Field(default_factory=list)
    form_fields: List[FormFieldBase] = Field(default_factory=list)
    benefits: List[BenefitBase] = Field(default_factory=list)
    selection_criteria: List[SelectionCriterionBase] = Field(default_factory=list)
    workflow_rules: List[WorkflowRuleBase] = Field(default_factory=list)

class SchemeVersionResponse(SchemeVersionCreate):
    id: int
    scheme_id: int

    class Config:
        from_attributes = True

# Scheme Schemas
class SchemeCreate(BaseModel):
    name: str
    description: Optional[str] = None
    versions: List[SchemeVersionCreate] = Field(default_factory=list)

class SchemeResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    versions: List[SchemeVersionResponse]

    class Config:
        from_attributes = True
