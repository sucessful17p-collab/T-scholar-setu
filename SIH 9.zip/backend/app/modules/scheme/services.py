from sqlalchemy.orm import Session
from fastapi import HTTPException
from app.modules.scheme import models, schemas

class SchemeService:
    @staticmethod
    def create_scheme(db: Session, scheme_in: schemas.SchemeCreate) -> models.Scheme:
        db_scheme = models.Scheme(
            name=scheme_in.name,
            description=scheme_in.description
        )
        db.add(db_scheme)
        db.flush()

        for version_in in scheme_in.versions:
            SchemeService.create_version(db, db_scheme.id, version_in)

        db.commit()
        db.refresh(db_scheme)
        return db_scheme

    @staticmethod
    def create_version(db: Session, scheme_id: int, version_in: schemas.SchemeVersionCreate) -> models.SchemeVersion:
        db_version = models.SchemeVersion(
            scheme_id=scheme_id,
            version_number=version_in.version_number,
            start_date=version_in.start_date,
            end_date=version_in.end_date,
            is_active=version_in.is_active
        )
        db.add(db_version)
        db.flush()

        # Add Eligibility Rules
        for rule_in in version_in.eligibility_rules:
            db.add(models.EligibilityRule(scheme_version_id=db_version.id, **rule_in.dict()))

        # Add Required Documents
        for doc_in in version_in.required_documents:
            db.add(models.RequiredDocument(scheme_version_id=db_version.id, **doc_in.dict()))

        # Add Form Fields
        for field_in in version_in.form_fields:
            db.add(models.FormField(scheme_version_id=db_version.id, **field_in.dict()))

        # Add Benefits
        for ben_in in version_in.benefits:
            db.add(models.Benefit(scheme_version_id=db_version.id, **ben_in.dict()))

        # Add Selection Criteria
        for crit_in in version_in.selection_criteria:
            db.add(models.SelectionCriterion(scheme_version_id=db_version.id, **crit_in.dict()))

        # Add Workflow Rules
        for wf_in in version_in.workflow_rules:
            db.add(models.WorkflowRule(scheme_version_id=db_version.id, **wf_in.dict()))
        
        db.flush()
        return db_version

    @staticmethod
    def get_all_schemes(db: Session):
        return db.query(models.Scheme).all()

    @staticmethod
    def get_active_version(db: Session, scheme_id: int):
        version = db.query(models.SchemeVersion).filter(
            models.SchemeVersion.scheme_id == scheme_id,
            models.SchemeVersion.is_active == True
        ).first()
        if not version:
            raise HTTPException(status_code=404, detail="No active version found for this scheme")
        return version

scheme_service = SchemeService()
