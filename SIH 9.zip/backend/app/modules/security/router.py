from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.modules.identity.deps import get_db, get_current_user
from app.modules.identity.models import UserAccount, UserRole
from app.modules.audit.models import AuditLog

router = APIRouter(prefix="/security", tags=["Security"])

@router.get("/audit")
def audit_logs(limit: int = 100, db: Session = Depends(get_db), user: UserAccount = Depends(get_current_user)):
    if user.role != UserRole.ADMIN: raise HTTPException(403, "Admin access required")
    limit = max(1, min(limit, 500))
    rows = db.query(AuditLog).order_by(AuditLog.created_at.desc()).limit(limit).all()
    return [{
        "id": x.id, "actor_id": x.actor_id, "action": x.action,
        "entity_type": x.entity_type, "entity_id": x.entity_id,
        "old_status": x.old_status, "new_status": x.new_status,
        "metadata": x.metadata_json, "created_at": x.created_at
    } for x in rows]
