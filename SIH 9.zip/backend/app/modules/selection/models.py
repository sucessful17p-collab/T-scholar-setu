import enum
from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Float, Enum
from sqlalchemy.types import JSON
from sqlalchemy.orm import relationship
from app.db.base_class import Base

class SelectionRunStatus(str, enum.Enum):
    DRAFT = "DRAFT"
    EXECUTED = "EXECUTED"
    PUBLISHED = "PUBLISHED"
    CANCELLED = "CANCELLED"

class SelectionDecision(str, enum.Enum):
    SELECTED = "SELECTED"
    WAITLISTED = "WAITLISTED"
    NOT_SELECTED = "NOT_SELECTED"

class SelectionRun(Base):
    __tablename__ = "selection_runs"
    id = Column(Integer, primary_key=True, index=True)
    scheme_version_id = Column(Integer, ForeignKey("scheme_versions.id"), nullable=False, index=True)
    seats = Column(Integer, nullable=False)
    status = Column(Enum(SelectionRunStatus), default=SelectionRunStatus.DRAFT, nullable=False)
    created_by = Column(Integer, ForeignKey("user_accounts.id"), nullable=True)
    executed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    scheme_version = relationship("SchemeVersion", foreign_keys=[scheme_version_id])
    results = relationship("SelectionResult", back_populates="run", cascade="all, delete-orphan")

class SelectionResult(Base):
    __tablename__ = "selection_results"
    id = Column(Integer, primary_key=True, index=True)
    run_id = Column(Integer, ForeignKey("selection_runs.id"), nullable=False, index=True)
    application_id = Column(Integer, ForeignKey("applications.id"), nullable=False, index=True)
    rank = Column(Integer, nullable=False)
    score = Column(Float, nullable=False)
    decision = Column(Enum(SelectionDecision), nullable=False)
    score_breakdown = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

    run = relationship("SelectionRun", back_populates="results")
    application = relationship("Application", foreign_keys=[application_id])
