from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.modules.identity.deps import get_db, get_current_user
from app.modules.identity.models import UserAccount, UserRole
from app.modules.selection.models import SelectionRun, SelectionResult, SelectionRunStatus
from app.modules.selection.schemas import SelectionRunCreate, SelectionRunResponse, SelectionResultResponse
from app.modules.selection.services import selection_service

router = APIRouter(prefix="/selection", tags=["Selection / Merit"])

def require_admin(user: UserAccount = Depends(get_current_user)):
    if user.role != UserRole.ADMIN:
        raise HTTPException(403, "Admin access required")
    return user

@router.post("/runs", response_model=SelectionRunResponse, status_code=201)
def create_run(data: SelectionRunCreate, db: Session = Depends(get_db), user: UserAccount = Depends(require_admin)):
    run = SelectionRun(scheme_version_id=data.scheme_version_id, seats=data.seats, created_by=user.id)
    db.add(run); db.commit(); db.refresh(run)
    return run

@router.post("/runs/{run_id}/execute", response_model=SelectionRunResponse)
def execute_run(run_id: int, db: Session = Depends(get_db), user: UserAccount = Depends(require_admin)):
    return selection_service.execute(db, run_id, user.id)

@router.post("/runs/{run_id}/publish", response_model=SelectionRunResponse)
def publish_run(run_id: int, db: Session = Depends(get_db), user: UserAccount = Depends(require_admin)):
    return selection_service.publish(db, run_id, user.id)

@router.get("/runs/{run_id}", response_model=SelectionRunResponse)
def get_run(run_id: int, db: Session = Depends(get_db), user: UserAccount = Depends(get_current_user)):
    run = db.query(SelectionRun).filter(SelectionRun.id == run_id).first()
    if not run: raise HTTPException(404, "Selection run not found")
    if user.role != UserRole.ADMIN:
        result = db.query(SelectionResult).join(SelectionRun).filter(
            SelectionResult.run_id == run_id,
            SelectionResult.application.has(applicant_profile_id=user.profile.id if user.profile else -1)
        ).first()
        if not result: raise HTTPException(403, "Not authorized")
    return run

@router.get("/applications/{application_id}/result", response_model=SelectionResultResponse)
def application_result(application_id: int, db: Session = Depends(get_db), user: UserAccount = Depends(get_current_user)):
    result = db.query(SelectionResult).join(SelectionRun).filter(
        SelectionResult.application_id == application_id,
        SelectionRun.status == SelectionRunStatus.PUBLISHED
    ).order_by(SelectionResult.id.desc()).first()
    if not result: raise HTTPException(404, "Published selection result not found")
    if user.role == UserRole.APPLICANT:
        if not user.profile or result.application.applicant_profile_id != user.profile.id:
            raise HTTPException(403, "Not authorized")
    elif user.role != UserRole.ADMIN:
        raise HTTPException(403, "Not authorized")
    return result
