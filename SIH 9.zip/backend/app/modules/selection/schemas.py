from datetime import datetime
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field, ConfigDict
from app.modules.selection.models import SelectionRunStatus, SelectionDecision

class SelectionRunCreate(BaseModel):
    scheme_version_id: int
    seats: int = Field(gt=0, le=100000)

class SelectionResultResponse(BaseModel):
    id: int
    application_id: int
    rank: int
    score: float
    decision: SelectionDecision
    score_breakdown: Dict[str, Any]
    model_config = ConfigDict(from_attributes=True)

class SelectionRunResponse(BaseModel):
    id: int
    scheme_version_id: int
    seats: int
    status: SelectionRunStatus
    created_by: Optional[int]
    executed_at: Optional[datetime]
    created_at: datetime
    results: List[SelectionResultResponse] = Field(default_factory=list)
    model_config = ConfigDict(from_attributes=True)
