from datetime import datetime
from typing import Any, Dict, List
from fastapi import HTTPException
from sqlalchemy.orm import Session
from app.modules.application.models import Application, ApplicationStatus
from app.modules.scheme.models import SelectionCriterion
from app.modules.selection.models import SelectionRun, SelectionRunStatus, SelectionResult, SelectionDecision
from app.modules.audit.services import audit_service
from app.modules.notification.services import notification_service
from app.modules.notification.schemas import NotificationCreate

class SelectionService:
    def _criterion_score(self, criterion: str, form_data: Dict[str, Any]) -> float:
        value = form_data.get(criterion.lower())
        if value is None:
            aliases = {
                "MARKS_PERCENTAGE": "marks_percentage",
                "INSTITUTE_QS_RANKING": "institute_qs_ranking",
                "RESEARCH_SCORE": "research_score",
                "ENTRANCE_SCORE": "entrance_score",
            }
            value = form_data.get(aliases.get(criterion, criterion.lower()))
        try:
            value = float(value)
        except (TypeError, ValueError):
            return 0.0
        if criterion == "INSTITUTE_QS_RANKING":
            return 100.0 / max(value, 1.0)
        return max(0.0, min(value, 100.0))

    def execute(self, db: Session, run_id: int, actor_id: int) -> SelectionRun:
        run = db.query(SelectionRun).filter(SelectionRun.id == run_id).first()
        if not run:
            raise HTTPException(404, "Selection run not found")
        if run.status not in [SelectionRunStatus.DRAFT]:
            raise HTTPException(400, "Selection run has already been executed")

        criteria = db.query(SelectionCriterion).filter(
            SelectionCriterion.scheme_version_id == run.scheme_version_id
        ).order_by(SelectionCriterion.priority.asc()).all()
        if not criteria:
            raise HTTPException(400, "No selection criteria configured for this scheme version")

        applications = db.query(Application).filter(
            Application.scheme_version_id == run.scheme_version_id,
            Application.status == ApplicationStatus.VERIFIED
        ).all()
        if not applications:
            raise HTTPException(400, "No VERIFIED applications available for selection")

        # Weighted-by-priority deterministic scoring. Higher priority receives a larger weight.
        weights = {c.criterion: max(1, len(criteria) - i) for i, c in enumerate(criteria)}
        scored = []
        for app in applications:
            breakdown = {}
            total = 0.0
            total_weight = 0.0
            for c in criteria:
                score = self._criterion_score(c.criterion, app.form_data or {})
                breakdown[c.criterion] = {"score": score, "priority": c.priority, "weight": weights[c.criterion]}
                total += score * weights[c.criterion]
                total_weight += weights[c.criterion]
            normalized = total / total_weight if total_weight else 0.0
            # Deterministic tie-breaker: application id.
            scored.append((normalized, app.id, breakdown))

        scored.sort(key=lambda x: (-x[0], x[1]))
        for idx, (score, app_id, breakdown) in enumerate(scored, start=1):
            decision = SelectionDecision.SELECTED if idx <= run.seats else SelectionDecision.NOT_SELECTED
            result = SelectionResult(
                run_id=run.id, application_id=app_id, rank=idx,
                score=round(score, 6), decision=decision, score_breakdown=breakdown
            )
            db.add(result)

        run.status = SelectionRunStatus.EXECUTED
        run.executed_at = datetime.utcnow()
        audit_service.log_action(
            db, "SELECTION_RUN_EXECUTED", "SelectionRun", run.id, actor_id=actor_id,
            new_status=run.status.value,
            metadata={"scheme_version_id": run.scheme_version_id, "seats": run.seats, "candidate_count": len(scored)}
        )
        db.commit()
        db.refresh(run)
        return run

    def publish(self, db: Session, run_id: int, actor_id: int) -> SelectionRun:
        run = db.query(SelectionRun).filter(SelectionRun.id == run_id).first()
        if not run:
            raise HTTPException(404, "Selection run not found")
        if run.status != SelectionRunStatus.EXECUTED:
            raise HTTPException(400, "Only executed runs can be published")
        run.status = SelectionRunStatus.PUBLISHED
        audit_service.log_action(db, "MERIT_LIST_PUBLISHED", "SelectionRun", run.id, actor_id=actor_id, new_status=run.status.value)
        db.commit()
        db.refresh(run)
        selected = [r for r in run.results if r.decision == SelectionDecision.SELECTED]
        for result in selected:
            notification_service.send(
                db,
                NotificationCreate(
                    user_id=result.application.applicant_profile.user_id,
                    application_id=result.application_id,
                    template="MERIT_LIST_PUBLISHED",
                    message=f"Your application {result.application.application_number} was selected at merit rank {result.rank}.",
                ),
            )
        return run

selection_service = SelectionService()
