import enum
from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Enum
from sqlalchemy.orm import relationship

from app.db.base_class import Base

class VerificationAssignmentStatus(str, enum.Enum):
    PENDING = "PENDING"
    ASSIGNED = "ASSIGNED"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"

class VerificationActionEnum(str, enum.Enum):
    APPROVE = "APPROVE"
    DEFECT = "DEFECT"
    REJECT = "REJECT"

class VerificationAssignment(Base):
    __tablename__ = "verification_assignments"
    
    id = Column(Integer, primary_key=True, index=True)
    application_id = Column(Integer, ForeignKey("applications.id"), nullable=False, index=True)
    verifier_id = Column(Integer, ForeignKey("user_accounts.id"), nullable=True, index=True)
    
    verification_level = Column(String, nullable=False) # e.g., "INSTITUTE_NODAL_OFFICER"
    status = Column(Enum(VerificationAssignmentStatus), default=VerificationAssignmentStatus.PENDING, nullable=False)
    
    assigned_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    application = relationship("Application", foreign_keys=[application_id])
    verifier = relationship("UserAccount", foreign_keys=[verifier_id])
    actions = relationship("VerificationAction", back_populates="assignment", cascade="all, delete-orphan")


class VerificationAction(Base):
    __tablename__ = "verification_actions"
    
    id = Column(Integer, primary_key=True, index=True)
    assignment_id = Column(Integer, ForeignKey("verification_assignments.id"), nullable=False, index=True)
    application_id = Column(Integer, ForeignKey("applications.id"), nullable=False, index=True)
    verifier_id = Column(Integer, ForeignKey("user_accounts.id"), nullable=False, index=True)
    
    action = Column(Enum(VerificationActionEnum), nullable=False)
    comments = Column(String, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    
    assignment = relationship("VerificationAssignment", back_populates="actions")
    application = relationship("Application", foreign_keys=[application_id])
    verifier = relationship("UserAccount", foreign_keys=[verifier_id])
