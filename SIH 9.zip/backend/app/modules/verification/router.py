from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.modules.identity.models import UserAccount, UserRole
from app.modules.identity.deps import get_db, get_current_user
from app.modules.verification.schemas import (
    VerificationAssignmentResponse,
    VerificationActionSubmit,
    VerificationActionResponse
)
from app.modules.verification.services import verification_service

router = APIRouter(
    prefix="/verifications",
    tags=["Verification"]
)

def require_verifier(current_user: UserAccount = Depends(get_current_user)):
    if current_user.role not in [UserRole.INSTITUTE_NODAL_OFFICER, UserRole.DISTRICT_NODAL_OFFICER]:
        raise HTTPException(status_code=403, detail="Not authorized as verifier")
    return current_user

@router.get("/my-assignments", response_model=List[VerificationAssignmentResponse])
def get_my_assignments(
    db: Session = Depends(get_db),
    current_user: UserAccount = Depends(require_verifier)
):
    return verification_service.get_my_assignments(db, current_user.id, current_user.role.value)

@router.post("/assignments/{assignment_id}/assign-to-me", response_model=VerificationAssignmentResponse)
def assign_to_me(
    assignment_id: int,
    db: Session = Depends(get_db),
    current_user: UserAccount = Depends(require_verifier)
):
    return verification_service.assign_to_me(db, assignment_id, current_user.id, current_user.role.value)

@router.post("/assignments/{assignment_id}/actions", response_model=VerificationActionResponse)
def submit_verification_action(
    assignment_id: int,
    data: VerificationActionSubmit,
    db: Session = Depends(get_db),
    current_user: UserAccount = Depends(require_verifier)
):
    return verification_service.submit_action(db, assignment_id, current_user.id, current_user.role.value, data)
