from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
from app.modules.verification.models import VerificationAssignmentStatus, VerificationActionEnum

class VerificationAssignmentResponse(BaseModel):
    id: int
    application_id: int
    verifier_id: Optional[int]
    verification_level: str
    status: VerificationAssignmentStatus
    assigned_at: Optional[datetime]
    completed_at: Optional[datetime]
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class VerificationActionSubmit(BaseModel):
    action: VerificationActionEnum
    comments: Optional[str] = None

class VerificationActionResponse(BaseModel):
    id: int
    assignment_id: int
    application_id: int
    verifier_id: int
    action: VerificationActionEnum
    comments: Optional[str]
    created_at: datetime
    
    class Config:
        from_attributes = True
