from typing import List, Optional
from datetime import datetime
from sqlalchemy.orm import Session
from fastapi import HTTPException

from app.modules.verification.models import (
    VerificationAssignment, 
    VerificationAssignmentStatus,
    VerificationAction,
    VerificationActionEnum
)
from app.modules.application.models import Application, ApplicationStatus
from app.modules.scheme.models import WorkflowRule
from app.modules.audit.services import audit_service
from app.modules.verification.schemas import VerificationActionSubmit

class VerificationService:
    def _create_assignment(self, db: Session, application: Application, rule: WorkflowRule) -> VerificationAssignment:
        assignment = VerificationAssignment(
            application_id=application.id,
            verification_level=rule.required_role,
            status=VerificationAssignmentStatus.PENDING
        )
        db.add(assignment)
        db.flush()
        
        audit_service.log_action(
            db=db,
            action="WORKFLOW_TASK_CREATED",
            entity_type="VerificationAssignment",
            entity_id=assignment.id,
            metadata={"verification_level": rule.required_role, "application_id": application.id}
        )
        return assignment

    def start_verification_workflow(self, db: Session, application: Application):
        """Called automatically after submission and eligibility pass."""
        scheme_version = application.scheme_version
        
        # Check if an active assignment already exists to avoid duplicates
        existing_assignment = db.query(VerificationAssignment).filter(
            VerificationAssignment.application_id == application.id,
            VerificationAssignment.status.in_([VerificationAssignmentStatus.PENDING, VerificationAssignmentStatus.ASSIGNED])
        ).first()
        if existing_assignment:
            return
            
        first_rule = db.query(WorkflowRule).filter(
            WorkflowRule.scheme_version_id == scheme_version.id
        ).order_by(WorkflowRule.step_order.asc()).first()
        
        if first_rule:
            self._create_assignment(db, application, first_rule)
            
            old_status = application.status
            application.status = ApplicationStatus.IN_REVIEW
            
            audit_service.log_action(
                db=db,
                action="APPLICATION_IN_REVIEW",
                entity_type="Application",
                entity_id=application.id,
                old_status=old_status.value,
                new_status=ApplicationStatus.IN_REVIEW.value
            )

    def get_my_assignments(self, db: Session, verifier_id: int, role: str) -> List[VerificationAssignment]:
        # A verifier sees assignments explicitly assigned to them OR pending ones matching their role.
        # This implementation lets them see PENDING ones for their level. 
        # (In a real system, there might be district boundaries, but keeping it simple based on role)
        return db.query(VerificationAssignment).filter(
            VerificationAssignment.verification_level == role,
            VerificationAssignment.status.in_([VerificationAssignmentStatus.PENDING, VerificationAssignmentStatus.ASSIGNED])
        ).all()
        
    def assign_to_me(self, db: Session, assignment_id: int, verifier_id: int, role: str) -> VerificationAssignment:
        assignment = db.query(VerificationAssignment).filter(VerificationAssignment.id == assignment_id).first()
        if not assignment:
            raise HTTPException(status_code=404, detail="Assignment not found")
        if assignment.verification_level != role:
            raise HTTPException(status_code=403, detail="Role mismatch for this assignment")
        if assignment.status != VerificationAssignmentStatus.PENDING:
            if assignment.verifier_id != verifier_id:
                raise HTTPException(status_code=400, detail="Already assigned to someone else")
                
        assignment.verifier_id = verifier_id
        assignment.status = VerificationAssignmentStatus.ASSIGNED
        assignment.assigned_at = datetime.utcnow()
        
        audit_service.log_action(
            db=db,
            action="VERIFIER_ASSIGNED",
            entity_type="VerificationAssignment",
            entity_id=assignment.id,
            actor_id=verifier_id,
            new_status=VerificationAssignmentStatus.ASSIGNED.value
        )
        db.commit()
        db.refresh(assignment)
        return assignment

    def submit_action(self, db: Session, assignment_id: int, verifier_id: int, role: str, data: VerificationActionSubmit) -> VerificationAction:
        assignment = db.query(VerificationAssignment).filter(VerificationAssignment.id == assignment_id).first()
        if not assignment:
            raise HTTPException(status_code=404, detail="Assignment not found")
            
        if assignment.verification_level != role:
            raise HTTPException(status_code=403, detail="Role mismatch for this assignment")
            
        if assignment.status == VerificationAssignmentStatus.COMPLETED:
            raise HTTPException(status_code=400, detail="Assignment is already completed")
            
        # Optional: Auto-assign if they act on a pending assignment directly
        if assignment.status == VerificationAssignmentStatus.PENDING:
            assignment.verifier_id = verifier_id
            
        if assignment.verifier_id != verifier_id:
            raise HTTPException(status_code=403, detail="Assignment is held by another verifier")
            
        application = assignment.application
        if application.status not in [ApplicationStatus.SUBMITTED, ApplicationStatus.IN_REVIEW]:
            raise HTTPException(status_code=400, detail="Application is not in a valid state for verification")

        action = VerificationAction(
            assignment_id=assignment.id,
            application_id=application.id,
            verifier_id=verifier_id,
            action=data.action,
            comments=data.comments
        )
        db.add(action)
        
        assignment.status = VerificationAssignmentStatus.COMPLETED
        assignment.completed_at = datetime.utcnow()
        
        old_app_status = application.status
        
        # State transitions
        if data.action == VerificationActionEnum.REJECT:
            application.status = ApplicationStatus.REJECTED
        elif data.action == VerificationActionEnum.DEFECT:
            application.status = ApplicationStatus.DEFECTIVE
        elif data.action == VerificationActionEnum.APPROVE:
            # Find current rule
            current_rule = db.query(WorkflowRule).filter(
                WorkflowRule.scheme_version_id == application.scheme_version_id,
                WorkflowRule.required_role == assignment.verification_level
            ).first()
            
            if current_rule and current_rule.is_final_approval:
                application.status = ApplicationStatus.VERIFIED
            else:
                # Find next rule
                next_rule = db.query(WorkflowRule).filter(
                    WorkflowRule.scheme_version_id == application.scheme_version_id,
                    WorkflowRule.step_order > current_rule.step_order
                ).order_by(WorkflowRule.step_order.asc()).first()
                
                if next_rule:
                    self._create_assignment(db, application, next_rule)
                else:
                    # Fallback if no next rule is defined but not marked final
                    application.status = ApplicationStatus.VERIFIED
                    
        audit_service.log_action(
            db=db,
            action=f"VERIFICATION_{data.action.value}",
            entity_type="Application",
            entity_id=application.id,
            actor_id=verifier_id,
            old_status=old_app_status.value,
            new_status=application.status.value,
            metadata={"comments": data.comments, "assignment_id": assignment.id}
        )
        
        db.commit()
        db.refresh(action)
        return action

verification_service = VerificationService()
