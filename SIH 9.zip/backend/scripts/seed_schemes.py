import os
import sys

# Ensure backend directory is in path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.db.session import SessionLocal
from app.modules.scheme.schemas import (
    SchemeCreate, SchemeVersionCreate, EligibilityRuleBase, RequiredDocumentBase,
    FormFieldBase, BenefitBase, SelectionCriterionBase, WorkflowRuleBase
)
from app.modules.scheme.models import OperatorEnum, FieldTypeEnum, BenefitTypeEnum
from app.modules.scheme.services import scheme_service

def seed_nos_scheme(db):
    nos_scheme = SchemeCreate(
        name="National Overseas Scholarship (NOS) for ST Students",
        description="Financial assistance to pursue Master's, Ph.D, and Post-Doctoral research abroad.",
        versions=[
            SchemeVersionCreate(
                version_number="2021-22",
                is_active=True,
                eligibility_rules=[
                    EligibilityRuleBase(rule_type="MAX_INCOME", operator=OperatorEnum.LESS_EQUALS, value="600000"),
                    EligibilityRuleBase(rule_type="MAX_AGE_MASTERS", operator=OperatorEnum.LESS_EQUALS, value="32"),
                    EligibilityRuleBase(rule_type="MAX_AGE_PHD", operator=OperatorEnum.LESS_EQUALS, value="35"),
                    EligibilityRuleBase(rule_type="MAX_AGE_POSTDOC", operator=OperatorEnum.LESS_EQUALS, value="38"),
                    EligibilityRuleBase(rule_type="MIN_MARKS", operator=OperatorEnum.GREATER_EQUALS, value="55"),
                    EligibilityRuleBase(rule_type="CATEGORY", operator=OperatorEnum.EQUALS, value="ST")
                ],
                required_documents=[
                    RequiredDocumentBase(document_name="Latest Coloured Passport Size Photograph", is_mandatory=True),
                    RequiredDocumentBase(document_name="ST certificate", is_mandatory=True),
                    RequiredDocumentBase(document_name="PVTG certificate", is_mandatory=False, description="if applicable"),
                    RequiredDocumentBase(document_name="10th Certificate/Marksheet (Date of Birth)", is_mandatory=True),
                    RequiredDocumentBase(document_name="Graduation/Post-Graduation mark sheet", is_mandatory=True),
                    RequiredDocumentBase(document_name="Offer of admission", is_mandatory=True),
                    RequiredDocumentBase(document_name="Income Certificate", is_mandatory=True)
                ],
                form_fields=[
                    FormFieldBase(field_name="institute_qs_ranking", field_type=FieldTypeEnum.INTEGER, is_mandatory=True),
                    FormFieldBase(field_name="course_level", field_type=FieldTypeEnum.STRING, is_mandatory=True)
                ],
                benefits=[
                    BenefitBase(benefit_name="Annual Maintenance Allowance (US)", benefit_type=BenefitTypeEnum.ALLOWANCE, amount=15400.0, currency="USD"),
                    BenefitBase(benefit_name="Annual Contingency (US)", benefit_type=BenefitTypeEnum.ALLOWANCE, amount=1532.0, currency="USD"),
                    BenefitBase(benefit_name="Poll Tax", benefit_type=BenefitTypeEnum.FEE_REIMBURSEMENT, amount=0.0, description="Actuals"),
                    BenefitBase(benefit_name="Visa Fees", benefit_type=BenefitTypeEnum.FEE_REIMBURSEMENT, amount=0.0, description="Actuals"),
                    BenefitBase(benefit_name="Incidental Journey Expenses", benefit_type=BenefitTypeEnum.ALLOWANCE, amount=20.0, currency="USD"),
                    BenefitBase(benefit_name="Tuition Fees", benefit_type=BenefitTypeEnum.FEE_REIMBURSEMENT, amount=0.0, description="Actuals"),
                    BenefitBase(benefit_name="Medical Insurance Premium", benefit_type=BenefitTypeEnum.FEE_REIMBURSEMENT, amount=0.0, description="Actuals"),
                    BenefitBase(benefit_name="Cost of Air Passage", benefit_type=BenefitTypeEnum.FEE_REIMBURSEMENT, amount=0.0, description="Actuals"),
                    BenefitBase(benefit_name="Local Travel", benefit_type=BenefitTypeEnum.FEE_REIMBURSEMENT, amount=0.0, description="Actuals")
                ],
                selection_criteria=[
                    SelectionCriterionBase(criterion="QS_RANKING", priority=1),
                    SelectionCriterionBase(criterion="MARKS_PERCENTAGE", priority=2),
                    SelectionCriterionBase(criterion="INTERVIEW_SCORE", priority=3)
                ],
                workflow_rules=[
                    WorkflowRuleBase(step_order=1, step_name="State/UT Verification", required_role="STATE_NODAL_OFFICER"),
                    WorkflowRuleBase(step_order=2, step_name="Expert Committee Interview", required_role="COMMITTEE_MEMBER"),
                    WorkflowRuleBase(step_order=3, step_name="Ministry Approval", required_role="MINISTRY_OFFICIAL", is_final_approval=True),
                    WorkflowRuleBase(step_order=4, step_name="Embassy Verification (Post-Selection)", required_role="EMBASSY_OFFICIAL")
                ]
            )
        ]
    )
    scheme_service.create_scheme(db, nos_scheme)
    print("Seeded NOS Scheme successfully.")

def seed_pre_matric_scheme(db):
    pre_matric_scheme = SchemeCreate(
        name="Pre-Matric Scholarship for ST Students (Class IX and X)",
        description="Financial assistance for ST students studying in classes IX and X.",
        versions=[
            SchemeVersionCreate(
                version_number="2021-22",
                is_active=True,
                eligibility_rules=[
                    EligibilityRuleBase(rule_type="MAX_INCOME", operator=OperatorEnum.LESS_EQUALS, value="250000"),
                    EligibilityRuleBase(rule_type="CATEGORY", operator=OperatorEnum.EQUALS, value="ST"),
                    EligibilityRuleBase(rule_type="CLASS_ENROLLED", operator=OperatorEnum.IN, value="9,10")
                ],
                required_documents=[
                    RequiredDocumentBase(document_name="Aadhar Number", is_mandatory=True),
                    RequiredDocumentBase(document_name="Domicile certificate", is_mandatory=True),
                    RequiredDocumentBase(document_name="ST certificate", is_mandatory=True),
                    RequiredDocumentBase(document_name="Family Income Certificate", is_mandatory=True),
                    RequiredDocumentBase(document_name="Disability certificate", is_mandatory=False, description="if applicable"),
                    RequiredDocumentBase(document_name="Scanned copy of the passport size photograph", is_mandatory=True)
                ],
                form_fields=[
                    FormFieldBase(field_name="current_class", field_type=FieldTypeEnum.INTEGER, is_mandatory=True),
                    FormFieldBase(field_name="school_udise_code", field_type=FieldTypeEnum.STRING, is_mandatory=True)
                ],
                benefits=[
                    BenefitBase(benefit_name="Day Scholar Allowance (10 months)", benefit_type=BenefitTypeEnum.ALLOWANCE, amount=2250.0, currency="INR"),
                    BenefitBase(benefit_name="Hosteller Allowance (10 months)", benefit_type=BenefitTypeEnum.ALLOWANCE, amount=5250.0, currency="INR"),
                    BenefitBase(benefit_name="Books and ad hoc Grant (Day Scholar)", benefit_type=BenefitTypeEnum.ONE_TIME_GRANT, amount=750.0, currency="INR"),
                    BenefitBase(benefit_name="Books and ad hoc Grant (Hosteller)", benefit_type=BenefitTypeEnum.ONE_TIME_GRANT, amount=1000.0, currency="INR"),
                    BenefitBase(benefit_name="Disability Allowance (Day Scholar)", benefit_type=BenefitTypeEnum.ALLOWANCE, amount=7200.0, currency="INR"),
                    BenefitBase(benefit_name="Disability Allowance (Hosteller)", benefit_type=BenefitTypeEnum.ALLOWANCE, amount=9600.0, currency="INR")
                ],
                selection_criteria=[
                    SelectionCriterionBase(criterion="ELIGIBILITY_ONLY", priority=1)
                ],
                workflow_rules=[
                    WorkflowRuleBase(step_order=1, step_name="Institute Verification", required_role="INO"),
                    WorkflowRuleBase(step_order=2, step_name="District Scrutiny", required_role="DNO"),
                    WorkflowRuleBase(step_order=3, step_name="State Approval", required_role="SNO", is_final_approval=True)
                ]
            )
        ]
    )
    scheme_service.create_scheme(db, pre_matric_scheme)
    print("Seeded Pre-Matric Scheme successfully.")

if __name__ == "__main__":
    db = SessionLocal()
    try:
        seed_nos_scheme(db)
        seed_pre_matric_scheme(db)
    finally:
        db.close()
