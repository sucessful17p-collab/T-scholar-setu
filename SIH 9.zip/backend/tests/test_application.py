import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.main import app
from app.db.base_class import Base
from app.modules.identity.deps import get_db
from app.core.security import create_access_token
from app.modules.identity.models import UserAccount, ApplicantProfile, UserRole
from app.modules.scheme.models import Scheme, SchemeVersion, FormField, FieldTypeEnum

SQLALCHEMY_DATABASE_URL = "sqlite:///./test_application.db"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)

@pytest.fixture(autouse=True)
def setup_db():
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)

@pytest.fixture
def auth_header():
    db = TestingSessionLocal()
    # Create user and profile
    user = UserAccount(phone_number="1112223333", role=UserRole.APPLICANT)
    db.add(user)
    db.commit()
    db.refresh(user)
    
    profile = ApplicantProfile(user_id=user.id)
    db.add(profile)
    db.commit()
    
    token = create_access_token(subject=str(user.id))
    db.close()
    
    return {"Authorization": f"Bearer {token}"}

@pytest.fixture
def scheme_version():
    db = TestingSessionLocal()
    scheme = Scheme(name="Test Scheme")
    db.add(scheme)
    db.commit()
    db.refresh(scheme)
    
    version = SchemeVersion(scheme_id=scheme.id, version_number="1.0", is_active=True)
    db.add(version)
    db.commit()
    db.refresh(version)
    
    # Add form fields
    ff1 = FormField(scheme_version_id=version.id, field_name="course_level", field_type=FieldTypeEnum.STRING, is_mandatory=True)
    ff2 = FormField(scheme_version_id=version.id, field_name="institute_qs_ranking", field_type=FieldTypeEnum.INTEGER, is_mandatory=False)
    db.add(ff1)
    db.add(ff2)
    db.commit()
    
    vid = version.id
    db.close()
    return vid

def test_create_draft(auth_header, scheme_version):
    response = client.post(
        "/api/v1/applications/",
        json={"scheme_version_id": scheme_version, "form_data": {"course_level": "PG"}},
        headers=auth_header
    )
    assert response.status_code == 201
    data = response.json()
    assert data["status"] == "DRAFT"
    assert "APP-" in data["application_number"]
    assert data["form_data"]["course_level"] == "PG"

def test_list_applications(auth_header, scheme_version):
    # Create one
    client.post(
        "/api/v1/applications/",
        json={"scheme_version_id": scheme_version},
        headers=auth_header
    )
    response = client.get("/api/v1/applications/", headers=auth_header)
    assert response.status_code == 200
    assert len(response.json()) == 1

def test_update_draft(auth_header, scheme_version):
    app_response = client.post(
        "/api/v1/applications/",
        json={"scheme_version_id": scheme_version},
        headers=auth_header
    )
    app_id = app_response.json()["id"]
    
    update_response = client.patch(
        f"/api/v1/applications/{app_id}",
        json={"form_data": {"course_level": "UG"}},
        headers=auth_header
    )
    assert update_response.status_code == 200
    assert update_response.json()["form_data"]["course_level"] == "UG"

def test_submit_application_success(auth_header, scheme_version):
    app_response = client.post(
        "/api/v1/applications/",
        json={"scheme_version_id": scheme_version, "form_data": {"course_level": "PG"}},
        headers=auth_header
    )
    app_id = app_response.json()["id"]
    
    submit_response = client.post(f"/api/v1/applications/{app_id}/submit", headers=auth_header)
    assert submit_response.status_code == 200
    assert submit_response.json()["status"] == "SUBMITTED"

def test_submit_application_missing_fields(auth_header, scheme_version):
    app_response = client.post(
        "/api/v1/applications/",
        json={"scheme_version_id": scheme_version, "form_data": {}},
        headers=auth_header
    )
    app_id = app_response.json()["id"]
    
    submit_response = client.post(f"/api/v1/applications/{app_id}/submit", headers=auth_header)
    assert submit_response.status_code == 400
    assert "Missing required fields" in submit_response.json()["detail"]
