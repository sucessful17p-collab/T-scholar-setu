import os
import io
import pytest
from fastapi.testclient import TestClient

import uuid
from app.modules.scheme.models import RequiredDocument, Scheme, SchemeVersion
from app.modules.document.models import ApplicationDocument
from app.modules.identity.models import UserAccount, ApplicantProfile
from app.modules.application.models import Application, ApplicationStatus
from app.modules.identity.services import identity_service
from app.core.security import create_access_token

@pytest.fixture
def test_user_token(db):
    user = db.query(UserAccount).filter(UserAccount.phone_number == "9999999999").first()
    if not user:
        user = UserAccount(phone_number="9999999999", is_active=True)
        db.add(user)
        db.commit()
        db.refresh(user)
    
    if not hasattr(user, 'profile') or user.profile is None:
        profile = ApplicantProfile(user_id=user.id)
        db.add(profile)
        db.commit()
        db.refresh(profile)
        
    token = create_access_token(subject=str(user.id), additional_claims={"role": user.role.value})
    return token, user.profile.id

@pytest.fixture
def test_application(db, test_user_token):
    token, profile_id = test_user_token
    
    # Create scheme version
    scheme = Scheme(name="Test Scheme")
    db.add(scheme)
    db.commit()
    db.refresh(scheme)
    
    sv = SchemeVersion(scheme_id=scheme.id, version_number="1.0", is_active=True)
    db.add(sv)
    db.commit()
    db.refresh(sv)
    
    app = Application(
        application_number=f"APP-TEST-{uuid.uuid4().hex[:8]}",
        applicant_profile_id=profile_id,
        scheme_version_id=sv.id,
        status=ApplicationStatus.DRAFT,
        form_data={}
    )
    db.add(app)
    db.commit()
    db.refresh(app)
    return app


@pytest.fixture
def mock_storage(monkeypatch):
    import shutil
    from app.modules.document.storage import LocalStorageProvider, get_storage_provider
    from app.main import app

    test_path = "/tmp/test_sih_uploads"
    if os.path.exists(test_path):
        shutil.rmtree(test_path)
    os.makedirs(test_path, exist_ok=True)
    
    mock_provider = LocalStorageProvider(base_path=test_path)
    app.dependency_overrides[get_storage_provider] = lambda: mock_provider
    
    yield mock_provider
    
    if os.path.exists(test_path):
        shutil.rmtree(test_path)
    app.dependency_overrides.pop(get_storage_provider, None)


def test_upload_document(client, db, test_user_token, test_application, mock_storage):
    token, _ = test_user_token
    file_content = b"dummy pdf content"
    files = {"file": ("test.pdf", io.BytesIO(file_content), "application/pdf")}
    
    response = client.post(
        f"/api/v1/applications/{test_application.id}/documents/",
        headers={"Authorization": f"Bearer {token}"},
        files=files
    )
    
    assert response.status_code == 200, response.text
    data = response.json()
    assert data["original_filename"] == "test.pdf"
    assert data["mime_type"] == "application/pdf"
    assert data["file_size"] == len(file_content)
    
    doc_id = data["id"]
    doc = db.query(ApplicationDocument).filter(ApplicationDocument.id == doc_id).first()
    assert doc is not None
    assert os.path.exists(mock_storage.get_path(doc.storage_key))


def test_upload_document_invalid_type(client, test_user_token, test_application, mock_storage):
    token, _ = test_user_token
    file_content = b"dummy text content"
    files = {"file": ("test.txt", io.BytesIO(file_content), "text/plain")}
    
    response = client.post(
        f"/api/v1/applications/{test_application.id}/documents/",
        headers={"Authorization": f"Bearer {token}"},
        files=files
    )
    assert response.status_code == 400
    assert "Unsupported file type" in response.text


def test_upload_document_oversized(client, test_user_token, test_application, mock_storage):
    token, _ = test_user_token
    # 6MB file
    file_content = b"a" * (6 * 1024 * 1024)
    files = {"file": ("large.pdf", io.BytesIO(file_content), "application/pdf")}
    
    response = client.post(
        f"/api/v1/applications/{test_application.id}/documents/",
        headers={"Authorization": f"Bearer {token}"},
        files=files
    )
    assert response.status_code == 400
    assert "exceeds the 5MB limit" in response.text


def test_list_and_download_document(client, db, test_user_token, test_application, mock_storage):
    token, _ = test_user_token
    file_content = b"test file content"
    files = {"file": ("test2.png", io.BytesIO(file_content), "image/png")}
    
    upload_res = client.post(
        f"/api/v1/applications/{test_application.id}/documents/",
        headers={"Authorization": f"Bearer {token}"},
        files=files
    )
    doc_id = upload_res.json()["id"]
    
    list_res = client.get(
        f"/api/v1/applications/{test_application.id}/documents/",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert list_res.status_code == 200
    docs = list_res.json()
    assert any(d["id"] == doc_id for d in docs)
    
    download_res = client.get(
        f"/api/v1/documents/{doc_id}/download",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert download_res.status_code == 200
    assert download_res.content == file_content


def test_delete_document(client, test_user_token, test_application, mock_storage):
    token, _ = test_user_token
    file_content = b"to be deleted"
    files = {"file": ("test3.jpg", io.BytesIO(file_content), "image/jpeg")}
    
    upload_res = client.post(
        f"/api/v1/applications/{test_application.id}/documents/",
        headers={"Authorization": f"Bearer {token}"},
        files=files
    )
    doc_id = upload_res.json()["id"]
    
    del_res = client.delete(
        f"/api/v1/documents/{doc_id}",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert del_res.status_code == 200
    
    list_res = client.get(
        f"/api/v1/applications/{test_application.id}/documents/",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert not any(d["id"] == doc_id for d in list_res.json())


def test_unauthorized_access(client, test_user_token, test_application, mock_storage):
    token, _ = test_user_token
    response = client.get(
        f"/api/v1/applications/99999/documents/",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert response.status_code == 404
