import pytest
from datetime import date
from sqlalchemy.orm import Session

from app.modules.identity.models import UserAccount, ApplicantProfile, CategoryEnum
from app.modules.scheme.models import Scheme, SchemeVersion, EligibilityRule, OperatorEnum
from app.modules.application.models import Application, ApplicationStatus
from app.modules.eligibility.models import EligibilityEvaluation, EligibilityOverallStatus, EligibilityRuleResultStatus
from app.core.security import create_access_token

@pytest.fixture
def test_user_token(db: Session):
    user = db.query(UserAccount).filter(UserAccount.phone_number == "1234567890").first()
    if not user:
        user = UserAccount(phone_number="1234567890", is_active=True)
        db.add(user)
        db.commit()
        db.refresh(user)
    
    if not hasattr(user, 'profile') or user.profile is None:
        profile = ApplicantProfile(
            user_id=user.id,
            category=CategoryEnum.ST,
            annual_family_income=500000.0,
            date_of_birth=date(2000, 1, 1) # age 26 in 2026
        )
        db.add(profile)
        db.commit()
        db.refresh(profile)
        
    token = create_access_token(subject=str(user.id), additional_claims={"role": user.role.value})
    return token, user.profile

@pytest.fixture
def other_user_token(db: Session):
    user = db.query(UserAccount).filter(UserAccount.phone_number == "0987654321").first()
    if not user:
        user = UserAccount(phone_number="0987654321", is_active=True)
        db.add(user)
        db.commit()
        db.refresh(user)
        
    if not hasattr(user, 'profile') or user.profile is None:
        profile = ApplicantProfile(user_id=user.id)
        db.add(profile)
        db.commit()
        db.refresh(profile)
        
    token = create_access_token(subject=str(user.id), additional_claims={"role": user.role.value})
    return token, user.profile

@pytest.fixture
def test_scheme_setup(db: Session):
    scheme = Scheme(name="Test Eligibility Scheme")
    db.add(scheme)
    db.commit()
    
    sv = SchemeVersion(scheme_id=scheme.id, version_number="1.0", is_active=True)
    db.add(sv)
    db.commit()
    
    # Rules
    rule1 = EligibilityRule(scheme_version_id=sv.id, rule_type="MAX_INCOME", operator=OperatorEnum.LESS_EQUALS, value="600000")
    rule2 = EligibilityRule(scheme_version_id=sv.id, rule_type="CATEGORY", operator=OperatorEnum.EQUALS, value="ST")
    rule3 = EligibilityRule(scheme_version_id=sv.id, rule_type="CLASS_ENROLLED", operator=OperatorEnum.IN, value='[9, 10]')
    rule4 = EligibilityRule(scheme_version_id=sv.id, rule_type="MAX_AGE_MASTERS", operator=OperatorEnum.LESS_THAN, value="30")
    
    db.add_all([rule1, rule2, rule3, rule4])
    db.commit()
    return sv

import uuid

@pytest.fixture
def test_application(db: Session, test_user_token, test_scheme_setup):
    _, profile = test_user_token
    sv = test_scheme_setup
    
    app = Application(
        application_number=f"APP-ELIG-{uuid.uuid4().hex[:8]}",
        applicant_profile_id=profile.id,
        scheme_version_id=sv.id,
        status=ApplicationStatus.DRAFT,
        form_data={"class_enrolled": 10, "marks_percentage": 65}
    )
    db.add(app)
    db.commit()
    db.refresh(app)
    return app

def test_evaluate_fully_eligible(client, test_user_token, test_application):
    token, _ = test_user_token
    
    response = client.post(
        f"/api/v1/applications/{test_application.id}/eligibility/evaluate",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["overall_status"] == "ELIGIBLE"
    assert len(data["rule_results"]) == 4
    for rule in data["rule_results"]:
        assert rule["result"] == "PASS"

def test_evaluate_failed_rule(client, db: Session, test_user_token, test_application):
    token, profile = test_user_token
    
    # Change income to fail MAX_INCOME rule
    profile.annual_family_income = 800000.0
    db.commit()
    
    response = client.post(
        f"/api/v1/applications/{test_application.id}/eligibility/evaluate",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["overall_status"] == "NOT_ELIGIBLE"
    
    failed_rule = next(r for r in data["rule_results"] if r["result"] == "FAIL")
    assert failed_rule["actual_value"] == 800000.0

def test_evaluate_missing_data(client, db: Session, test_user_token, test_application):
    token, profile = test_user_token
    
    # Remove category to trigger UNKNOWN rule
    profile.category = None
    # Reset income to pass
    profile.annual_family_income = 500000.0
    db.commit()
    
    response = client.post(
        f"/api/v1/applications/{test_application.id}/eligibility/evaluate",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["overall_status"] == "INCOMPLETE"
    
    unknown_rule = next(r for r in data["rule_results"] if r["result"] == "UNKNOWN")
    assert "missing" in unknown_rule["explanation"]

def test_evaluate_unsupported_operator(client, db: Session, test_user_token, test_application):
    token, _ = test_user_token
    
    # Add an unsupported rule type
    sv = test_application.scheme_version
    bad_rule = EligibilityRule(scheme_version_id=sv.id, rule_type="RANDOM_UNSUPPORTED", operator=OperatorEnum.EQUALS, value="YES")
    db.add(bad_rule)
    db.commit()
    
    response = client.post(
        f"/api/v1/applications/{test_application.id}/eligibility/evaluate",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["overall_status"] == "INCOMPLETE" # Fails back to UNKNOWN
    
    unknown_rules = [r for r in data["rule_results"] if r["result"] == "UNKNOWN"]
    assert any("Unsupported rule type" in r["explanation"] for r in unknown_rules), f"Found unknown rules: {unknown_rules}"

def test_reevaluation_persists(client, test_user_token, test_application):
    token, _ = test_user_token
    
    # Eval 1
    res1 = client.post(
        f"/api/v1/applications/{test_application.id}/eligibility/evaluate",
        headers={"Authorization": f"Bearer {token}"}
    )
    eval1_id = res1.json()["id"]
    
    # Eval 2
    res2 = client.post(
        f"/api/v1/applications/{test_application.id}/eligibility/evaluate",
        headers={"Authorization": f"Bearer {token}"}
    )
    eval2_id = res2.json()["id"]
    
    assert eval1_id != eval2_id # Distinct records
    
    # Get latest
    get_res = client.get(
        f"/api/v1/applications/{test_application.id}/eligibility",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert get_res.json()["id"] == eval2_id

def test_unauthorized_access(client, other_user_token, test_application):
    token, _ = other_user_token
    
    # Try to evaluate another user's application
    res = client.post(
        f"/api/v1/applications/{test_application.id}/eligibility/evaluate",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert res.status_code == 403
    
    # Try to view another user's application
    res_get = client.get(
        f"/api/v1/applications/{test_application.id}/eligibility",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert res_get.status_code == 403
