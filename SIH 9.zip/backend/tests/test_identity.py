import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import uuid

from app.main import app
from app.db.base_class import Base
from app.db.session import SessionLocal
from app.modules.identity.deps import get_db

# Assuming SQLite for simple testing without external DB. 
# Alternatively, mock the DB session.
SQLALCHEMY_DATABASE_URL = "sqlite:///./test_identity.db"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)

@pytest.fixture(autouse=True)
def setup_db():
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)

def test_request_otp():
    response = client.post("/api/v1/identity/auth/request-otp", json={"phone_number": "9999999999"})
    assert response.status_code == 200
    assert response.json()["message"] == "OTP sent successfully"

def test_update_profile():
    from app.core.security import create_access_token
    from app.modules.identity.models import UserAccount, ApplicantProfile, UserRole
    
    db = TestingSessionLocal()
    user = UserAccount(phone_number="8888888888", role=UserRole.APPLICANT)
    db.add(user)
    db.commit()
    db.refresh(user)
    
    profile = ApplicantProfile(user_id=user.id)
    db.add(profile)
    db.commit()
    
    token = create_access_token(subject=str(user.id))
    db.close()
    
    headers = {"Authorization": f"Bearer {token}"}
    response = client.patch("/api/v1/identity/profile", json={"full_name": "John Doe", "category": "GENERAL"}, headers=headers)
    
    assert response.status_code == 200
    data = response.json()
    assert data["full_name"] == "John Doe"
    assert data["category"] == "GENERAL"

# Note: Testing verify_otp requires extracting the plaintext OTP from the DB or mocking the OTP generation.
# In a real environment, we'd mock the `identity_service._generate_otp` method.

def test_mock_aadhaar_verification():
    # Because endpoints require JWT, testing /verify requires a token.
    # Alternatively, test the service layer directly.
    from app.modules.identity.adapters.mock_aadhaar import MockAadhaarAdapter
    
    adapter = MockAadhaarAdapter()
    
    # Invalid length
    res = adapter.verify_identity("123")
    assert res["is_verified"] == False
    
    # Valid length
    res = adapter.verify_identity("123456789012")
    assert res["is_verified"] == True
    assert "reference_id" in res
    assert res["reference_id"].startswith("mock_uidai_ref_")
    
def test_mock_digilocker_verification():
    from app.modules.identity.adapters.mock_digilocker import MockDigiLockerAdapter
    adapter = MockDigiLockerAdapter()
    
    res = adapter.verify_identity("dl_doc_123")
    assert res["is_verified"] == True
    assert "reference_id" in res
