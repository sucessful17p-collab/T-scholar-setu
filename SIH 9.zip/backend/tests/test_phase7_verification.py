import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session
from app.modules.application.models import ApplicationStatus
from app.modules.identity.models import UserRole
from app.modules.verification.models import VerificationAssignmentStatus

def test_workflow_submission(client: TestClient, db: Session, normal_user_token_headers: dict, setup_application: int):
    # App is currently DRAFT
    app_id = setup_application
    
    # Submit Application
    response = client.post(f"/api/v1/applications/{app_id}/submit", headers=normal_user_token_headers)
    assert response.status_code == 200
    
    # After submission, it should be IN_REVIEW if eligible
    data = response.json()
    assert data["status"] == "IN_REVIEW"

def test_applicant_cannot_access_verification_endpoints(client: TestClient, normal_user_token_headers: dict):
    response = client.get("/api/v1/verifications/my-assignments", headers=normal_user_token_headers)
    assert response.status_code == 403

def test_verifier_access(client: TestClient, db: Session, institute_verifier_token_headers: dict, district_verifier_token_headers: dict):
    # Check that they can access the endpoint
    res = client.get("/api/v1/verifications/my-assignments", headers=institute_verifier_token_headers)
    assert res.status_code == 200
    
    res = client.get("/api/v1/verifications/my-assignments", headers=district_verifier_token_headers)
    assert res.status_code == 200

# Full workflow test is difficult to set up via basic fixture since we'd need to mock 
# the creation of verifier users. We'll do a simpler unit test checking the module directly.
