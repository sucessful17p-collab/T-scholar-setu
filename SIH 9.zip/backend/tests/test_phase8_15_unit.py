from app.modules.selection.services import SelectionService
from app.modules.rag_assistant.services import RAGService

def test_selection_marks_score():
    service = SelectionService()
    assert service._criterion_score("MARKS_PERCENTAGE", {"marks_percentage": 91.5}) == 91.5

def test_selection_qs_rank_score():
    service = SelectionService()
    assert service._criterion_score("INSTITUTE_QS_RANKING", {"institute_qs_ranking": 1}) == 100.0

def test_selection_missing_score_is_zero():
    service = SelectionService()
    assert service._criterion_score("MARKS_PERCENTAGE", {}) == 0.0

def test_rag_term_extraction():
    service = RAGService()
    assert "income" in service._terms("What is the maximum family income?")
