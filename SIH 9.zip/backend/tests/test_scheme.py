def test_create_and_get_scheme(client):
    scheme_payload = {
        "name": "Test Scholarship",
        "description": "A test scheme",
        "versions": [
            {
                "version_number": "2024-25",
                "is_active": True,
                "eligibility_rules": [
                    {
                        "rule_type": "MAX_AGE",
                        "operator": "<=",
                        "value": "30"
                    }
                ],
                "required_documents": [
                    {
                        "document_name": "ID Proof",
                        "is_mandatory": True
                    }
                ],
                "form_fields": [
                    {
                        "field_name": "student_name",
                        "field_type": "string",
                        "is_mandatory": True
                    }
                ],
                "benefits": [
                    {
                        "benefit_name": "Stipend",
                        "benefit_type": "ALLOWANCE",
                        "amount": 1000.0,
                        "currency": "INR"
                    }
                ],
                "selection_criteria": [
                    {
                        "criterion": "MERIT",
                        "priority": 1
                    }
                ],
                "workflow_rules": [
                    {
                        "step_order": 1,
                        "step_name": "Initial Review",
                        "required_role": "CLERK",
                        "is_final_approval": True
                    }
                ]
            }
        ]
    }

    response = client.post("/api/v1/schemes/", json=scheme_payload)
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "Test Scholarship"
    assert len(data["versions"]) == 1
    
    scheme_id = data["id"]

    # Test getting active version
    response = client.get(f"/api/v1/schemes/{scheme_id}/versions/active")
    assert response.status_code == 200
    version_data = response.json()
    assert version_data["version_number"] == "2024-25"
    assert len(version_data["eligibility_rules"]) == 1
    assert version_data["eligibility_rules"][0]["rule_type"] == "MAX_AGE"
