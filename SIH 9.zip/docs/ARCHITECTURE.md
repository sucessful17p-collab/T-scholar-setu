# AI-Enabled Scholarship and Fellowship Management System
**Phase 0 Architecture Specification**

## 1. Architectural Style: Modular Monolith
The application is structured as a **Modular Monolith**. It runs as a cohesive, single deployable backend service but maintains strict internal module boundaries. This ensures low coupling and high cohesion while avoiding the operational overhead of a distributed microservice architecture prematurely.

### Core Principles
- **Separation of Concerns:** Each module handles one distinct business responsibility.
- **Dependency Inversion:** Business logic depends on abstractions, not external vendor implementations.
- **Configuration-Driven:** Scholarship schemes are defined by configuration, not hardcoded logic.
- **AI as an Assistant:** AI augments but never replaces deterministic rules for eligibility and final selections.

## 2. Dependency Rules & Architecture Layers

```
API / Presentation Layer (FastAPI / Next.js)
        |
        v
Application Services (Use Cases)
        |
        v
Domain / Business Logic (Core Models & Rules)
        |
        v
Repository / Infrastructure Layer (Data Access & External APIs)
        |
        v
Database (PostgreSQL)
```

**External Integrations Strategy:**
External dependencies (UIDAI, DigiLocker, PFMS) are never directly embedded in the business logic.
Instead, we use adapters:
```
Identity Interface
      |
      +---- Demo Aadhaar Adapter (Sandbox)
      |
      +---- Production Aadhaar Adapter
```

## 3. Module Cohesion and Boundaries

### Identity Module
- **Purpose**: Manage applicant authentication and verification against official sources (e.g., UIDAI).
- **Responsibilities**: Registration, login, JWT management, Aadhaar verification logic.
- **Non-responsibilities**: Application status, workflow routing.
- **Public Interfaces**: `verify_identity()`, `get_applicant_profile()`.

### Scheme Module
- **Purpose**: Manage configuration-driven scholarship schemes.
- **Responsibilities**: Scheme definitions, SchemeVersions, maintaining the master data of EligibilityRules, FormFields, RequiredDocuments.
- **Non-responsibilities**: Applying rules to specific applicants.
- **Data Owned**: Schemes, SchemeVersions, Eligibility Configurations.

### Applicant Module
- **Purpose**: Manage applicant profiles and historical data.
- **Responsibilities**: Personal details, academic history, bank details, family income profile.
- **Non-responsibilities**: Scheme-specific application data.

### Application Module
- **Purpose**: Manage the submission and state of scheme applications.
- **Responsibilities**: Capturing form field values, linking to scheme versions, coordinating with Eligibility and Document modules during submission.
- **Non-responsibilities**: Document storage, payment processing.

### Document Module
- **Purpose**: Manage applicant-submitted documents.
- **Responsibilities**: Document metadata, upload/download handling, versioning, integration with DigiLocker.
- **Non-responsibilities**: Document verification logic (handled by Verification Module), OCR (handled by AI).

### Verification Module
- **Purpose**: Coordinate the verification of submitted documents and data.
- **Responsibilities**: Cross-checking data, flagging deficiencies, invoking AI for OCR/Extraction, generating a Verification Result.
- **Non-responsibilities**: Final scheme eligibility decision.

### Eligibility Module (Deterministic Engine)
- **Purpose**: The authoritative rule engine for scheme eligibility.
- **Responsibilities**: Evaluating Applicant and Application data against deterministic Scheme rules (income limits, category, age, academic cutoffs).
- **Non-responsibilities**: Making probabilistic AI judgements.

### Workflow Module
- **Purpose**: Route applications through state transitions.
- **Responsibilities**: Scrutiny routing, multi-level review coordination (Institution -> District -> State -> Ministry), handling resubmissions.

### Selection Module
- **Purpose**: Manage the final selection and merit list generation.
- **Responsibilities**: Applying SelectionCriteria (e.g., merit ranking, quota allocation).

### Payment Module
- **Purpose**: Coordinate fund disbursement.
- **Responsibilities**: Generating payment files, interfacing with PFMS (via adapters), tracking payment status.

### RAG Assistant Module
- **Purpose**: Provide grounded answers based on scheme guidelines.
- **Responsibilities**: Query processing, retrieving official circulars/FAQs, providing contextual help.
- **Non-responsibilities**: Making eligibility decisions, hallucinating policy.

### Analytics Module
- **Purpose**: Generate insights and reports.

### Audit Module
- **Purpose**: Maintain immutable records of system mutations (Who, What, When, Reason).

### Grievance Module
- **Purpose**: Handle applicant complaints and helpdesk tickets.
- **Responsibilities**: Ticket routing, status tracking, resolution logs.
- **Non-responsibilities**: Application state changes.

### Notification Module
- **Purpose**: Handle SMS, Email, and in-app alerts.

## 4. Configuration-Driven Architecture
Schemes must not be hardcoded. The domain supports a configuration approach:
```
Scheme
 └── SchemeVersion
       ├── EligibilityRules (e.g., Max Income = 250000)
       ├── RequiredDocuments (e.g., Caste Certificate, Income Certificate)
       ├── FormFields (e.g., Current Semester GPA)
       ├── SelectionCriteria
       ├── Benefits
       └── WorkflowRules
```
*Note: This structure guarantees that historical applications are locked to their specific `SchemeVersion`.*

## 5. Document and AI Architecture
AI is strictly separated from the Deterministic Eligibility engine.
**Document Processing Pipeline:**
```
Document -> Classification -> OCR -> Field Extraction -> Normalization -> Cross-document Verification -> Verification Result
```
AI acts as an anomaly detector and information extractor. A human or deterministic engine makes the final choice.
- **AI Component interfaces** (LLM, OCR, Vector DB) are abstracted so providers can be swapped.

## 6. RAG Architecture
The assistant provides help grounded in approved documents (Ministry circulars, Scheme guidelines) and not generic knowledge. 
```
User -> Query Processing -> Retriever (Vector DB of Guidelines) -> LLM -> Grounded Response
```

## 7. Security Architecture
- **Auth**: JWT based stateless session management.
- **RBAC**: Roles including Applicant, Institution Nodal Officer, District Nodal Officer, State Nodal Officer, Ministry Desk Officer.
- **Audit**: All actions changing application state must be logged with a Correlation ID.
- **Data Protection**: PII/Identity data must be encrypted at rest.

## 8. Database Principles
- Strict normalization where appropriate.
- Use of JSONB (if Postgres) for dynamic configuration (e.g., `ApplicationFieldValue` or `FormFields`).
- Referential integrity enforced at the DB level.
- Audit trailing via separate audit tables or triggers.

## 9. API Conventions
RESTful principles apply:
- `GET /api/v1/schemes`
- `GET /api/v1/schemes/{id}/versions`
- `POST /api/v1/applications`
- `POST /api/v1/applications/{id}/documents`
- `POST /api/v1/applications/{id}/eligibility/check`

*End of Phase 0 Architecture Document.*


## Backend phase 8–16 implementation

The modular monolith now maps the remaining architecture boxes as follows:

- **Selection / Merit:** `app/modules/selection` — deterministic, auditable merit runs from versioned `SelectionCriterion` records.
- **Payment / DBT:** `app/modules/payment` — idempotent payment orders with a replaceable PFMS adapter.
- **Notifications:** `app/modules/notification` — in-app/SMS/email channel model with demo provider.
- **Grievance:** `app/modules/grievance` — ticket lifecycle and officer assignment.
- **AI / RAG:** `app/modules/rag_assistant` — scheme-scoped guideline knowledge base and local retrieval.
- **Analytics / MIS:** `app/modules/analytics` — application, payment, grievance and selection metrics.
- **Admin Dashboard:** `app/modules/admin` — aggregated dashboard payload for the admin frontend.
- **Security / Hardening:** `app/modules/security` plus middleware in `app/main.py`.
- **Deployment:** Alembic migration `f23456789012_phase_8_to_15.py`, Docker compose, health endpoint and production configuration hooks.

### End-to-end lifecycle

```text
Applicant
  -> Identity
  -> Scheme/Form
  -> Application Draft
  -> Documents
  -> Submit
  -> Eligibility
  -> Verification
  -> VERIFIED
  -> Selection Run
  -> Published Merit List
  -> Payment/DBT
  -> Notification

Applicant <-> Grievance
Admin <-> Analytics / MIS / Dashboard / Audit
Admin -> Knowledge Base -> RAG Assistant
```
