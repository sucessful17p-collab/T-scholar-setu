# Backend integration

The backend is available at `http://localhost:8000` and the API prefix is `/api/v1`.

The archive originally contained only `frontend/README.md`, not the React source (`main.jsx`, `styles.css`, package.json). To avoid overwriting the existing SIH UI, this package adds `frontend/src/api.js` as the shared API client instead of fabricating a replacement UI.

## Use from the existing React app

```js
import { api, auth } from "./api";

// OTP login
await api.requestOtp(phone);
const { access_token } = await api.verifyOtp(phone, otp);

// Dashboard
const [profile, applications, notifications] = await Promise.all([
  api.getProfile(),
  api.listApplications(),
  api.myNotifications(),
]);
```

The client automatically sends the bearer token, clears it on a 401, handles JSON errors, and supports multipart document uploads.

Set `frontend/.env` to:

```env
VITE_API_URL=http://localhost:8000/api/v1
```

The existing frontend can keep its current landing page, dashboard, animated hero, and CSS; replace direct `fetch()` calls with the functions in `api.js` so authentication and API paths stay consistent.
