# SIH Scholarship System - Frontend

This directory contains the frontend application for the AI-Enabled Scholarship and Fellowship Management System.

## Overview
The frontend will provide interfaces for:
- Applicants (Registration, Profile, Applications, Documents, RAG Assistant)
- Nodal Officers (Verification, Scrutiny, Deficiencies)
- Ministry Officials (Scheme Configuration, Selection, Approvals)
- System Administrators

*(Implementation details pending Phase 1)*
