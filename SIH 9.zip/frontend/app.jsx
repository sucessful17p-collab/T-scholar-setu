const { useState, useEffect } = React;

function App() {
  const [role, setRole] = useState(localStorage.getItem('role') || null);
  const [token, setToken] = useState(null);
  const [apiReady, setApiReady] = useState(false);

  useEffect(() => {
    const init = () => {
       setApiReady(true);
       setToken(window.auth.getToken());
    };
    if (window.api) init();
    else window.addEventListener('api-loaded', init);
    
    const handleStorage = () => setToken(window.auth.getToken());
    window.addEventListener('storage', handleStorage);
    return () => {
      window.removeEventListener('api-loaded', init);
      window.removeEventListener('storage', handleStorage);
    }
  }, []);

  if (!apiReady) return <div className="p-8">Loading Application...</div>;

  if (!token || !role) {
    return <Login setRole={setRole} setToken={setToken} />;
  }

  return (
    <div>
      <nav className={`p-4 flex justify-between shadow ${role === 'ADMIN' ? 'bg-purple-700' : 'bg-blue-600'} text-white`}>
        <h1 className="text-xl font-bold">{role === 'ADMIN' ? 'SIH Admin Portal' : 'SIH Student Portal'}</h1>
        <div className="flex items-center gap-4">
          <span className="font-semibold">{role}</span>
          <button onClick={() => {
              window.auth.clear();
              setToken(null);
              setRole(null);
          }} className="bg-red-500 hover:bg-red-600 px-4 py-2 rounded font-bold transition">Logout</button>
        </div>
      </nav>
      <div className="p-8 max-w-7xl mx-auto">
        {role === 'ADMIN' ? <AdminPortal /> : <StudentPortal />}
      </div>
    </div>
  );
}

function Login({ setRole, setToken }) {
  const [loading, setLoading] = useState(false);

  const loginStudent = async () => {
    setLoading(true);
    try {
       await window.api.requestOtp('9999999999');
       const res = await window.api.verifyOtp('9999999999', '123456');
       localStorage.setItem('role', 'STUDENT');
       setRole('STUDENT');
       setToken(res.access_token);
    } catch(e) { 
       alert('Login failed: ' + e.message); 
    }
    setLoading(false);
  };

  const loginAdmin = async () => {
    setLoading(true);
    try {
      const res = await window.api.adminDemoLogin();
      localStorage.setItem('role', 'ADMIN');
      setRole('ADMIN');
      setToken(res.access_token);
    } catch(e) { 
      alert('Admin login failed: ' + e.message); 
    }
    setLoading(false);
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-200">
      <div className="bg-white p-10 rounded-xl shadow-lg w-full max-w-md text-center">
        <h2 className="text-3xl font-extrabold mb-8 text-gray-800">SIH Portal Login</h2>
        <button onClick={loginStudent} disabled={loading} className="w-full bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-lg mb-4 font-semibold text-lg transition disabled:opacity-50">
          Login as Student (Demo)
        </button>
        <button onClick={loginAdmin} disabled={loading} className="w-full bg-purple-600 hover:bg-purple-700 text-white p-3 rounded-lg font-semibold text-lg transition disabled:opacity-50">
          Login as Admin (Demo)
        </button>
      </div>
    </div>
  );
}

function StudentPortal() {
  const [activeTab, setActiveTab] = useState('applications');
  
  return (
    <div>
      <div className="flex gap-4 border-b pb-2 mb-6">
        {['applications', 'profile', 'grievances', 'notifications', 'assistant'].map(tab => (
          <button 
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 font-bold capitalize ${activeTab === tab ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500'}`}
          >
            {tab}
          </button>
        ))}
      </div>

      {activeTab === 'applications' && <StudentApplications />}
      {activeTab === 'profile' && <StudentProfile />}
      {activeTab === 'grievances' && <StudentGrievances />}
      {activeTab === 'notifications' && <StudentNotifications />}
      {activeTab === 'assistant' && <StudentAssistant />}
    </div>
  );
}

function StudentApplications() {
  const [apps, setApps] = useState([]);
  
  const fetchApps = async () => {
    try {
      const data = await window.api.listApplications();
      setApps(data);
    } catch (e) { console.error(e); }
  };

  useEffect(() => {
    fetchApps();
    const interval = setInterval(fetchApps, 3000);
    return () => clearInterval(interval);
  }, []);

  const createDraft = async () => {
     try {
         const schemes = await window.api.getSchemes();
         if(schemes.length > 0) {
             const activeVersion = await window.api.getActiveSchemeVersion(schemes[0].id);
             await window.api.createApplication(activeVersion.id, { 
                student_name: "John Doe", 
                course: "B.Tech" 
             });
             fetchApps();
         } else {
             alert('No active schemes found. Admin needs to initialize a scheme first.');
         }
     } catch (e) { alert("Failed to create draft: " + e.message); }
  };

  const uploadDoc = async (appId) => {
    // Generate a dummy text file to act as an uploaded document
    const blob = new Blob(["This is a dummy document for SIH testing."], { type: "text/plain" });
    const file = new File([blob], "dummy_document.txt", { type: "text/plain" });
    try {
      await window.api.uploadDocument(appId, file);
      alert("Dummy Document uploaded successfully!");
    } catch(e) {
      alert("Failed to upload document: " + e.message);
    }
  }

  return (
    <div>
       <div className="flex justify-between items-center mb-6">
         <h2 className="text-2xl font-bold text-gray-800">My Applications</h2>
         <button onClick={createDraft} className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg shadow font-semibold">
            + New Application
         </button>
       </div>
       <div className="grid gap-6">
         {apps.length === 0 && <p className="text-gray-500">No applications found.</p>}
         {apps.map(app => (
            <div key={app.id} className="bg-white p-6 shadow-md rounded-lg flex flex-col md:flex-row justify-between items-center border-l-4 border-blue-500 gap-4">
               <div>
                 <p className="text-xl font-bold text-gray-800">{app.application_number}</p>
                 <p className="text-sm text-gray-500 mt-1">Submitted: {app.submitted_at ? new Date(app.submitted_at).toLocaleString() : 'Not yet'}</p>
                 <p className="mt-2 text-lg">Status: <span className="text-blue-600 font-bold bg-blue-100 px-2 py-1 rounded">{app.status}</span></p>
               </div>
               <div className="flex gap-2">
                 <button onClick={() => window.api.evaluateEligibility(app.id).then(res => alert(JSON.stringify(res))).catch(e => alert(e.message))} className="bg-gray-200 px-4 py-2 rounded font-semibold">Check Eligibility</button>
                 <button onClick={() => uploadDoc(app.id)} className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded font-semibold">Upload Doc</button>
                 {app.status === 'DRAFT' && (
                    <button onClick={async () => {
                        try {
                          await window.api.submitApplication(app.id);
                          fetchApps();
                        } catch(e) { alert("Submit failed: " + e.message); }
                    }} className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded shadow font-semibold">Submit</button>
                 )}
               </div>
            </div>
         ))}
       </div>
    </div>
  );
}

function StudentProfile() {
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    window.api.getProfile().then(setProfile).catch(console.error);
  }, []);

  if(!profile) return <div>Loading...</div>;

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h2 className="text-2xl font-bold mb-4">My Identity Profile</h2>
      <pre className="bg-gray-100 p-4 rounded text-sm overflow-auto">{JSON.stringify(profile, null, 2)}</pre>
    </div>
  )
}

function StudentGrievances() {
  const [grievances, setGrievances] = useState([]);
  const [title, setTitle] = useState('');

  useEffect(() => {
    window.api.myGrievances().then(setGrievances).catch(console.error);
  }, []);

  const submitGrievance = async () => {
    try {
      await window.api.createGrievance({ subject: title, description: "Detailed description", category: "GENERAL" });
      setTitle('');
      window.api.myGrievances().then(setGrievances);
    } catch(e) { alert(e.message); }
  }

  return (
    <div>
       <h2 className="text-2xl font-bold mb-4">Grievances</h2>
       <div className="flex gap-2 mb-6">
         <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Grievance subject" className="border p-2 rounded flex-grow" />
         <button onClick={submitGrievance} className="bg-red-500 text-white px-4 py-2 rounded">Submit Ticket</button>
       </div>
       <div className="grid gap-4">
         {grievances.map(g => (
           <div key={g.id} className="bg-white p-4 shadow rounded">
             <h3 className="font-bold">{g.subject}</h3>
             <p className="text-sm text-gray-500">Status: {g.status}</p>
           </div>
         ))}
       </div>
    </div>
  )
}

function StudentNotifications() {
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    window.api.myNotifications().then(setNotifications).catch(console.error);
  }, []);

  return (
    <div className="grid gap-4">
      {notifications.length === 0 && <p>No notifications.</p>}
      {notifications.map(n => (
        <div key={n.id} className={`p-4 shadow rounded ${n.is_read ? 'bg-gray-100' : 'bg-blue-50 border-l-4 border-blue-500'}`}>
          <h3 className="font-bold">{n.title}</h3>
          <p>{n.message}</p>
          {!n.is_read && (
            <button onClick={() => window.api.markNotificationRead(n.id).then(() => window.api.myNotifications().then(setNotifications))} className="text-sm text-blue-600 mt-2">Mark as read</button>
          )}
        </div>
      ))}
    </div>
  )
}

function StudentAssistant() {
  const [query, setQuery] = useState('');
  const [reply, setReply] = useState('');

  const ask = async () => {
    try {
      const res = await window.api.assistantQuery(query, null);
      setReply(res.answer);
    } catch(e) { alert(e.message); }
  }

  return (
    <div className="bg-white p-6 rounded shadow">
      <h2 className="text-xl font-bold mb-4">AI Assistant (RAG)</h2>
      <input value={query} onChange={e=>setQuery(e.target.value)} className="border p-2 w-full rounded mb-4" placeholder="Ask about schemes..." />
      <button onClick={ask} className="bg-indigo-500 text-white px-4 py-2 rounded w-full">Ask</button>
      {reply && <div className="mt-6 p-4 bg-gray-50 rounded italic">{reply}</div>}
    </div>
  )
}

function AdminPortal() {
  const [activeTab, setActiveTab] = useState('dashboard');
  
  return (
    <div>
      <div className="flex gap-4 border-b pb-2 mb-6">
        {['dashboard', 'verifications', 'selection', 'payments', 'audit'].map(tab => (
          <button 
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 font-bold capitalize ${activeTab === tab ? 'text-purple-700 border-b-2 border-purple-700' : 'text-gray-500'}`}
          >
            {tab}
          </button>
        ))}
      </div>

      {activeTab === 'dashboard' && <AdminDashboard />}
      {activeTab === 'verifications' && <AdminVerifications />}
      {activeTab === 'selection' && <AdminSelection />}
      {activeTab === 'payments' && <AdminPayments />}
      {activeTab === 'audit' && <AdminAudit />}
    </div>
  );
}

function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [schemes, setSchemes] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchData = async () => {
     try {
        const dashboard = await window.api.adminDashboard();
        setStats(dashboard);
        const sch = await window.api.getSchemes();
        setSchemes(sch);
     } catch (e) { console.error(e); }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 3000);
    return () => clearInterval(interval);
  }, []);

  const initScheme = async () => {
      setLoading(true);
      try {
          await window.api.createScheme({
             name: "National Scholarship Demo",
             description: "Demo Scheme for SIH",
             versions: [{
                 version_number: "2024-25",
                 is_active: true,
                 eligibility_rules: [],
                 required_documents: [],
                 form_fields: [],
                 benefits: [],
                 selection_criteria: [],
                 workflow_rules: []
             }]
          });
          fetchData();
          alert('Scheme successfully initialized!');
      } catch (e) { alert("Init scheme failed: " + e.message); }
      setLoading(false);
  }

  return (
     <div>
       <div className="flex justify-between items-center mb-6">
         <h2 className="text-2xl font-bold text-gray-800">Overview</h2>
         {schemes.length === 0 && (
           <button onClick={initScheme} disabled={loading} className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-2 rounded-lg shadow font-semibold">
              Initialize Demo Scheme
           </button>
         )}
       </div>
       
       <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 shadow-md rounded-lg border-t-4 border-purple-500">
             <h3 className="text-gray-500 font-semibold mb-2">Total Applications</h3>
             <p className="text-4xl font-bold text-gray-800">{stats?.total_applications || 0}</p>
          </div>
          <div className="bg-white p-6 shadow-md rounded-lg border-t-4 border-yellow-500">
             <h3 className="text-gray-500 font-semibold mb-2">Pending Review</h3>
             <p className="text-4xl font-bold text-gray-800">{stats?.pending_review || 0}</p>
          </div>
          <div className="bg-white p-6 shadow-md rounded-lg border-t-4 border-green-500">
             <h3 className="text-gray-500 font-semibold mb-2">Verified Applications</h3>
             <p className="text-4xl font-bold text-gray-800">{stats?.verified || 0}</p>
          </div>
       </div>
     </div>
  );
}

function AdminVerifications() {
  const [assignments, setAssignments] = useState([]);

  useEffect(() => {
    window.api.verifications.mine().then(setAssignments).catch(console.error);
  }, []);

  return (
    <div>
       <h2 className="text-2xl font-bold mb-4">My Verification Queue</h2>
       <p className="mb-4 text-gray-600">Pending applications assigned to you for verification.</p>
       {assignments.length === 0 ? <p>No assignments currently.</p> : (
         <div className="grid gap-4">
            {assignments.map(a => (
               <div key={a.id} className="bg-white p-4 shadow rounded flex justify-between">
                  <span>Application #{a.application_id} - Step: {a.step_name}</span>
                  <div className="flex gap-2">
                     <button onClick={() => window.api.verifications.action(a.id, 'APPROVE').then(()=>window.api.verifications.mine().then(setAssignments))} className="bg-green-500 text-white px-3 py-1 rounded">Approve</button>
                     <button onClick={() => window.api.verifications.action(a.id, 'REJECT').then(()=>window.api.verifications.mine().then(setAssignments))} className="bg-red-500 text-white px-3 py-1 rounded">Reject</button>
                  </div>
               </div>
            ))}
         </div>
       )}
    </div>
  )
}

function AdminSelection() {
  return (
    <div className="bg-white p-6 rounded shadow">
      <h2 className="text-2xl font-bold mb-4">Selection Runs</h2>
      <p>Configure algorithm criteria and trigger bulk selection runs (API connection placeholder).</p>
      <button className="bg-purple-600 text-white px-4 py-2 rounded mt-4" onClick={() => alert("Requires active scheme ID and bulk data.")}>Create Run</button>
    </div>
  )
}

function AdminPayments() {
  const [payments, setPayments] = useState([]);

  useEffect(() => {
    window.api.adminPayments.list().then(setPayments).catch(console.error);
  }, []);

  return (
    <div>
       <h2 className="text-2xl font-bold mb-4">Payment Disbursement</h2>
       <div className="bg-white p-6 rounded shadow">
         {payments.length === 0 ? <p>No payments found.</p> : (
           <ul>
             {payments.map(p => <li key={p.id} className="border-b py-2">{p.amount} {p.currency} - {p.status}</li>)}
           </ul>
         )}
       </div>
    </div>
  )
}

function AdminAudit() {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    window.api.auditLogs(10).then(setLogs).catch(console.error);
  }, []);

  return (
    <div className="bg-white p-6 rounded shadow">
       <h2 className="text-2xl font-bold mb-4">Security Audit Logs (Last 10)</h2>
       <div className="overflow-x-auto">
         <table className="min-w-full">
           <thead>
             <tr className="bg-gray-100 text-left">
               <th className="p-2">Action</th>
               <th className="p-2">User ID</th>
               <th className="p-2">IP</th>
               <th className="p-2">Time</th>
             </tr>
           </thead>
           <tbody>
             {logs.map(log => (
               <tr key={log.id} className="border-b">
                 <td className="p-2 text-sm">{log.action}</td>
                 <td className="p-2 text-sm">{log.user_id}</td>
                 <td className="p-2 text-sm">{log.ip_address}</td>
                 <td className="p-2 text-sm">{new Date(log.timestamp).toLocaleString()}</td>
               </tr>
             ))}
           </tbody>
         </table>
       </div>
    </div>
  )
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
