// Use relative path to avoid CORS issues since it's served by the same backend
const API_BASE_URL = '/api/v1';
const TOKEN_KEY = 'sih_access_token';
const LEGACY_TOKEN_KEY = 'token';

export const auth = {
  getToken: () => localStorage.getItem(TOKEN_KEY) || localStorage.getItem(LEGACY_TOKEN_KEY),
  setToken: (token) => {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(LEGACY_TOKEN_KEY, token);
  },
  clear: () => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(LEGACY_TOKEN_KEY);
    localStorage.removeItem('role');
  },
};

async function request(path, options = {}) {
  const headers = new Headers(options.headers || {});
  const token = auth.getToken();
  if (token) headers.set('Authorization', `Bearer ${token}`);

  const isFormData = options.body instanceof FormData;
  if (!isFormData && options.body !== undefined) {
    headers.set('Content-Type', 'application/json');
  }

  const response = await fetch(`${API_BASE_URL}${path}`, { ...options, headers });
  const text = await response.text();
  let payload = null;
  try { payload = text ? JSON.parse(text) : null; } catch { payload = text; }

  if (response.status === 401) auth.clear();
  if (!response.ok) {
    const message = payload?.detail || payload?.message || `Request failed (${response.status})`;
    const error = new Error(message);
    error.status = response.status;
    error.payload = payload;
    throw error;
  }
  return payload;
}

const json = (method, path, body) => request(path, {
  method,
  body: JSON.stringify(body),
});

export const api = {
  requestOtp: (phone_number) => json('POST', '/identity/auth/request-otp', { phone_number }),

  verifyOtp: async (phone_number, otp) => {
    const data = await json('POST', '/identity/auth/verify-otp', { phone_number, otp });
    auth.setToken(data.access_token);
    return data;
  },
  adminDemoLogin: async () => {
    const data = await request('/identity/auth/admin-demo', { method: 'POST' });
    auth.setToken(data.access_token);
    return data;
  },

  getProfile: () => request('/identity/profile'),

  getSchemes: () => request('/schemes/'),
  getActiveSchemeVersion: (schemeId) => request(`/schemes/${schemeId}/versions/active`),

  createScheme: (payload) => json('POST', '/schemes/', payload),

  createApplication: (scheme_version_id, form_data = {}) =>
    json('POST', '/applications/', { scheme_version_id, form_data }),
  listApplications: () => request('/applications/'),
  getApplication: (applicationId) => request(`/applications/${applicationId}`),
  updateApplication: (applicationId, form_data) =>
    json('PATCH', `/applications/${applicationId}`, { form_data }),
  submitApplication: (applicationId) => json('POST', `/applications/${applicationId}/submit`),

  evaluateEligibility: (applicationId) =>
    request(`/applications/${applicationId}/eligibility/evaluate`, { method: 'POST' }),
  getEligibility: (applicationId) => request(`/applications/${applicationId}/eligibility`),

  uploadDocument: (applicationId, file, required_document_id = null) => {
    const body = new FormData();
    body.append('file', file);
    if (required_document_id != null) body.append('required_document_id', String(required_document_id));
    return request(`/applications/${applicationId}/documents/`, { method: 'POST', body });
  },
  listDocuments: (applicationId) => request(`/applications/${applicationId}/documents/`),
  deleteDocument: (documentId) => request(`/documents/${documentId}`, { method: 'DELETE' }),

  downloadDocument: async (documentId) => {
    const token = auth.getToken();
    const response = await fetch(`${API_BASE_URL}/documents/${documentId}/download`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    if (!response.ok) throw new Error(`Download failed (${response.status})`);
    return response.blob();
  },

  myNotifications: () => request('/notifications/me'),
  markNotificationRead: (id) => request(`/notifications/${id}/read`, { method: 'POST' }),
  createGrievance: (data) => json('POST', '/grievances/', data),
  myGrievances: () => request('/grievances/me'),
  updateGrievance: (id, data) => json('PATCH', `/grievances/${id}`, data),
  assistantQuery: (question, scheme_version_id) =>
    json('POST', '/assistant/query', { question, scheme_version_id }),

  adminDashboard: () => request('/admin/dashboard'),
  analyticsOverview: () => request('/analytics/overview'),
  auditLogs: (limit = 100) => request(`/security/audit?limit=${Math.min(Math.max(limit, 1), 500)}`),

  selectionRuns: {
    create: (scheme_version_id, seats) => json('POST', '/selection/runs', { scheme_version_id, seats }),
    execute: (id) => request(`/selection/runs/${id}/execute`, { method: 'POST' }),
    publish: (id) => request(`/selection/runs/${id}/publish`, { method: 'POST' }),
    get: (id) => request(`/selection/runs/${id}`),
  },

  verifications: {
    mine: () => request('/verifications/my-assignments'),
    assignToMe: (id) => request(`/verifications/assignments/${id}/assign-to-me`, { method: 'POST' }),
    action: (id, action, comments = null) =>
      json('POST', `/verifications/assignments/${id}/actions`, { action, comments }),
  },

  adminPayments: {
    list: () => request('/payments/'),
    create: (data) => json('POST', '/payments/', data),
  },
};

export { API_BASE_URL };
